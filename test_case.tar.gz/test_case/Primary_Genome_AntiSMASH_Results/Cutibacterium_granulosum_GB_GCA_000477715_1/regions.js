var recordData = [
    {
        "length": 1405158,
        "seq_id": "KI515698.1",
        "regions": []
    },
    {
        "length": 145783,
        "seq_id": "KI515699.1",
        "regions": []
    },
    {
        "length": 575789,
        "seq_id": "KI515700.1",
        "regions": []
    },
    {
        "length": 1115,
        "seq_id": "KI515701.1",
        "regions": []
    }
];
var all_regions = {
    "order": []
};
var details_data = {
    "nrpspks": {},
    "pfam": {}
};
var resultsData = {};
