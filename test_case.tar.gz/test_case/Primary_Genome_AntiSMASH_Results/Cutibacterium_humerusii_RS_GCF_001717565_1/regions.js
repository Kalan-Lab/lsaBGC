var recordData = [
    {
        "length": 2571505,
        "seq_id": "CP017040.1",
        "regions": [
            {
                "start": 1703547,
                "end": 1713879,
                "idx": 1,
                "orfs": [
                    {
                        "start": 1703829,
                        "end": 1704422,
                        "strand": 1,
                        "locus_tag": "AAA_01665",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01665</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01665</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,703,829 - 1,704,422,\n (total: 594 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01850.21 (PIN domain): [4:117](score: 30.3, e-value: 4.9e-07)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTLVVEVSVLAEMLVGSTVGCAAWQQWGGEEFIAPQHLSAEIAHVVRNLSLGQLITDAEAMQILSDFRAFKVELYPVEPLMVDAWEMRHNVSAYDALYVVLARLLGACLLTRDHRLKPRAVLGRSPLRTDLTGRGSRSIRRAISFGSTPRPTRCALGPEPDCPAQSLGASSGSLACSACSDKAARSDLVWDASRGPP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1693829&amp;to=1714422\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTLVVEVSVLAEMLVGSTVGCAAWQQWGGEEFIAPQHLSAEIAHVVRNLSLGQLITDAEAMQILSDFRAFKVELYPVEPLMVDAWEMRHNVSAYDALYVVLARLLGACLLTRDHRLKPRAVLGRSPLRTDLTGRGSRSIRRAISFGSTPRPTRCALGPEPDCPAQSLGASSGSLACSACSDKAARSDLVWDASRGPP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACACTTGTCGTCGAAGTGTCCGTGCTCGCTGAAATGCTCGTTGGTAGCACGGTTGGGTGTGCGGCATGGCAGCAATGGGGCGGCGAGGAGTTCATTGCCCCCCAGCATCTGTCTGCAGAGATTGCCCATGTCGTACGAAACCTCTCCTTGGGGCAACTCATCACCGATGCGGAGGCAATGCAGATATTGTCGGACTTCCGAGCATTCAAGGTGGAGTTGTATCCGGTGGAACCACTGATGGTGGATGCGTGGGAGATGCGGCACAACGTGTCTGCTTATGATGCGCTGTACGTGGTGCTGGCGCGTCTGTTGGGTGCGTGTCTGTTGACGCGTGACCATCGTCTGAAGCCCAGGGCTGTGCTGGGCCGTTCGCCCTTGAGGACGGACCTCACCGGACGGGGGTCTCGGTCGATTCGTCGGGCGATCTCTTTTGGCTCCACCCCTCGGCCAACAAGGTGCGCACTAGGTCCTGAGCCTGACTGTCCTGCTCAGTCACTGGGCGCCTCCTCGGGAAGTCTTGCTTGCTCGGCCTGCTCTGACAAAGCGGCCCGTTCCGATCTGGTTTGGGACGCCTCTAGGGGCCCTCCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1704320,
                        "end": 1704652,
                        "strand": -1,
                        "locus_tag": "AAA_01666",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01666</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01666</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,704,320 - 1,704,652,\n (total: 333 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MHHRGASLTAAVITIAALASGCQSNSSASAPSPTPTPTVTSATPSPTPSAGAVYTSSVATWTLHPSGQGRTAAPHGCHGGPLEASQTRSERAALSEQAEQARLPEEAPSD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1694320&amp;to=1714652\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MHHRGASLTAAVITIAALASGCQSNSSASAPSPTPTPTVTSATPSPTPSAGAVYTSSVATWTLHPSGQGRTAAPHGCHGGPLEASQTRSERAALSEQAEQARLPEEAPSD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCACCATCGTGGCGCATCCCTGACCGCAGCTGTTATCACGATCGCAGCCCTGGCCAGTGGCTGCCAATCCAACAGTTCAGCATCCGCACCCTCACCCACGCCGACCCCGACTGTTACCTCGGCTACCCCCAGCCCGACCCCGTCAGCCGGAGCGGTCTACACCAGCAGCGTGGCCACCTGGACGCTCCACCCAAGTGGGCAAGGACGGACGGCTGCGCCTCACGGGTGTCATGGAGGGCCCCTAGAGGCGTCCCAAACCAGATCGGAACGGGCCGCTTTGTCAGAGCAGGCCGAGCAAGCAAGACTTCCCGAGGAGGCGCCCAGTGACTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1704690,
                        "end": 1704917,
                        "strand": -1,
                        "locus_tag": "AAA_01667",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01667</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01667</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,704,690 - 1,704,917,\n (total: 228 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MELARWALTQGLLVSPDHEDLVAGCLRTEYQAGNMDKVCELVDHLSATARRLGVDLGEDTTRIIDTVTDTHTRAS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1694690&amp;to=1714917\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MELARWALTQGLLVSPDHEDLVAGCLRTEYQAGNMDKVCELVDHLSATARRLGVDLGEDTTRIIDTVTDTHTRAS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGGAGTTGGCCCGGTGGGCCCTGACCCAAGGACTCCTCGTATCACCCGATCATGAGGACCTGGTCGCCGGATGCCTACGCACCGAGTACCAGGCCGGGAACATGGACAAAGTCTGCGAACTCGTCGATCACCTGTCGGCCACCGCCCGCCGGCTGGGCGTCGACCTGGGCGAAGACACCACCCGCATCATCGATACGGTCACCGATACACACACAAGAGCGTCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1705288,
                        "end": 1705446,
                        "strand": 1,
                        "locus_tag": "AAA_01668",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01668</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01668</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,705,288 - 1,705,446,\n (total: 159 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKLTTTLEHRTRSVQSPITSAFGGASVTVDLLAPGGSTCSSAGSRRPARRAL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1695288&amp;to=1715446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKLTTTLEHRTRSVQSPITSAFGGASVTVDLLAPGGSTCSSAGSRRPARRAL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGCTCACCACCACCCTTGAGCATCGCACCCGCAGCGTTCAGAGCCCGATCACCTCGGCCTTCGGCGGCGCCTCGGTCACCGTCGACCTCTTGGCCCCGGGTGGCTCGACTTGCTCCAGCGCTGGCTCTCGTCGTCCTGCTCGACGTGCGCTGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1705537,
                        "end": 1705833,
                        "strand": -1,
                        "locus_tag": "AAA_01669",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01669</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01669</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,705,537 - 1,705,833,\n (total: 297 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01061.24 (ABC-2 type transporter): [1:61](score: 38.0, e-value: 1.2e-09)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSYALALRTKSEAALSAIFNVALLPLLLLSGIMLPLSFAPRWIGAVARFNPLWYLVSGTRDQFERGDLTGSAVIAWAIAFGGMVVAYLWGSHEFGKRR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1695537&amp;to=1715833\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_01669_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSYALALRTKSEAALSAIFNVALLPLLLLSGIMLPLSFAPRWIGAVARFNPLWYLVSGTRDQFERGDLTGSAVIAWAIAFGGMVVAYLWGSHEFGKRR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCCTACGCTCTGGCGCTGCGGACTAAGAGCGAAGCAGCCTTGTCCGCGATCTTCAATGTCGCCCTGCTGCCCCTCCTCCTGCTATCGGGGATCATGCTGCCGCTGTCCTTCGCCCCGCGCTGGATCGGAGCCGTCGCTCGCTTCAATCCGCTCTGGTACCTCGTGTCAGGCACGCGTGATCAGTTCGAGCGAGGTGATCTCACCGGCTCAGCTGTCATCGCATGGGCTATCGCCTTTGGCGGGATGGTCGTGGCATATCTCTGGGGCTCCCACGAGTTTGGGAAGCGTCGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1705940,
                        "end": 1706269,
                        "strand": -1,
                        "locus_tag": "AAA_01670",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01670</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01670</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,705,940 - 1,706,269,\n (total: 330 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01061.24 (ABC-2 type transporter): [2:92](score: 30.4, e-value: 2.4e-07)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTACFRRYLTLAARNRRDFALSFVQPLVYIVLFGPLFVASVNMAQHLTQGRSYALYVSGLCLQIAMTIGAFSGLSIILEYRLGILERIWSTPSLAAQRSGGESAATWCS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1695940&amp;to=1716269\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTACFRRYLTLAARNRRDFALSFVQPLVYIVLFGPLFVASVNMAQHLTQGRSYALYVSGLCLQIAMTIGAFSGLSIILEYRLGILERIWSTPSLAAQRSGGESAATWCS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGGCATGCTTCCGCAGGTATCTGACGTTGGCGGCGCGCAATCGCCGTGATTTCGCGTTGTCATTCGTTCAACCGCTCGTGTACATCGTGTTGTTCGGGCCACTCTTCGTCGCCTCGGTGAACATGGCGCAACACTTGACACAGGGCCGCTCGTATGCGCTGTACGTGAGTGGACTCTGCCTCCAGATCGCCATGACCATCGGCGCGTTCTCGGGGCTGTCGATCATCTTGGAGTATCGACTCGGAATCTTGGAACGCATATGGAGCACCCCCTCACTGGCCGCGCAGCGATCGGGGGGCGAATCGGCAGCGACGTGGTGCTCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1706266,
                        "end": 1707246,
                        "strand": -1,
                        "locus_tag": "AAA_01671",
                        "type": "transport",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01671</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01671</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,706,266 - 1,707,246,\n (total: 981 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 170.1; E-value: 1e-51)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00005.27 (ABC transporter): [32:172](score: 95.1, e-value: 4.9e-27)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDANASSPVPTTLSIRNLVKKYKVRGGYQVPALNGVSLELGRGEMLSLFGPNGAGKTTLVRIIAGLLSADSGTIEWPGNESRNPRSLLGYVSQKGGLQYGLTCREEMTFHVRCFGLGDREAARRVERVTEMLHCGYLLDWNVDRLSGGQRRVVEVGMALLHEPAVILLDEPTLGLDPATRLSLWETVGSARRESDAAFLVTTHYIDEVAQQLSNVSVINHGTVIASGTPEELQSTYSTGSVSIMVPRERLSEATQALQPISPDVYAVSGKVVVPAPSPDRVVTAALQALEGHGIRALAVAVRKPSLNEAFLALTSTPSASEGEWTA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1696266&amp;to=1717246\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_01671_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%0AMDANASSPVPTTLSIRNLVKKYKVRGGYQVPALNGVSLELGRGEMLSLFGPNGAGKTTLVRIIAGLLSADSGTIEWPGNESRNPRSLLGYVSQKGGLQYGLTCREEMTFHVRCFGLGDREAARRVERVTEMLHCGYLLDWNVDRLSGGQRRVVEVGMALLHEPAVILLDEPTLGLDPATRLSLWETVGSARRESDAAFLVTTHYIDEVAQQLSNVSVINHGTVIASGTPEELQSTYSTGSVSIMVPRERLSEATQALQPISPDVYAVSGKVVVPAPSPDRVVTAALQALEGHGIRALAVAVRKPSLNEAFLALTSTPSASEGEWTA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDANASSPVPTTLSIRNLVKKYKVRGGYQVPALNGVSLELGRGEMLSLFGPNGAGKTTLVRIIAGLLSADSGTIEWPGNESRNPRSLLGYVSQKGGLQYGLTCREEMTFHVRCFGLGDREAARRVERVTEMLHCGYLLDWNVDRLSGGQRRVVEVGMALLHEPAVILLDEPTLGLDPATRLSLWETVGSARRESDAAFLVTTHYIDEVAQQLSNVSVINHGTVIASGTPEELQSTYSTGSVSIMVPRERLSEATQALQPISPDVYAVSGKVVVPAPSPDRVVTAALQALEGHGIRALAVAVRKPSLNEAFLALTSTPSASEGEWTA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGGACGCGAACGCCTCCTCGCCTGTTCCCACGACCCTGTCCATCAGGAATCTCGTCAAGAAGTACAAGGTCCGGGGCGGGTACCAGGTCCCCGCTCTCAACGGGGTCTCGCTTGAGCTCGGTCGCGGTGAGATGCTCAGTCTGTTCGGTCCCAACGGTGCAGGAAAGACCACCTTGGTCAGGATCATTGCAGGGCTCCTGTCGGCAGACTCTGGGACGATCGAATGGCCCGGCAACGAGAGTCGGAACCCGAGGTCGTTGCTGGGGTACGTTTCGCAGAAGGGCGGCCTGCAGTACGGACTGACGTGCCGCGAAGAGATGACCTTTCATGTCCGTTGCTTCGGTCTGGGGGACCGCGAGGCTGCGCGGCGCGTTGAAAGAGTCACCGAGATGCTCCATTGTGGCTACCTGCTCGACTGGAACGTAGACCGCCTGTCCGGTGGGCAACGACGTGTCGTCGAAGTGGGTATGGCACTGCTGCACGAGCCGGCGGTGATCCTCCTGGACGAACCGACTCTCGGGCTCGACCCGGCCACGCGTCTATCCCTGTGGGAGACGGTGGGCTCGGCTAGGCGGGAGTCCGATGCAGCCTTCCTTGTGACCACGCATTACATCGACGAAGTCGCGCAGCAGCTCTCCAATGTGAGCGTCATCAACCATGGCACGGTCATCGCGTCAGGCACCCCGGAAGAGCTGCAATCCACGTACTCCACCGGCAGTGTCTCGATCATGGTTCCAAGGGAGCGACTAAGTGAGGCGACCCAAGCACTGCAACCAATCTCCCCAGACGTCTATGCGGTGTCCGGCAAGGTCGTAGTGCCGGCCCCGTCGCCGGATCGAGTGGTCACGGCGGCACTGCAGGCTTTGGAGGGCCATGGCATCCGTGCGTTGGCGGTCGCCGTTCGCAAACCATCCCTCAATGAGGCATTCCTGGCGCTGACCTCGACCCCGTCCGCATCAGAAGGAGAATGGACCGCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1707256,
                        "end": 1707768,
                        "strand": -1,
                        "locus_tag": "AAA_01672",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01672</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01672</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,707,256 - 1,707,768,\n (total: 513 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MFMPTRNVYVSDKDQALFREAAEIAGGLSPAVSEALHEYVQRRRLVAASLKQIEVDLRSEGVDRRVSFMGRRLARVQRDHKQGHRVDTVYVTAKSQIAVVSKVQRSLPGWAEGRENLWSHPETWDRNFWTAGDRTLAVFADLDELRTADTDLADRVESAMRVVPYQVLDI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1697256&amp;to=1717768\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MFMPTRNVYVSDKDQALFREAAEIAGGLSPAVSEALHEYVQRRRLVAASLKQIEVDLRSEGVDRRVSFMGRRLARVQRDHKQGHRVDTVYVTAKSQIAVVSKVQRSLPGWAEGRENLWSHPETWDRNFWTAGDRTLAVFADLDELRTADTDLADRVESAMRVVPYQVLDI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTTCATGCCTACTCGAAACGTGTACGTGTCTGACAAAGACCAGGCTTTGTTCCGCGAGGCGGCCGAGATAGCGGGAGGATTGTCGCCGGCGGTCAGTGAGGCCTTGCATGAGTACGTCCAACGCCGTCGGCTTGTGGCGGCGAGTCTCAAGCAGATCGAGGTGGACCTGCGCAGTGAGGGTGTTGATCGCCGTGTCTCTTTCATGGGTAGACGACTGGCGCGGGTGCAACGGGACCACAAACAGGGCCACCGTGTCGACACCGTGTACGTAACGGCCAAGAGCCAGATCGCCGTTGTGTCCAAGGTTCAGCGTTCCCTGCCTGGTTGGGCCGAGGGGAGAGAGAATCTCTGGTCTCATCCGGAGACCTGGGACAGGAACTTCTGGACGGCTGGGGACCGCACCCTCGCCGTCTTCGCAGACTTGGACGAGCTGCGCACCGCCGATACCGACCTTGCTGATCGGGTGGAGTCGGCAATGCGAGTCGTGCCCTACCAGGTTCTGGACATCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1708022,
                        "end": 1708243,
                        "strand": 1,
                        "locus_tag": "AAA_01673",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01673</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01673</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,708,022 - 1,708,243,\n (total: 222 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF10991.8 (Protein of unknown function (DUF2815)): [8:50](score: 43.7, e-value: 2.7e-11)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSTTNPTRVVTGEVRLSYTNIFEAKSIQGGKPKYSVSVIIPKGERVTGIEPAYPARESDPRLDSGVPTSLWER&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1698022&amp;to=1718243\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSTTNPTRVVTGEVRLSYTNIFEAKSIQGGKPKYSVSVIIPKGERVTGIEPAYPARESDPRLDSGVPTSLWER\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCTACAACTAATCCGACCCGTGTGGTCACCGGCGAAGTCCGCCTGTCCTACACCAACATCTTCGAGGCGAAGAGTATCCAGGGCGGAAAGCCCAAGTACTCCGTCAGCGTGATCATCCCGAAGGGCGAGCGGGTGACGGGAATCGAACCCGCATATCCAGCTCGGGAATCCGATCCACGGTTGGATTCAGGCGTGCCGACGAGCTTATGGGAGCGGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1708547,
                        "end": 1708879,
                        "strand": 1,
                        "locus_tag": "AAA_01674",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01674</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01674</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,708,547 - 1,708,879,\n (total: 333 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RiPP-like: Lactococcin_972<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF09683.10 (Bacteriocin (Lactococcin_972)): [52:107](score: 42.4, e-value: 7.7e-11)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MFSSPLQGNHNWKIPRYYLSEEKDTRKVLGIAAAVAVFVGVGTLPALAWDNAGGGLWDHGSDMSSVWSNYYHRTSNHGSTAAGNEVKYSGCKRPTVTSHASAPLSWYKTV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1698547&amp;to=1718879\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MFSSPLQGNHNWKIPRYYLSEEKDTRKVLGIAAAVAVFVGVGTLPALAWDNAGGGLWDHGSDMSSVWSNYYHRTSNHGSTAAGNEVKYSGCKRPTVTSHASAPLSWYKTV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTTCAGTAGCCCCCTGCAAGGGAATCACAATTGGAAGATTCCTCGATATTATCTCAGTGAGGAGAAAGACACGCGTAAGGTGCTAGGGATTGCTGCAGCGGTGGCGGTCTTCGTTGGAGTGGGTACGCTTCCGGCATTGGCTTGGGACAACGCTGGTGGAGGGTTGTGGGATCATGGATCGGATATGTCGAGCGTCTGGTCTAATTATTATCACCGGACCTCTAACCATGGATCCACGGCAGCGGGCAACGAGGTCAAGTACTCCGGATGTAAGCGCCCCACGGTGACGTCGCATGCATCGGCGCCGCTCTCCTGGTACAAGACGGTATAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1709026,
                        "end": 1710342,
                        "strand": 1,
                        "locus_tag": "AAA_01675",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01675</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01675</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,709,026 - 1,710,342,\n (total: 1317 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPSRVLKFSFVFMLILTLGMAFAVLRDYDGQTLTGCHYSLIVDGPLKRVEDSFKGLVSKLQSFSENHSVMIAKRDIGLDETQAARVVYVTSGSSLGREWLGEGYPSVNTDLTTVVKPIADVAVLDPRGIYLTTASRVQTEEIASIFQEAGLGVQVENERSVQRIVGFYFHSGPFAILIATIAVCSAIFLLGALILDLRRYTTQVLNGWSIGNIVASDGICIARVCLLWLLVLGAISFGGLVIFSGVTAATILVFLWLGMFIPGALLLLVLERVSLGIIFSDSIGTLLKGGVNSKYLVILLRGIQVLCICIAISLSNSLAAGVAQANSIARSNADWERFAHLAVVGLKTAQSVDGDMPVQVGSYGARELTSGRAVLALNSDPQASLGEVPSSFSGWKVLVVNDTYLRVSGMSKGWGVDEDSSDVQVLTPRGFLGTDSEN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1699026&amp;to=1720342\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPSRVLKFSFVFMLILTLGMAFAVLRDYDGQTLTGCHYSLIVDGPLKRVEDSFKGLVSKLQSFSENHSVMIAKRDIGLDETQAARVVYVTSGSSLGREWLGEGYPSVNTDLTTVVKPIADVAVLDPRGIYLTTASRVQTEEIASIFQEAGLGVQVENERSVQRIVGFYFHSGPFAILIATIAVCSAIFLLGALILDLRRYTTQVLNGWSIGNIVASDGICIARVCLLWLLVLGAISFGGLVIFSGVTAATILVFLWLGMFIPGALLLLVLERVSLGIIFSDSIGTLLKGGVNSKYLVILLRGIQVLCICIAISLSNSLAAGVAQANSIARSNADWERFAHLAVVGLKTAQSVDGDMPVQVGSYGARELTSGRAVLALNSDPQASLGEVPSSFSGWKVLVVNDTYLRVSGMSKGWGVDEDSSDVQVLTPRGFLGTDSEN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCATCCCGGGTCCTGAAATTCAGCTTCGTATTCATGCTCATTCTTACCTTGGGTATGGCATTCGCAGTGTTGCGAGACTATGACGGTCAGACTCTCACCGGATGCCATTACTCCCTGATTGTAGATGGGCCGTTGAAGAGGGTTGAGGATTCCTTTAAGGGCCTTGTATCAAAGCTGCAATCCTTTTCGGAGAATCATTCCGTAATGATTGCGAAGCGTGACATTGGACTGGATGAGACTCAGGCTGCCAGAGTGGTTTACGTGACTTCGGGGTCCTCTTTGGGACGCGAGTGGCTGGGGGAGGGTTATCCCAGTGTGAACACCGATCTGACCACAGTGGTTAAACCGATTGCCGATGTAGCCGTATTGGATCCCCGTGGGATCTATCTGACGACGGCGAGTAGAGTACAGACGGAAGAGATTGCCTCCATTTTTCAAGAAGCTGGACTGGGCGTCCAAGTCGAAAATGAACGATCGGTTCAAAGAATTGTGGGATTTTATTTCCACAGCGGTCCCTTTGCGATTTTGATTGCAACAATTGCTGTATGCTCTGCGATCTTTCTTCTCGGGGCCCTAATTTTAGATCTGCGACGCTATACGACTCAAGTGCTCAACGGATGGAGCATTGGTAATATTGTCGCCTCCGATGGCATTTGTATTGCGAGGGTTTGCCTACTTTGGCTGTTGGTGCTAGGTGCCATTTCATTCGGGGGCCTGGTGATTTTTAGTGGTGTCACTGCGGCAACGATCTTGGTATTCCTCTGGTTGGGAATGTTTATTCCCGGGGCCCTTCTCCTACTTGTCTTGGAGAGAGTTTCCCTAGGAATTATCTTTTCTGACAGTATCGGGACCCTACTTAAGGGCGGGGTTAATTCAAAGTACCTGGTAATACTTTTGAGGGGCATCCAAGTCTTATGTATCTGTATAGCCATTTCGTTGAGTAATAGTCTAGCTGCCGGAGTTGCTCAGGCTAACTCGATTGCAAGATCAAACGCTGACTGGGAAAGATTTGCTCACCTAGCGGTAGTTGGGCTGAAGACGGCACAGTCTGTTGATGGTGACATGCCGGTACAGGTGGGGTCTTATGGCGCTCGTGAGCTGACGTCTGGGCGAGCCGTTCTCGCGCTCAACTCTGACCCCCAGGCCAGCTTAGGTGAGGTACCCTCGAGCTTTTCCGGATGGAAGGTGCTCGTGGTGAACGACACTTACCTGCGTGTGAGCGGAATGTCCAAGGGGTGGGGTGTAGACGAAGATAGTTCCGACGTTCAAGTGCTTACTCCGAGAGGTTTCTTGGGAACTGATAGCGAAAATTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1710434,
                        "end": 1711093,
                        "strand": 1,
                        "locus_tag": "AAA_01676",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01676</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01676</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,710,434 - 1,711,093,\n (total: 660 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTIGAVPPIGSVGESSSRYARTIIAVLPEKFGKLSPNDVMAMISNGSILFTSARKVVDDVSQDAGLTRYVSSVTPLQSVALKKEEDLLNSNSQLLAALLLSISALLGMSLANDIVYFKISRQRIKAQLMNGWFSIRMHWLFECTELLLVSAVIYWQYYRQHSYGVILANPQSTSFAYFKASLAVSRWAVPGAVAVSLISLLGAGGALVLGTRRILRNKF&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1700434&amp;to=1721093\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTIGAVPPIGSVGESSSRYARTIIAVLPEKFGKLSPNDVMAMISNGSILFTSARKVVDDVSQDAGLTRYVSSVTPLQSVALKKEEDLLNSNSQLLAALLLSISALLGMSLANDIVYFKISRQRIKAQLMNGWFSIRMHWLFECTELLLVSAVIYWQYYRQHSYGVILANPQSTSFAYFKASLAVSRWAVPGAVAVSLISLLGAGGALVLGTRRILRNKF\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACTATCGGCGCGGTTCCCCCTATCGGCTCTGTCGGAGAGTCGTCATCTCGTTACGCGCGGACCATCATCGCGGTGCTACCTGAGAAATTTGGAAAACTCTCGCCTAATGATGTGATGGCAATGATTAGTAACGGATCAATCTTGTTTACGAGCGCACGCAAGGTGGTTGATGACGTGTCTCAGGATGCTGGCTTGACGAGATATGTTTCCTCAGTAACTCCGCTGCAGAGTGTTGCTCTCAAGAAGGAGGAGGATCTGTTGAATTCGAACTCTCAACTGCTCGCGGCGCTACTCTTATCGATTTCAGCCCTGCTGGGTATGTCCCTGGCCAACGACATCGTGTATTTCAAAATTTCCAGGCAACGTATTAAGGCGCAGCTGATGAATGGCTGGTTCAGTATAAGAATGCACTGGCTATTTGAATGCACTGAGTTGCTCTTGGTGAGTGCTGTGATTTATTGGCAATATTATCGACAGCACTCTTATGGGGTGATTTTAGCTAATCCACAATCGACATCATTTGCCTATTTCAAGGCAAGCCTTGCGGTGAGTAGGTGGGCTGTACCTGGAGCTGTTGCTGTCTCGCTTATCTCCCTTCTGGGTGCTGGGGGTGCCTTAGTGCTTGGAACTCGGCGCATTCTGCGCAATAAGTTCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1711142,
                        "end": 1711780,
                        "strand": 1,
                        "locus_tag": "AAA_01677",
                        "type": "transport",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01677</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01677</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,711,142 - 1,711,780,\n (total: 639 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 170.2; E-value: 9.6e-52)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00005.27 (ABC transporter): [19:165](score: 108.8, e-value: 2.9e-31)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSLGVENLSKSFGSRELWRGISFEVSRGKIFGITGPSGGGKTTLLNCLGALEKPTSGNIFLNGRRISGLSVRKSRRLWAKDIGFLFQDYALVDRMNVRSNVSMGVPHLIGRRGLDDGISSALAGVGLPGCGVNPTYQLSGGEQQRVALARLMLKSPSLVLADEPTGSLDALNEEMVLKHLRSFAKQGSMVVVASHSNSVLECCDQVLEVGLH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1701142&amp;to=1721780\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_01677_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%0AMSLGVENLSKSFGSRELWRGISFEVSRGKIFGITGPSGGGKTTLLNCLGALEKPTSGNIFLNGRRISGLSVRKSRRLWAKDIGFLFQDYALVDRMNVRSNVSMGVPHLIGRRGLDDGISSALAGVGLPGCGVNPTYQLSGGEQQRVALARLMLKSPSLVLADEPTGSLDALNEEMVLKHLRSFAKQGSMVVVASHSNSVLECCDQVLEVGLH\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSLGVENLSKSFGSRELWRGISFEVSRGKIFGITGPSGGGKTTLLNCLGALEKPTSGNIFLNGRRISGLSVRKSRRLWAKDIGFLFQDYALVDRMNVRSNVSMGVPHLIGRRGLDDGISSALAGVGLPGCGVNPTYQLSGGEQQRVALARLMLKSPSLVLADEPTGSLDALNEEMVLKHLRSFAKQGSMVVVASHSNSVLECCDQVLEVGLH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGTCTTGGCGTCGAAAATCTAAGTAAGAGTTTTGGCTCGAGGGAGCTGTGGCGGGGAATATCCTTTGAAGTCTCTCGAGGGAAGATTTTTGGGATCACTGGCCCGAGTGGAGGTGGGAAGACCACGCTCCTGAACTGTCTCGGAGCACTAGAAAAACCTACGAGCGGGAATATTTTTCTGAATGGCAGGCGTATATCGGGTTTGAGTGTGCGTAAATCCAGAAGGCTTTGGGCTAAAGACATCGGTTTTCTATTTCAGGACTACGCCCTGGTAGATCGCATGAACGTCCGTTCGAATGTTTCTATGGGTGTTCCCCATTTGATAGGTAGACGAGGCTTGGATGATGGAATCAGCTCAGCGCTGGCGGGTGTGGGGCTGCCAGGATGTGGGGTGAACCCTACCTATCAGCTTTCAGGGGGTGAGCAGCAGCGTGTTGCTCTTGCTCGTCTTATGCTCAAGAGCCCGTCCCTAGTGCTTGCGGATGAGCCGACTGGTTCTCTCGACGCGTTGAATGAGGAGATGGTGTTGAAGCATCTTCGGTCATTTGCTAAGCAGGGATCCATGGTGGTTGTCGCGTCGCATAGCAACTCTGTTTTGGAGTGCTGTGACCAAGTGCTGGAGGTTGGCCTCCATTAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1712373,
                        "end": 1712579,
                        "strand": -1,
                        "locus_tag": "AAA_01678",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01678</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01678</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,712,373 - 1,712,579,\n (total: 207 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MFRISADNHARAPRTLFHERYEVTRTSALLNGHPSRPNKNMTVRDAVVSVGNFATGEGAEVKNVPAST&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1702373&amp;to=1722579\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MFRISADNHARAPRTLFHERYEVTRTSALLNGHPSRPNKNMTVRDAVVSVGNFATGEGAEVKNVPAST\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGTTCCGAATATCGGCAGATAACCATGCCCGCGCTCCACGAACGTTATTCCACGAACGTTATGAGGTGACGCGCACCAGTGCCCTGCTCAACGGCCACCCCAGCAGGCCGAACAAAAATATGACTGTACGCGACGCCGTGGTCTCGGTAGGCAACTTCGCGACAGGCGAAGGGGCTGAGGTCAAGAACGTGCCCGCGTCAACGTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1713148,
                        "end": 1713330,
                        "strand": -1,
                        "locus_tag": "AAA_01679",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01679</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01679</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,713,148 - 1,713,330,\n (total: 183 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MQLIAPADRLGLVGISLNMLYQDISNALLVELVENGLHTYQRSPLIQTTTPHTSRMSKKA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1703148&amp;to=1723330\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MQLIAPADRLGLVGISLNMLYQDISNALLVELVENGLHTYQRSPLIQTTTPHTSRMSKKA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCAACTGATCGCGCCTGCAGATCGGCTGGGCCTGGTCGGCATCAGCCTCAACATGCTGTACCAGGACATTTCGAATGCTCTGCTGGTCGAGCTCGTCGAGAACGGCTTACACACCTACCAGCGCTCTCCCTTGATCCAGACTACGACGCCACATACCAGCAGGATGTCAAAGAAGGCTTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1713397,
                        "end": 1713606,
                        "strand": -1,
                        "locus_tag": "AAA_01680",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01680</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01680</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,713,397 - 1,713,606,\n (total: 210 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLGEALRPSRADVVVTAYSLHGLSLDARLPDTFERKPHYPTTKDIDLVQMRADLDRVIASLHPNSNNGP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1703397&amp;to=1723606\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLGEALRPSRADVVVTAYSLHGLSLDARLPDTFERKPHYPTTKDIDLVQMRADLDRVIASLHPNSNNGP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTTGGCGAGGCCCTTCGCCCTTCCCGCGCAGACGTGGTAGTGACCGCTTACTCACTGCACGGGCTCTCACTCGACGCACGGCTGCCGGACACTTTCGAACGCAAGCCGCACTACCCGACGACGAAGGACATCGATCTGGTCCAAATGCGAGCCGACCTCGATCGAGTGATCGCGTCACTCCACCCCAATTCCAATAACGGGCCATAG\">Copy to clipboard</span><br>\n</div>"
                    }
                ],
                "clusters": [
                    {
                        "start": 1708546,
                        "end": 1708879,
                        "tool": "rule-based-clusters",
                        "neighbouring_start": 1703546,
                        "neighbouring_end": 1713879,
                        "product": "RiPP-like",
                        "height": 2,
                        "kind": "protocluster",
                        "prefix": ""
                    }
                ],
                "ttaCodons": [],
                "type": "RiPP-like",
                "products": [
                    "RiPP-like"
                ],
                "anchor": "r1c1"
            }
        ]
    },
    {
        "length": 77702,
        "seq_id": "CP017041.1",
        "regions": [
            {
                "start": 1,
                "end": 28236,
                "idx": 1,
                "orfs": [
                    {
                        "start": 2,
                        "end": 583,
                        "strand": -1,
                        "locus_tag": "AAA_02515",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02515</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02515</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2 - 583,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKTIGTRSKPSKSRLPGRVFNLIMADQVLSQSSYFALLPVLPLLLTLKFGSTQERLIAGSVSVLTLMTRGGALFLASPLHRLSVRSCVRIALTLISVSYAVVALTANPYAIIAALGAAGLGFSVNGTGVRSFIALATPDRASQNRGFAVIQVVANCTAAVGPILGNMILDRNIYEQFLLGVSVALFIAAILAPM&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=0&amp;to=10583\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKTIGTRSKPSKSRLPGRVFNLIMADQVLSQSSYFALLPVLPLLLTLKFGSTQERLIAGSVSVLTLMTRGGALFLASPLHRLSVRSCVRIALTLISVSYAVVALTANPYAIIAALGAAGLGFSVNGTGVRSFIALATPDRASQNRGFAVIQVVANCTAAVGPILGNMILDRNIYEQFLLGVSVALFIAAILAPM\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGAAGACAATAGGGACACGAAGTAAACCGTCGAAGTCTCGGCTTCCTGGGCGCGTATTCAACCTCATTATGGCAGACCAAGTTCTCAGCCAATCATCTTACTTTGCGTTGCTACCGGTCCTCCCTCTATTGCTTACATTGAAATTTGGAAGTACGCAGGAACGACTCATCGCGGGGTCGGTAAGCGTGCTTACACTGATGACTCGTGGTGGTGCTCTATTTCTTGCTTCGCCACTTCACCGTTTATCAGTGCGAAGTTGCGTAAGAATTGCTCTTACTCTGATCTCGGTTTCTTACGCTGTTGTGGCGCTTACGGCAAACCCCTATGCGATAATTGCTGCTCTGGGCGCTGCGGGCCTAGGGTTCAGTGTTAATGGTACTGGTGTGCGAAGCTTTATAGCGCTAGCAACTCCTGATAGAGCTTCCCAAAACCGCGGTTTCGCTGTCATTCAAGTTGTCGCGAATTGCACTGCGGCGGTAGGTCCTATTCTCGGTAATATGATACTTGATAGAAATATTTATGAGCAGTTTCTATTAGGAGTCAGTGTAGCGCTCTTTATCGCTGCGATATTAGCGCCAATG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1174,
                        "end": 2481,
                        "strand": -1,
                        "locus_tag": "AAA_02516",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02516</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02516</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,174 - 2,481,\n (total: 1308 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1063:argininosuccinate lyase/adenylosuccinate lyase (Score: 75.8; E-value: 5.9e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF13535.6 (ATP-grasp domain): [183:317](score: 42.6, e-value: 4.6e-11)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MFSRDSVVAERKWAVLVGVTTSGSHASTHWFKSFYEACQKRHIMICGVDFEEELKNKIPPISVDCLIRISGPYRRSLDADEIAKIATEIETRCPGKIALSTALRENYQLQNSLLAEAIGVARNTADCIERIQDKPACRDALRKAGIYQPQSLRIVGVTSDGCLQFSDASGAVVEKPTDSPRGWIVKPSIGMGSVGVRHILNVEDTSGLDAVVLEGNYCLEEFITGIEYSVEGIAIDGRVCIYTTTAKTTNEDFVEIGHIQPADLNSISSKLEFEEQLQSCVNALGIECGNLHVEFWVTPEKKIVWGEFHVRQGGDFIAPDLVSAVRPGIDYYGNLIDSLCGLPLHPLPEITQCAASKFIEASPGVVSEVSLYDSVPEEIDLYWECFPGEVAHAVNGSHARVAAIVARGNDEHTVTQLLDRAANACVVRVAPVSRD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=0&amp;to=12481\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_02516_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MFSRDSVVAERKWAVLVGVTTSGSHASTHWFKSFYEACQKRHIMICGVDFEEELKNKIPPISVDCLIRISGPYRRSLDADEIAKIATEIETRCPGKIALSTALRENYQLQNSLLAEAIGVARNTADCIERIQDKPACRDALRKAGIYQPQSLRIVGVTSDGCLQFSDASGAVVEKPTDSPRGWIVKPSIGMGSVGVRHILNVEDTSGLDAVVLEGNYCLEEFITGIEYSVEGIAIDGRVCIYTTTAKTTNEDFVEIGHIQPADLNSISSKLEFEEQLQSCVNALGIECGNLHVEFWVTPEKKIVWGEFHVRQGGDFIAPDLVSAVRPGIDYYGNLIDSLCGLPLHPLPEITQCAASKFIEASPGVVSEVSLYDSVPEEIDLYWECFPGEVAHAVNGSHARVAAIVARGNDEHTVTQLLDRAANACVVRVAPVSRD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTTTTCTCGTGACAGCGTAGTGGCTGAAAGAAAATGGGCGGTTTTGGTAGGTGTCACCACATCTGGATCTCATGCCTCAACGCATTGGTTTAAAAGCTTCTATGAAGCGTGCCAGAAGCGCCACATAATGATATGTGGCGTAGATTTCGAGGAAGAACTAAAGAACAAAATTCCGCCGATTTCTGTCGATTGTTTAATTAGAATATCCGGACCCTACAGGAGAAGCTTAGATGCTGATGAGATCGCTAAAATAGCGACAGAAATTGAAACCCGATGCCCTGGAAAGATAGCTCTTTCAACGGCACTGCGCGAAAATTATCAGTTGCAGAATAGTCTTTTAGCTGAAGCTATTGGTGTTGCTAGAAATACTGCTGATTGTATTGAACGTATCCAAGATAAACCAGCGTGCCGCGATGCGCTTCGAAAAGCTGGTATCTATCAGCCACAAAGCTTGCGTATTGTTGGAGTGACTTCTGATGGGTGCCTACAATTTAGTGATGCATCAGGCGCTGTCGTTGAAAAACCAACCGATAGCCCAAGAGGCTGGATTGTTAAGCCATCCATAGGAATGGGCAGTGTTGGCGTTAGACACATCTTAAATGTTGAAGATACTTCTGGACTTGATGCTGTCGTTCTCGAGGGGAATTACTGCTTAGAAGAGTTTATCACGGGTATTGAGTACTCAGTTGAGGGTATTGCTATAGATGGACGGGTATGCATCTACACAACCACAGCAAAAACAACCAACGAAGATTTCGTTGAAATTGGTCATATCCAGCCAGCTGATCTGAACAGTATATCCAGCAAACTTGAATTTGAAGAACAGCTTCAAAGCTGTGTAAATGCGCTTGGAATTGAGTGTGGAAATCTGCATGTTGAATTTTGGGTCACACCTGAGAAAAAAATTGTATGGGGAGAATTTCACGTGCGTCAAGGTGGAGATTTTATTGCGCCGGATCTTGTGTCAGCTGTGCGACCAGGGATCGACTACTATGGAAATCTGATTGATTCTTTGTGTGGACTTCCTCTCCATCCTTTGCCTGAGATAACCCAGTGTGCTGCTTCAAAGTTTATCGAAGCCTCGCCTGGAGTGGTATCAGAGGTTTCGCTCTATGACAGTGTCCCTGAAGAAATCGATTTGTATTGGGAATGCTTCCCAGGAGAAGTAGCACATGCAGTAAATGGTTCGCATGCAAGGGTAGCTGCTATTGTTGCCCGTGGTAATGACGAGCATACAGTGACTCAGTTATTGGATCGCGCTGCTAATGCTTGCGTAGTGCGTGTCGCTCCTGTAAGCAGAGATTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 2468,
                        "end": 3181,
                        "strand": -1,
                        "locus_tag": "AAA_02517",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02517</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02517</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,468 - 3,181,\n (total: 714 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1004:thioesterase (Score: 94; E-value: 1.3e-28)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00975.20 (Thioesterase domain): [18:221](score: 45.8, e-value: 7.7e-12)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNPEVWQRISSATTSCCSTVLIFPPTGAGAPAFQSMSVLEGDTTVWGYCPPGRGQRLLEPGIRTMGEFVSKFRSSFEIPTGPLILAGVSFGAMLSFVAANILENDGIFATRLVALCGQSPKSYRGEREGWNLERARQRMRSYGLTPKSILNSDESDDLFVRPTLDDLLLAESCCGNQLKQIHVPITCVSAIDDKIVSSEEAVQWREATSETYRLIEVTGGHYAHEGFGRREWLNVFS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=0&amp;to=13181\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNPEVWQRISSATTSCCSTVLIFPPTGAGAPAFQSMSVLEGDTTVWGYCPPGRGQRLLEPGIRTMGEFVSKFRSSFEIPTGPLILAGVSFGAMLSFVAANILENDGIFATRLVALCGQSPKSYRGEREGWNLERARQRMRSYGLTPKSILNSDESDDLFVRPTLDDLLLAESCCGNQLKQIHVPITCVSAIDDKIVSSEEAVQWREATSETYRLIEVTGGHYAHEGFGRREWLNVFS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"TTGAATCCGGAAGTTTGGCAGCGTATTAGTTCAGCAACTACCTCTTGTTGCTCCACAGTCCTGATATTCCCTCCTACGGGTGCCGGAGCTCCTGCCTTTCAATCGATGTCTGTCTTAGAGGGGGATACTACAGTTTGGGGTTACTGCCCGCCTGGCAGGGGTCAACGATTACTTGAACCCGGCATCAGAACCATGGGAGAGTTCGTCAGCAAGTTTCGATCATCCTTCGAAATTCCGACTGGGCCGTTGATACTCGCCGGGGTTAGCTTTGGCGCGATGTTGTCGTTCGTAGCTGCTAATATTTTAGAAAATGACGGAATTTTCGCGACTCGTTTGGTTGCCTTATGTGGGCAAAGTCCTAAGAGTTACAGGGGGGAGCGAGAGGGATGGAACTTGGAACGTGCACGGCAGCGTATGCGTAGCTACGGATTGACTCCTAAAAGTATTCTGAACTCCGATGAATCCGATGATCTGTTTGTTCGCCCTACGCTCGATGATCTCTTACTGGCGGAATCGTGTTGTGGTAACCAACTTAAGCAGATTCATGTCCCTATAACCTGTGTTTCCGCTATTGATGATAAGATTGTTTCTTCCGAAGAGGCCGTCCAATGGCGTGAAGCTACGAGTGAGACGTACAGATTGATCGAAGTGACCGGAGGGCATTATGCACATGAAGGTTTTGGAAGAAGGGAATGGTTAAATGTTTTCTCGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 3178,
                        "end": 4917,
                        "strand": -1,
                        "locus_tag": "AAA_02518",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02518</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02518</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,178 - 4,917,\n (total: 1740 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 166.1; E-value: 1.6e-50)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00501.28 (AMP-binding enzyme): [103:395](score: 148.0, e-value: 2.9e-43)<br>\n \n  PF00550.25 (Phosphopantetheine attachment site): [506:569](score: 45.4, e-value: 7.6e-12)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MQPSHDLLEGFRNIVIQKPGDVCLTGPAGEQCSWEQLVKNILAWRRWFNREQSEGVTFAARLDLSAKSVALVIAAVTLPVKIAWIPLNIPASRERDMIINLGSKTVLIDDSTAEEAIFAGNWISDVRSLTWSDKSKFLYFTSGSEGVPKAVQVGMDAVRNRITWMWNAYPYESSDLVVVQKPLSFVASFWEVLGTLLAGVTGVLITNIERSRPDVMFDRLASSGATHLFTTPPALASLCDIATEQGSTLPQLRLACSSADQLMASVVRQFFEIAPRARVVNLYGATETSANTTSFEVSRSGSIPDPIPLGEPICATKIVIRDMKGNEKLSGEEGQICVQGAPVADGYIVNGQLSPGDDAFFTLGSGQREIRTGDLGIIKDGVLSLVGRLDNAVNIAGHKIHLEEVERAAARVANSTKQCGAVYHQGSGGFLALVIPREWESQVTTSRLAEFLPSYMIPLKIVTTQNVPRSRTGKIDRCECLKLVAQSELYDHDRISQGQMQRNSVHDQVQNIWDMVLGKKIHGEDRDFFSAGGNSLRAVQLLTAIGKQFGVRVPLRNFYSNPTISCLVSLLMPVEEREH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=0&amp;to=14917\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_02518_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MQPSHDLLEGFRNIVIQKPGDVCLTGPAGEQCSWEQLVKNILAWRRWFNREQSEGVTFAARLDLSAKSVALVIAAVTLPVKIAWIPLNIPASRERDMIINLGSKTVLIDDSTAEEAIFAGNWISDVRSLTWSDKSKFLYFTSGSEGVPKAVQVGMDAVRNRITWMWNAYPYESSDLVVVQKPLSFVASFWEVLGTLLAGVTGVLITNIERSRPDVMFDRLASSGATHLFTTPPALASLCDIATEQGSTLPQLRLACSSADQLMASVVRQFFEIAPRARVVNLYGATETSANTTSFEVSRSGSIPDPIPLGEPICATKIVIRDMKGNEKLSGEEGQICVQGAPVADGYIVNGQLSPGDDAFFTLGSGQREIRTGDLGIIKDGVLSLVGRLDNAVNIAGHKIHLEEVERAAARVANSTKQCGAVYHQGSGGFLALVIPREWESQVTTSRLAEFLPSYMIPLKIVTTQNVPRSRTGKIDRCECLKLVAQSELYDHDRISQGQMQRNSVHDQVQNIWDMVLGKKIHGEDRDFFSAGGNSLRAVQLLTAIGKQFGVRVPLRNFYSNPTISCLVSLLMPVEEREH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCAACCGTCACATGATTTGCTGGAGGGGTTTCGTAATATAGTCATTCAGAAACCAGGTGATGTCTGTCTGACCGGTCCCGCCGGCGAGCAATGCTCATGGGAACAGCTAGTTAAAAATATCCTTGCGTGGAGAAGGTGGTTCAACCGAGAACAAAGTGAGGGCGTTACTTTTGCTGCTCGACTCGATTTATCCGCCAAATCTGTTGCCCTTGTAATAGCAGCTGTGACGTTGCCTGTCAAGATTGCTTGGATTCCGTTGAATATTCCGGCTTCACGAGAGCGGGACATGATTATTAATCTTGGGTCTAAAACGGTTCTGATCGACGACTCAACAGCGGAAGAAGCAATTTTTGCAGGGAACTGGATAAGTGATGTCAGGTCCTTGACCTGGAGCGATAAATCAAAATTCTTATATTTCACATCTGGATCAGAAGGAGTTCCGAAAGCCGTCCAAGTAGGAATGGATGCGGTGCGGAACCGTATCACGTGGATGTGGAACGCCTACCCTTACGAGTCAAGCGATCTTGTGGTCGTCCAGAAGCCACTCTCATTTGTTGCTTCATTTTGGGAAGTGTTGGGGACTCTGCTGGCAGGTGTTACTGGTGTTTTGATTACTAATATCGAGCGTAGCAGACCTGACGTGATGTTCGATCGACTTGCGTCTAGTGGTGCTACCCACCTTTTTACGACACCTCCAGCACTAGCCAGCTTGTGTGACATTGCCACAGAGCAAGGGAGCACTCTTCCTCAGCTCCGTCTAGCGTGCAGCAGTGCAGACCAGCTGATGGCAAGCGTTGTCCGTCAATTCTTCGAGATCGCGCCCCGTGCGCGAGTAGTGAATCTTTACGGAGCTACTGAGACGTCGGCTAACACAACAAGTTTCGAGGTTTCTCGGTCAGGTAGCATTCCGGACCCTATCCCCCTTGGCGAGCCGATCTGTGCTACGAAAATTGTAATTCGGGACATGAAAGGTAACGAAAAGTTATCTGGGGAAGAGGGACAGATATGCGTACAGGGTGCCCCAGTGGCCGATGGATATATCGTTAATGGTCAACTCAGTCCAGGGGACGATGCGTTCTTTACACTTGGAAGTGGACAACGTGAAATACGGACTGGTGATCTGGGAATCATCAAGGATGGTGTCCTTTCACTGGTTGGCAGGCTCGATAATGCGGTAAATATCGCTGGACACAAGATCCACTTGGAAGAGGTTGAAAGAGCTGCAGCTCGAGTTGCTAACTCCACGAAACAATGTGGTGCAGTTTATCACCAAGGCAGTGGTGGATTTTTGGCGCTCGTGATTCCACGCGAATGGGAGTCTCAGGTCACGACTTCTCGTCTTGCCGAATTTCTACCTTCCTATATGATTCCTCTCAAGATCGTAACTACGCAGAATGTTCCTAGATCAAGAACGGGAAAAATAGATCGGTGCGAGTGCCTGAAATTGGTAGCACAGAGCGAACTCTACGATCACGACAGAATATCCCAAGGACAAATGCAGCGTAACAGTGTTCACGATCAAGTGCAAAATATCTGGGATATGGTCCTTGGAAAGAAGATCCACGGTGAAGATCGTGATTTTTTCTCCGCAGGTGGAAATTCGTTGCGCGCTGTTCAGCTTTTGACCGCCATCGGTAAACAGTTTGGTGTTCGTGTCCCCTTGCGGAACTTCTATTCCAATCCAACGATTTCCTGCTTGGTCAGCTTGCTGATGCCTGTTGAGGAGCGTGAGCATTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 4940,
                        "end": 8236,
                        "strand": -1,
                        "locus_tag": "AAA_02519",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02519</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02519</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,940 - 8,236,\n (total: 3297 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS: Condensation<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 263.9; E-value: 3.9e-80)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00501.28 (AMP-binding enzyme): [40:427](score: 214.8, e-value: 1.6e-63)<br>\n \n  PF00550.25 (Phosphopantetheine attachment site): [568:624](score: 23.8, e-value: 4.3e-05)<br>\n \n  PF00668.20 (Condensation domain): [656:1045](score: 124.4, e-value: 4.9e-36)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MINLTKSLEKNGLSLLATRSALVGENVDWPLERTLYSYLVEWAQITSHHVAVIDIHGEEITYEMLLNRVNNRAYLLEKKHAFGRVVISEHSRGIECLVDILACSAVGAIYTPIDPQWPEARRKHIKTITNAVAIFTENTSHVTEAKAPLGVTFLERVDDPFNAPSYCFFTSGSTGEPKGALIAHMGMMNHLHSKAHLLHLGVDSVVAQTAPTTFDVSIWQFCSALLVGGAVRIVPNGISQDPHELFSLLEEKHITHIELVPTVFRELIHEIGSSVSFSGLEYVLVTGEELPLRLARDWADKFPFVPLINAYGPTECSDDVTHAIVDGESLNSGEVPIGIPIPNTSLYVLEYAEGTWRPVSPGAQGELFVAGLCVGLGYIGSPDKTAQAFARIDGYPFRIYRTGDLVHQRADGQLVYDGRADRQIKISGVRIEPGEIENRILREIPELEDVVVVKFHPRVRERRAMVLRETTHQFLRQGDASLAAFYLPRADCLVTPKMLNNRAKSSLPRVMCPSRWIEVTDIPTTSNGKVDIKLLERRAGELLLNEIQESREGSIPGRVEQNQDSFILLVQDVLGTPVNPELTFIESGGDSLRAIQLANIVRSRGSYVRVRDLLSSYTLGSLAKEYQAQQISPKKSTSAKRSPSRFDDVKIPLTCDMNPAQQGIYFQWLLEPESPYYNYQILLECAGSNTDRIRRALGQALRANPQLMAKFGVDSTGRFTQTFPISAIDMDEISIHEVASAQEAREICWMKAAVPFNLEEGPAIAVDEIRINGYSTWFVLTMNEILIDGWGAMKFMEQLISLFECRNMDDQEIEVKTAMTSALEYFQHLSKPEEISAEAREFWSKSLDGVKSCFPLRDTLNSSCDPYAASVIEVSLDDEATAEIRSTAHALSTSPFAVFVAAYSLALAAVSDQHDFVVGAPVAGRNDEYEIGVPTLMLNMIAIRTRIDVEKKISDTVRSMISNVTEAVSFGDSVFSKVVSEFADHTNEDPLFSTMVNMLTYPSLEFWDGDRSLHLTELNTGFTKYDASLYIQRHGEDYTLQLAYKVAYVTPERANKVLALTAWFLTSDWLSGKTTVANAIKTALNDCDTSQITMLKSY&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=0&amp;to=18236\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_02519_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MINLTKSLEKNGLSLLATRSALVGENVDWPLERTLYSYLVEWAQITSHHVAVIDIHGEEITYEMLLNRVNNRAYLLEKKHAFGRVVISEHSRGIECLVDILACSAVGAIYTPIDPQWPEARRKHIKTITNAVAIFTENTSHVTEAKAPLGVTFLERVDDPFNAPSYCFFTSGSTGEPKGALIAHMGMMNHLHSKAHLLHLGVDSVVAQTAPTTFDVSIWQFCSALLVGGAVRIVPNGISQDPHELFSLLEEKHITHIELVPTVFRELIHEIGSSVSFSGLEYVLVTGEELPLRLARDWADKFPFVPLINAYGPTECSDDVTHAIVDGESLNSGEVPIGIPIPNTSLYVLEYAEGTWRPVSPGAQGELFVAGLCVGLGYIGSPDKTAQAFARIDGYPFRIYRTGDLVHQRADGQLVYDGRADRQIKISGVRIEPGEIENRILREIPELEDVVVVKFHPRVRERRAMVLRETTHQFLRQGDASLAAFYLPRADCLVTPKMLNNRAKSSLPRVMCPSRWIEVTDIPTTSNGKVDIKLLERRAGELLLNEIQESREGSIPGRVEQNQDSFILLVQDVLGTPVNPELTFIESGGDSLRAIQLANIVRSRGSYVRVRDLLSSYTLGSLAKEYQAQQISPKKSTSAKRSPSRFDDVKIPLTCDMNPAQQGIYFQWLLEPESPYYNYQILLECAGSNTDRIRRALGQALRANPQLMAKFGVDSTGRFTQTFPISAIDMDEISIHEVASAQEAREICWMKAAVPFNLEEGPAIAVDEIRINGYSTWFVLTMNEILIDGWGAMKFMEQLISLFECRNMDDQEIEVKTAMTSALEYFQHLSKPEEISAEAREFWSKSLDGVKSCFPLRDTLNSSCDPYAASVIEVSLDDEATAEIRSTAHALSTSPFAVFVAAYSLALAAVSDQHDFVVGAPVAGRNDEYEIGVPTLMLNMIAIRTRIDVEKKISDTVRSMISNVTEAVSFGDSVFSKVVSEFADHTNEDPLFSTMVNMLTYPSLEFWDGDRSLHLTELNTGFTKYDASLYIQRHGEDYTLQLAYKVAYVTPERANKVLALTAWFLTSDWLSGKTTVANAIKTALNDCDTSQITMLKSY\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGATAAACCTTACCAAAAGTTTGGAAAAAAATGGGTTGAGCTTGCTCGCTACCCGGAGTGCACTGGTCGGGGAAAACGTCGACTGGCCTTTAGAACGCACACTCTACTCGTATTTAGTTGAATGGGCCCAGATCACTTCACATCACGTTGCCGTAATAGATATTCATGGTGAAGAAATCACCTACGAAATGTTATTGAATCGAGTTAACAATCGAGCCTATCTCTTGGAAAAGAAACATGCCTTTGGAAGAGTAGTCATTTCAGAGCACTCGCGCGGTATCGAATGTCTTGTCGATATCCTAGCTTGTAGTGCCGTAGGTGCCATCTATACACCCATTGATCCTCAGTGGCCAGAGGCTCGTCGTAAACATATTAAGACAATCACGAACGCGGTCGCCATTTTCACTGAAAATACCTCGCACGTAACGGAAGCAAAGGCACCATTAGGAGTCACATTTCTGGAGCGTGTGGATGATCCTTTCAACGCTCCAAGCTACTGCTTTTTCACCTCGGGTAGCACAGGTGAACCGAAAGGTGCGCTAATCGCGCATATGGGCATGATGAATCACTTGCATAGCAAAGCCCATCTCCTTCATCTTGGTGTTGACTCAGTTGTGGCCCAGACGGCACCTACCACCTTTGATGTATCCATTTGGCAATTTTGTTCAGCTTTACTGGTAGGCGGTGCAGTACGTATCGTCCCCAACGGTATTTCACAGGATCCACATGAGCTTTTTTCTTTACTGGAAGAGAAACATATAACACACATTGAACTAGTTCCGACAGTATTTCGTGAACTTATTCACGAAATTGGGTCAAGCGTGTCTTTCTCTGGGCTTGAGTATGTTCTGGTGACTGGTGAAGAATTACCCCTTCGGTTGGCTAGAGACTGGGCAGACAAATTTCCGTTTGTCCCGTTGATTAATGCGTATGGTCCTACGGAATGTTCTGATGATGTAACGCATGCGATCGTGGATGGCGAATCGCTTAACTCAGGTGAAGTTCCCATCGGAATTCCAATACCTAATACGTCTTTATACGTCCTAGAGTACGCAGAAGGTACTTGGCGTCCAGTTTCTCCTGGAGCGCAAGGCGAGCTTTTTGTTGCTGGTCTTTGTGTGGGTTTAGGTTATATCGGAAGCCCAGATAAAACCGCTCAAGCATTTGCCAGGATTGATGGATACCCATTCCGAATATACCGCACCGGAGATCTCGTTCACCAGCGAGCGGATGGTCAGCTGGTTTACGATGGCCGCGCTGATCGACAGATAAAAATTAGTGGAGTACGGATTGAGCCCGGTGAAATCGAGAACCGTATCCTTCGAGAAATCCCAGAGCTTGAAGACGTTGTAGTGGTTAAATTCCACCCTCGTGTCCGTGAACGTCGCGCAATGGTGCTCCGAGAAACGACGCACCAGTTTCTTCGCCAAGGAGACGCTAGCTTGGCCGCATTCTATCTTCCTCGCGCCGATTGTTTAGTTACTCCCAAAATGCTTAATAATCGCGCGAAAAGCAGTCTCCCTAGAGTGATGTGTCCATCCCGTTGGATAGAGGTTACTGATATTCCCACTACTTCAAATGGCAAGGTAGATATTAAGTTATTAGAGCGCCGTGCCGGGGAACTGTTACTGAATGAAATTCAAGAGTCAAGAGAGGGATCCATTCCCGGTAGAGTTGAACAGAATCAGGACTCTTTCATTCTTCTCGTTCAGGACGTGCTTGGCACTCCTGTGAATCCAGAACTAACATTCATCGAATCCGGAGGCGATTCTCTTCGAGCAATTCAGCTAGCCAATATTGTCCGCTCACGAGGATCTTACGTAAGAGTACGAGATTTGCTTTCTTCATATACGTTAGGCTCTCTAGCAAAAGAATATCAAGCACAACAGATATCTCCGAAGAAATCGACCTCTGCAAAAAGATCTCCTTCCCGCTTTGATGACGTCAAAATTCCTTTGACTTGTGATATGAATCCGGCTCAGCAAGGAATTTATTTTCAATGGCTACTGGAGCCTGAAAGCCCTTACTATAATTATCAGATATTGTTAGAATGCGCTGGGTCGAACACCGATAGAATCCGTCGTGCTCTTGGCCAGGCATTACGGGCGAATCCACAGCTAATGGCGAAGTTTGGAGTGGATTCAACTGGGAGATTTACACAGACGTTTCCTATCTCTGCTATCGATATGGATGAAATCTCAATACACGAAGTGGCCTCTGCGCAAGAGGCTCGTGAGATCTGTTGGATGAAAGCAGCAGTCCCTTTTAACCTGGAGGAAGGTCCCGCTATCGCCGTGGACGAGATCCGTATAAATGGATATTCTACCTGGTTCGTTTTGACCATGAACGAGATCCTTATCGATGGCTGGGGAGCAATGAAGTTCATGGAACAGTTAATTTCTCTTTTTGAGTGTCGTAACATGGACGATCAGGAGATCGAAGTCAAGACAGCTATGACTTCAGCTCTGGAATATTTCCAACATCTGTCGAAACCTGAAGAGATATCCGCTGAAGCACGAGAATTTTGGTCAAAATCACTCGATGGAGTGAAATCATGTTTCCCATTGCGCGATACATTAAATAGTTCGTGTGATCCCTACGCTGCTTCTGTTATAGAGGTCTCTCTAGATGACGAAGCGACTGCTGAGATCCGTTCCACTGCGCATGCATTGAGTACAAGCCCATTTGCAGTATTCGTGGCTGCTTATTCGTTAGCGTTGGCAGCGGTCTCTGACCAACATGATTTTGTTGTCGGTGCACCAGTAGCAGGGCGAAACGATGAGTATGAAATTGGCGTCCCAACTCTGATGCTTAACATGATTGCAATACGAACTCGTATAGATGTCGAAAAGAAAATTAGTGACACAGTACGTTCGATGATATCTAATGTGACTGAAGCTGTCTCATTCGGTGACAGCGTATTTAGCAAGGTTGTTTCTGAGTTCGCTGATCACACGAACGAGGATCCATTGTTTAGCACGATGGTGAATATGCTTACTTACCCGTCTCTGGAGTTTTGGGATGGTGATCGAAGCCTTCACTTAACTGAATTGAATACTGGGTTTACGAAATATGATGCGTCTCTTTATATCCAGCGACACGGCGAAGATTATACCTTGCAACTTGCTTATAAAGTGGCGTATGTGACACCAGAACGCGCTAATAAAGTACTGGCTCTTACAGCGTGGTTCCTTACCTCTGATTGGCTCTCGGGGAAGACGACTGTCGCTAATGCCATAAAAACTGCCCTTAATGATTGTGATACATCTCAGATAACAATGCTCAAAAGCTATTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 8244,
                        "end": 9233,
                        "strand": -1,
                        "locus_tag": "AAA_02520",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02520</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02520</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,244 - 9,233,\n (total: 990 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1158:ornithine cyclodeaminase (Score: 360.4; E-value: 1.1e-109)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF02423.15 (Ornithine cyclodeaminase/mu-crystallin family): [25:312](score: 91.2, e-value: 5.5e-26)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTKYGEMLIIDAKLVETFLKGRESFLIDLVERVYRAHHAGNTVCPDSYFLRFPDAPRDRIIALPSYINDQTCVSGIKWISSFPENVDHGLQRASAVIVLNNTDNGYAYAFIEASRISAARTAASAALAVRVLHGAPTSIGVVGSGPIAQTTLHFIKSLYTTAVPVKIHDLNSELVARIVTRHGPECSVVSLEEALGCDLVLLATSAGTPYVPMSVRFQPNQLVLNISLRDLHPETIRTANNVFDDVEHCLKANTTPHLLEQLNGNRNFITGTLAEFICSEKQLDPDHPTVFSPFGLGILDLAVAQSLYEHVQISGDGLRVPDFHGDMKR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=0&amp;to=19233\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_02520_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTKYGEMLIIDAKLVETFLKGRESFLIDLVERVYRAHHAGNTVCPDSYFLRFPDAPRDRIIALPSYINDQTCVSGIKWISSFPENVDHGLQRASAVIVLNNTDNGYAYAFIEASRISAARTAASAALAVRVLHGAPTSIGVVGSGPIAQTTLHFIKSLYTTAVPVKIHDLNSELVARIVTRHGPECSVVSLEEALGCDLVLLATSAGTPYVPMSVRFQPNQLVLNISLRDLHPETIRTANNVFDDVEHCLKANTTPHLLEQLNGNRNFITGTLAEFICSEKQLDPDHPTVFSPFGLGILDLAVAQSLYEHVQISGDGLRVPDFHGDMKR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGAAATATGGTGAAATGCTAATTATAGACGCCAAGCTTGTCGAAACATTTTTAAAAGGCAGAGAGTCGTTTCTCATCGATCTTGTTGAACGTGTTTATCGAGCACATCACGCTGGAAATACAGTATGTCCCGATAGTTATTTTCTTCGGTTTCCAGATGCTCCACGAGATCGTATCATAGCGTTGCCATCTTATATCAATGATCAAACCTGTGTGTCGGGAATTAAATGGATTTCTAGCTTTCCTGAGAATGTTGATCATGGGCTACAAAGAGCTTCAGCAGTCATCGTGCTAAATAACACAGATAACGGCTATGCTTATGCGTTCATCGAGGCCAGCCGCATTAGTGCGGCTCGTACAGCTGCCTCGGCTGCGCTTGCAGTTCGAGTTCTTCACGGTGCTCCTACGAGTATCGGTGTAGTAGGCAGTGGCCCTATCGCACAGACAACTTTACATTTTATTAAGTCGCTATACACGACAGCGGTTCCAGTGAAAATTCACGATTTAAATAGTGAATTAGTCGCACGTATAGTCACTCGCCACGGCCCCGAGTGTTCGGTAGTCAGTTTAGAAGAAGCTCTTGGCTGTGATCTCGTGCTATTAGCCACCAGCGCCGGAACTCCTTATGTGCCGATGAGTGTACGTTTCCAACCGAACCAGCTCGTTCTCAATATCTCGCTTCGTGATTTACACCCTGAGACCATTCGAACGGCTAATAACGTGTTTGATGATGTTGAACATTGCCTGAAGGCAAACACTACACCCCACCTCCTCGAACAATTGAACGGAAATCGAAATTTCATCACAGGCACACTGGCGGAATTCATATGCTCTGAGAAGCAGCTTGACCCTGATCATCCAACCGTATTCTCTCCTTTTGGTTTAGGAATTTTGGACCTTGCTGTTGCTCAAAGCTTGTACGAGCACGTTCAAATATCCGGCGATGGATTACGTGTTCCAGACTTTCACGGAGACATGAAACGGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 9234,
                        "end": 10235,
                        "strand": -1,
                        "locus_tag": "AAA_02521",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02521</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02521</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,234 - 10,235,\n (total: 1002 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1081:cysteine synthase (Score: 324; E-value: 1.3e-98)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00291.25 (Pyridoxal-phosphate dependent enzyme): [11:291](score: 166.3, e-value: 9.7e-49)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIAGSIEELDENSQFVRLKNSFPKHDVYAKLEGLNTAGSVKLKTAIALVDSLEKLHGLQPGGWVVESSSGSLGIALSGVCARRGYKLTIVTDLNANSRSISHMRALGAEVEVVQSLDAAGGFLGTRLARVRELVEMPGGPLWTNQYENVANPEVHSKKTYRAIVEELGDPDYLFVGAGTTGTLMGVSRAVMKRGSCTKVYAIDSTGSVTFGGAPSRRYIPGLGASVKPPIFDEKFPLKRYYIDEIDTVRQCRRIAQVEGFLPGGSTGTVLAAFDALRDKIPEGSRVVIIAPDLGERYLDGVYNDDWVMENFGESAFNYAIRPVAHEVKETEGI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=0&amp;to=20235\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_02521_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIAGSIEELDENSQFVRLKNSFPKHDVYAKLEGLNTAGSVKLKTAIALVDSLEKLHGLQPGGWVVESSSGSLGIALSGVCARRGYKLTIVTDLNANSRSISHMRALGAEVEVVQSLDAAGGFLGTRLARVRELVEMPGGPLWTNQYENVANPEVHSKKTYRAIVEELGDPDYLFVGAGTTGTLMGVSRAVMKRGSCTKVYAIDSTGSVTFGGAPSRRYIPGLGASVKPPIFDEKFPLKRYYIDEIDTVRQCRRIAQVEGFLPGGSTGTVLAAFDALRDKIPEGSRVVIIAPDLGERYLDGVYNDDWVMENFGESAFNYAIRPVAHEVKETEGI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATTGCAGGATCTATTGAAGAACTAGATGAAAACTCTCAATTTGTCCGCTTGAAAAATTCATTTCCTAAACATGATGTTTACGCAAAATTAGAAGGTTTAAACACTGCTGGTTCCGTAAAACTCAAGACGGCTATTGCACTCGTCGATAGCTTAGAAAAGCTTCATGGTCTTCAGCCAGGAGGTTGGGTCGTAGAGTCTTCTTCTGGGAGTTTAGGCATAGCACTTTCCGGTGTATGTGCGCGCCGAGGATACAAATTAACAATTGTTACAGATCTGAATGCAAATTCAAGGTCGATTTCGCATATGCGTGCACTGGGCGCGGAAGTGGAAGTTGTTCAATCATTGGATGCAGCGGGCGGATTTCTTGGGACGCGACTTGCTAGAGTTCGCGAATTAGTAGAGATGCCAGGAGGGCCTTTATGGACAAACCAGTACGAAAATGTAGCCAATCCTGAGGTTCATTCCAAAAAGACATATAGAGCGATCGTCGAAGAGTTAGGAGATCCTGATTACCTATTTGTAGGTGCTGGTACCACTGGCACGCTTATGGGTGTATCTAGGGCTGTCATGAAGCGTGGTTCATGCACCAAAGTTTATGCTATTGATAGCACTGGTTCAGTGACTTTCGGAGGAGCTCCTTCGCGGCGATATATCCCTGGTCTAGGCGCTAGTGTAAAGCCACCAATCTTTGACGAAAAATTTCCTCTAAAACGGTATTATATTGATGAAATCGATACCGTGAGACAGTGCCGACGCATTGCGCAGGTAGAAGGATTTTTACCGGGTGGATCGACTGGCACTGTGCTAGCAGCTTTTGATGCTCTTCGAGATAAAATTCCCGAGGGAAGCCGCGTTGTCATTATTGCGCCGGATCTTGGTGAAAGGTATCTGGATGGAGTATATAACGACGATTGGGTTATGGAAAACTTTGGGGAATCAGCATTTAATTATGCCATTCGTCCTGTTGCGCACGAAGTGAAAGAAACGGAAGGTATTTAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 10232,
                        "end": 10369,
                        "strand": -1,
                        "locus_tag": "AAA_02522",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02522</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02522</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,232 - 10,369,\n (total: 138 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIKILNFLPKPLLITPIACTRLLIIICLYVMKTSDVMSCAVGANK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=232&amp;to=20369\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIKILNFLPKPLLITPIACTRLLIIICLYVMKTSDVMSCAVGANK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATCAAGATCCTTAACTTCTTGCCTAAACCTCTTCTAATAACGCCCATAGCCTGTACAAGACTCCTCATTATAATTTGCTTGTATGTTATGAAAACTTCCGATGTCATGTCATGCGCAGTAGGAGCAAATAAATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 10627,
                        "end": 11250,
                        "strand": 1,
                        "locus_tag": "AAA_02523",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02523</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02523</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,627 - 11,250,\n (total: 624 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1012:4&#39;-phosphopantetheinyl transferase (Score: 113.9; E-value: 1.1e-34)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01648.20 (4&#39;-phosphopantetheinyl transferase superfamily): [66:167](score: 43.7, e-value: 2.4e-11)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRIDDCLRCLIADELRAYSLKLDYKVPVQSEVSKNAFGKPLLANRDGPKFNLSHDGKWIVCATSPHPVGVDVEAVAEPGLAVVSNDFSVEEVEALRTTATAPLSIARAMIWTRKEAYLKYLGLGLTVQLDSFSVIDQTLLSPAEGMTDGIQFYSWCDADNSHVISVCGHGEEVVISCVSGQELLDGLPPSHCSEEPQEQLRWLPNLS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=627&amp;to=21250\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_02523_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRIDDCLRCLIADELRAYSLKLDYKVPVQSEVSKNAFGKPLLANRDGPKFNLSHDGKWIVCATSPHPVGVDVEAVAEPGLAVVSNDFSVEEVEALRTTATAPLSIARAMIWTRKEAYLKYLGLGLTVQLDSFSVIDQTLLSPAEGMTDGIQFYSWCDADNSHVISVCGHGEEVVISCVSGQELLDGLPPSHCSEEPQEQLRWLPNLS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCGAATCGATGACTGCTTGCGCTGCCTCATAGCTGACGAACTCCGGGCCTATTCATTGAAGCTTGATTACAAGGTGCCAGTACAGTCAGAGGTATCGAAGAACGCTTTCGGGAAGCCGCTACTAGCAAACCGCGATGGTCCTAAGTTCAACTTGTCGCACGATGGGAAGTGGATTGTCTGTGCCACAAGCCCACATCCTGTAGGCGTAGACGTCGAGGCAGTCGCTGAGCCAGGTTTAGCGGTGGTCTCGAACGATTTTTCAGTGGAAGAAGTGGAGGCCTTGCGGACGACCGCTACGGCTCCCCTCTCCATCGCTCGAGCGATGATCTGGACACGGAAGGAGGCATACCTCAAATATCTGGGGTTGGGTCTCACTGTTCAGTTAGATTCTTTTTCAGTAATAGATCAAACCTTGCTGTCGCCAGCTGAAGGGATGACAGACGGTATTCAGTTTTATAGTTGGTGCGATGCCGATAACTCGCATGTGATCTCTGTCTGTGGCCACGGCGAGGAAGTCGTCATCTCTTGCGTCAGCGGGCAAGAATTACTAGATGGACTGCCACCATCTCACTGTTCAGAAGAACCTCAAGAGCAACTTCGTTGGTTGCCCAATCTTAGTTAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 11350,
                        "end": 12051,
                        "strand": -1,
                        "locus_tag": "AAA_02524",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02524</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02524</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,350 - 12,051,\n (total: 702 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKLMKISSSCELSSYLPLNQLVWHEECETLRLKRLTKLLEHEALRESIHVAQGAPYIILDGAHRCRAAFYLGFDSIPAHVVPMAPEQSVSGWVHVYNTRKFSSMPPLVHGEDRGSTIAILHDGDLRQEVHSKSDLASDLFYAYWDLAELLGGFDYRRSADVPAQGQSVEWVLPSWGAIAKIATNYGPLPAGITRFGSVFFKKCPRCIAEHEKSIMSDPVLDRDEVKSLAVMKD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=1350&amp;to=22051\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKLMKISSSCELSSYLPLNQLVWHEECETLRLKRLTKLLEHEALRESIHVAQGAPYIILDGAHRCRAAFYLGFDSIPAHVVPMAPEQSVSGWVHVYNTRKFSSMPPLVHGEDRGSTIAILHDGDLRQEVHSKSDLASDLFYAYWDLAELLGGFDYRRSADVPAQGQSVEWVLPSWGAIAKIATNYGPLPAGITRFGSVFFKKCPRCIAEHEKSIMSDPVLDRDEVKSLAVMKD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAATTGATGAAAATTAGTAGTAGCTGTGAGTTATCATCGTATCTTCCGCTAAACCAACTCGTATGGCATGAGGAATGTGAGACTTTGCGTCTCAAGCGTCTTACAAAATTGCTAGAACATGAAGCATTACGAGAAAGCATCCACGTAGCCCAAGGGGCACCTTACATCATCCTTGATGGAGCCCACAGGTGTCGAGCAGCTTTTTATTTAGGATTCGATTCCATACCAGCACATGTTGTCCCGATGGCTCCAGAGCAATCCGTATCTGGTTGGGTACATGTCTATAATACTCGGAAATTTTCTTCCATGCCACCATTGGTGCATGGGGAGGATCGGGGATCCACTATCGCTATTTTACACGATGGTGACTTGCGACAAGAAGTCCATTCGAAGAGCGATTTGGCCTCGGATCTATTTTATGCTTATTGGGATCTTGCGGAGCTCTTGGGTGGATTTGATTATCGACGTTCAGCGGATGTACCTGCTCAAGGACAGTCTGTGGAATGGGTTCTTCCTTCATGGGGAGCTATAGCCAAGATAGCTACTAATTACGGGCCACTACCAGCAGGTATAACTCGTTTCGGATCAGTTTTTTTCAAAAAGTGCCCACGATGCATTGCTGAGCACGAAAAATCTATCATGAGTGATCCAGTACTTGATCGTGACGAGGTGAAGAGCCTAGCTGTCATGAAGGATTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 12454,
                        "end": 12585,
                        "strand": -1,
                        "locus_tag": "AAA_02525",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02525</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02525</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,454 - 12,585,\n (total: 132 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MASTMVRKLVSELVVAADRFCKPILQALFDVVINDGLLAPKGG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=2454&amp;to=22585\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MASTMVRKLVSELVVAADRFCKPILQALFDVVINDGLLAPKGG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCATCAACAATGGTACGTAAGCTTGTGTCAGAACTGGTGGTAGCGGCGGATCGGTTTTGTAAACCTATCCTGCAGGCCTTGTTCGATGTAGTGATCAACGACGGTCTCTTAGCTCCCAAGGGGGGATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 12957,
                        "end": 13754,
                        "strand": -1,
                        "locus_tag": "AAA_02526",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02526</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02526</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,957 - 13,754,\n (total: 798 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTERDNRAQDLVRTLLAEGWSQAEIARRIGRDPRLVRFVLKGLKPGTNLVEALTQLERGEEVTPPRRRHDRKGRTAKVRGKRGKPSHRPTEPDAELLHPRRSRAPQQSDEEVLGEKHIETLPRKRRHGTTPSTSQPERLERQMRKRNLLRHEVTNLPHHRSSHTLQFPRDNEDARGQASDLLTEILSEGRGQRMHAKLWIEVDEGGRRERQMVRLGDKGGYDCGFALEDVRMFRDALSWLEDQAGQQYGNVADRGRLVGVEIDVW&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=2957&amp;to=23754\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTERDNRAQDLVRTLLAEGWSQAEIARRIGRDPRLVRFVLKGLKPGTNLVEALTQLERGEEVTPPRRRHDRKGRTAKVRGKRGKPSHRPTEPDAELLHPRRSRAPQQSDEEVLGEKHIETLPRKRRHGTTPSTSQPERLERQMRKRNLLRHEVTNLPHHRSSHTLQFPRDNEDARGQASDLLTEILSEGRGQRMHAKLWIEVDEGGRRERQMVRLGDKGGYDCGFALEDVRMFRDALSWLEDQAGQQYGNVADRGRLVGVEIDVW\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACTGAGCGTGACAATCGGGCTCAGGACCTGGTGCGCACCCTGTTAGCCGAAGGGTGGAGCCAAGCCGAGATTGCCCGACGAATCGGCCGAGACCCCCGCCTGGTGCGGTTCGTGCTAAAAGGGCTTAAGCCTGGCACCAACCTGGTCGAGGCGTTAACACAGTTGGAGCGGGGCGAGGAGGTTACCCCGCCGCGGCGTCGGCATGATCGCAAAGGCCGGACCGCGAAGGTACGCGGTAAGCGCGGAAAACCATCTCACCGTCCCACCGAACCGGATGCCGAACTCCTGCACCCGAGACGAAGCCGCGCACCACAACAGTCCGACGAGGAGGTGCTGGGCGAGAAACACATTGAAACCCTGCCGAGGAAACGCCGCCACGGCACAACCCCGTCAACGAGTCAGCCCGAGCGCCTCGAACGGCAGATGCGCAAGCGCAACCTGCTGCGTCACGAGGTCACAAACCTGCCCCACCACCGTTCTTCCCACACACTCCAATTCCCTCGCGACAACGAGGATGCGCGAGGACAAGCCTCCGATCTGCTCACCGAGATCCTGTCAGAAGGCCGAGGCCAGCGGATGCACGCGAAACTATGGATCGAAGTCGATGAAGGTGGCCGTCGGGAGCGCCAGATGGTGCGGTTGGGGGATAAGGGCGGCTACGACTGCGGTTTCGCTTTGGAAGACGTGCGGATGTTCCGGGATGCGTTGTCGTGGCTAGAGGACCAGGCGGGTCAGCAGTATGGCAATGTCGCCGATAGGGGTCGGCTAGTCGGTGTAGAAATCGATGTTTGGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 13747,
                        "end": 15453,
                        "strand": -1,
                        "locus_tag": "AAA_02527",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02527</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02527</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,747 - 15,453,\n (total: 1707 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRDDQEQRRPAPHRPPDPETVWLDIDTARGVDAAGNEILPVLGGRRTKHATLSDLLTTALHHNARRLIVCGNIPDQPQSWLLPDTPAHTREFNQDWHVRGLFMLSGRPARGRFTHKETDRNLDILVADEWFPGQTLTPIQARWAWRELTHIIATRIDRDWALMDRPGAEGINLWKLRTPESYRMEPMDPELGALIQHTSPQHRYELCVDDGNPEDREKGWRPTVPAGPIPNFVYIDGRFMYAGSVTGEIGAAPATLLSATEARDLFTNNPWHPARYHIRFTVPSWWDDIGLLPVKRTKGRAGWFWPNVPGTTHETWVDTAELKLAIDEGWDTEAGPNGPITQPIEFLEGIKLTKVDPIRGWVKTIQDMIDIAEKRWADKNPTATTILTSALKNMLRVTIGQMSASNPVTTTVVYDADDIPSDIEGFDVIRNKTGDTIAYQYQTARRRPDPDTWHPEIAARIWALSRVRTLNTPIADPTTGKNATTKGGALRMNSRTLLAIHGDAIYTSNVPPWALPVAQGGGDDGKDGRLRVKGVLPGPLEAPQTGSERAALSEQAEQVGLPEEATSD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=3747&amp;to=25453\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRDDQEQRRPAPHRPPDPETVWLDIDTARGVDAAGNEILPVLGGRRTKHATLSDLLTTALHHNARRLIVCGNIPDQPQSWLLPDTPAHTREFNQDWHVRGLFMLSGRPARGRFTHKETDRNLDILVADEWFPGQTLTPIQARWAWRELTHIIATRIDRDWALMDRPGAEGINLWKLRTPESYRMEPMDPELGALIQHTSPQHRYELCVDDGNPEDREKGWRPTVPAGPIPNFVYIDGRFMYAGSVTGEIGAAPATLLSATEARDLFTNNPWHPARYHIRFTVPSWWDDIGLLPVKRTKGRAGWFWPNVPGTTHETWVDTAELKLAIDEGWDTEAGPNGPITQPIEFLEGIKLTKVDPIRGWVKTIQDMIDIAEKRWADKNPTATTILTSALKNMLRVTIGQMSASNPVTTTVVYDADDIPSDIEGFDVIRNKTGDTIAYQYQTARRRPDPDTWHPEIAARIWALSRVRTLNTPIADPTTGKNATTKGGALRMNSRTLLAIHGDAIYTSNVPPWALPVAQGGGDDGKDGRLRVKGVLPGPLEAPQTGSERAALSEQAEQVGLPEEATSD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGAGACGACCAGGAGCAGCGCCGTCCCGCCCCACATCGGCCCCCCGACCCCGAAACAGTGTGGCTAGACATCGACACCGCCCGGGGAGTCGACGCGGCCGGAAACGAGATCCTGCCAGTGCTGGGGGGACGACGCACCAAGCACGCAACCCTGTCAGACCTGCTAACAACCGCGCTACACCACAACGCCCGACGCCTGATCGTCTGCGGTAACATCCCCGACCAGCCTCAATCCTGGCTGCTGCCTGACACCCCCGCTCACACCCGCGAGTTCAACCAGGACTGGCACGTGCGGGGCCTGTTCATGCTGTCCGGGCGGCCCGCCCGAGGCCGGTTCACCCACAAAGAAACCGACCGCAACCTCGACATTCTGGTCGCTGATGAATGGTTCCCTGGCCAGACCCTCACCCCAATCCAGGCCCGCTGGGCATGGCGCGAATTAACCCACATCATCGCCACCAGAATCGACCGCGACTGGGCCCTCATGGACCGCCCCGGAGCAGAAGGAATCAACCTCTGGAAGCTACGGACCCCCGAGTCCTATCGCATGGAGCCGATGGACCCCGAACTGGGCGCACTCATCCAACACACCTCCCCTCAGCACCGCTACGAACTATGCGTCGACGACGGCAACCCCGAGGACCGCGAAAAGGGCTGGCGCCCCACCGTGCCTGCCGGCCCTATCCCTAACTTCGTGTACATCGACGGCCGATTCATGTATGCCGGATCAGTGACCGGAGAGATCGGTGCCGCACCCGCCACTCTGCTCAGCGCCACCGAAGCCCGCGACCTGTTCACCAACAACCCCTGGCACCCGGCCCGCTACCACATCCGCTTCACCGTGCCATCCTGGTGGGACGACATCGGCCTACTACCGGTCAAACGCACCAAAGGACGAGCAGGATGGTTTTGGCCCAACGTGCCCGGCACCACCCACGAAACATGGGTCGATACCGCCGAACTGAAACTAGCCATCGACGAAGGCTGGGACACCGAAGCCGGACCAAATGGGCCCATCACCCAGCCCATCGAGTTCCTCGAAGGGATCAAACTGACCAAAGTCGATCCCATCCGAGGATGGGTCAAAACCATCCAAGACATGATCGACATCGCCGAGAAACGCTGGGCAGACAAAAACCCCACCGCCACGACAATCCTCACCTCCGCGTTGAAAAACATGCTGCGCGTGACCATCGGCCAAATGTCGGCCTCCAACCCCGTCACCACCACCGTCGTCTACGACGCCGACGACATCCCCTCCGACATCGAAGGCTTCGACGTCATCCGCAACAAAACCGGTGACACCATCGCCTACCAATACCAAACCGCCCGCCGCCGCCCCGACCCCGACACCTGGCACCCCGAAATCGCCGCCCGCATCTGGGCCCTGTCCCGCGTACGCACCCTCAACACACCCATCGCCGACCCCACCACCGGAAAAAACGCCACAACCAAGGGAGGAGCACTACGCATGAACTCCCGCACCCTGCTGGCTATCCACGGCGACGCTATCTACACCAGCAACGTGCCCCCCTGGGCGCTCCCTGTGGCCCAGGGGGGCGGCGATGACGGCAAGGACGGGCGGCTGCGTGTCAAAGGTGTCTTGCCGGGCCCTTTGGAAGCGCCTCAGACCGGATCGGAGCGGGCTGCTCTATCAGAGCAGGCCGAGCAAGTAGGACTCCCCGAGGAGGCGACCAGTGACTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 15450,
                        "end": 15971,
                        "strand": -1,
                        "locus_tag": "AAA_02528",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02528</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02528</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,450 - 15,971,\n (total: 522 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPSYRTTPDGKDYRLVITVTDEVTTCVIERIREGTWVPVQTWNTDVTARTRAPERRLKITESAANHGWQVPADAWGPIRHNRIVVKTIHPTGWASVVADATRRRDEALAQLGTIDLAWRDVLADAAAIGHLPATTIAEAAGVSRGRVYQLREEQRERMNALDAGRSLAQRRKP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=5450&amp;to=25971\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPSYRTTPDGKDYRLVITVTDEVTTCVIERIREGTWVPVQTWNTDVTARTRAPERRLKITESAANHGWQVPADAWGPIRHNRIVVKTIHPTGWASVVADATRRRDEALAQLGTIDLAWRDVLADAAAIGHLPATTIAEAAGVSRGRVYQLREEQRERMNALDAGRSLAQRRKP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCCAGCTACCGAACCACCCCAGACGGGAAAGATTATCGTCTGGTCATCACAGTCACCGACGAGGTCACCACGTGCGTCATCGAACGCATCCGAGAAGGGACGTGGGTACCAGTCCAGACCTGGAACACCGACGTCACTGCCCGCACCCGCGCACCTGAGCGACGCCTCAAGATCACCGAGTCCGCCGCCAATCACGGCTGGCAAGTCCCCGCTGATGCATGGGGCCCCATCCGCCACAACCGAATCGTCGTCAAGACCATCCACCCCACAGGGTGGGCCTCCGTAGTGGCTGATGCCACCCGCCGCCGCGACGAAGCTCTAGCCCAGCTGGGAACCATTGACCTGGCCTGGCGTGACGTCCTTGCCGACGCTGCCGCCATCGGCCACCTGCCGGCCACCACCATCGCCGAGGCAGCAGGAGTGTCACGAGGCCGGGTCTACCAACTACGCGAAGAACAACGCGAGCGCATGAACGCCCTCGACGCCGGCCGCTCCCTGGCCCAAAGGAGGAAACCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 16041,
                        "end": 16601,
                        "strand": -1,
                        "locus_tag": "AAA_02529",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02529</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02529</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,041 - 16,601,\n (total: 561 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00583.25 (Acetyltransferase (GNAT) family): [115:163](score: 24.3, e-value: 2.9e-05)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIQESWEFSLSWHRSEITEIMAGHRRSALLIPIAAGVEAAIIWALRDWIICGNWPGQGELAMIGAATLVVVAVIMVALEAHHWRTATWRSWQTTPDWHGGAYVAPPARRHGPMLMCVHAVPRTQGHGSQILTQVCQWADEHGLTLELKPSGPAAERFYKRFGFVKTSRRVMRRECLSGRADPHKGV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=6041&amp;to=26601\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIQESWEFSLSWHRSEITEIMAGHRRSALLIPIAAGVEAAIIWALRDWIICGNWPGQGELAMIGAATLVVVAVIMVALEAHHWRTATWRSWQTTPDWHGGAYVAPPARRHGPMLMCVHAVPRTQGHGSQILTQVCQWADEHGLTLELKPSGPAAERFYKRFGFVKTSRRVMRRECLSGRADPHKGV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATTCAAGAGTCGTGGGAATTCTCCTTGTCGTGGCATCGCAGCGAGATCACCGAGATCATGGCAGGACACCGTCGTTCTGCCTTGCTCATCCCGATCGCAGCAGGCGTGGAAGCCGCGATCATCTGGGCGTTAAGAGACTGGATCATCTGCGGGAACTGGCCTGGCCAGGGTGAGCTGGCCATGATCGGGGCCGCAACGCTCGTCGTCGTCGCGGTGATCATGGTGGCCCTCGAAGCCCACCACTGGCGTACCGCGACATGGCGAAGCTGGCAGACCACACCGGACTGGCATGGCGGAGCCTACGTGGCCCCGCCAGCGCGCCGCCACGGCCCCATGCTCATGTGCGTCCACGCCGTCCCCCGCACTCAAGGCCACGGCTCACAGATCCTCACACAAGTCTGCCAATGGGCCGACGAGCACGGTCTCACCCTCGAACTGAAGCCCTCCGGGCCCGCTGCGGAGCGGTTCTATAAGCGGTTTGGTTTCGTTAAGACGTCGCGGCGGGTCATGAGACGTGAGTGCCTGTCTGGGCGGGCGGATCCACACAAAGGCGTCTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 16598,
                        "end": 16975,
                        "strand": -1,
                        "locus_tag": "AAA_02530",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02530</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02530</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,598 - 16,975,\n (total: 378 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRINATRTPLPPVRTMTASQLKIGDLVAGHTADGSYPFHVERADSYDGMVHLRLIEISHASGLTDEQHPGIESVHAPDEPVITLSRHFGVCSECGRLSPCPDELAERRLEKLWQGEAEEAVHTSA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=6598&amp;to=26975\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRINATRTPLPPVRTMTASQLKIGDLVAGHTADGSYPFHVERADSYDGMVHLRLIEISHASGLTDEQHPGIESVHAPDEPVITLSRHFGVCSECGRLSPCPDELAERRLEKLWQGEAEEAVHTSA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGGATCAACGCGACCCGGACCCCGCTGCCGCCGGTGCGAACCATGACCGCCAGCCAGTTGAAGATCGGGGACCTGGTTGCAGGCCACACCGCGGACGGCTCCTACCCGTTCCATGTCGAGAGAGCCGACAGCTACGACGGCATGGTCCACCTCCGTCTGATCGAGATCAGCCACGCTTCGGGACTCACCGATGAGCAGCACCCGGGCATCGAGTCGGTTCATGCTCCCGACGAGCCGGTCATCACTCTCTCGCGCCACTTCGGGGTCTGCTCCGAGTGCGGCAGGCTGTCGCCGTGTCCCGACGAGCTGGCTGAGCGTCGTTTGGAGAAACTATGGCAGGGCGAAGCCGAAGAAGCCGTTCACACATCAGCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 17132,
                        "end": 17500,
                        "strand": 1,
                        "locus_tag": "AAA_02531",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02531</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02531</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,132 - 17,500,\n (total: 369 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIEPTTISTTPRVAIISPSGPARFWGEPPSIALRRHGRSPMRSLPSGALLLVWDVTVLTGPTLGHRVRPLSKDAELTARRWLDQVADNPGFLDTLIEAARITNGWHHATPPHIQAPYRTLHQ&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=7132&amp;to=27500\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIEPTTISTTPRVAIISPSGPARFWGEPPSIALRRHGRSPMRSLPSGALLLVWDVTVLTGPTLGHRVRPLSKDAELTARRWLDQVADNPGFLDTLIEAARITNGWHHATPPHIQAPYRTLHQ\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATCGAACCCACAACCATCTCCACCACGCCCCGCGTGGCCATCATCTCCCCCAGCGGGCCAGCACGGTTCTGGGGCGAGCCTCCCAGCATCGCACTGCGCCGACACGGCCGGTCCCCCATGAGGTCCCTTCCTTCCGGGGCCCTGCTGCTGGTGTGGGACGTCACCGTTTTGACCGGGCCCACTCTCGGCCACCGCGTGCGTCCTCTCAGTAAGGACGCCGAGCTGACTGCCCGGCGCTGGCTCGACCAGGTCGCCGACAACCCCGGCTTCCTCGACACCCTTATCGAGGCCGCCCGCATCACCAATGGATGGCATCACGCGACGCCTCCGCACATTCAGGCCCCTTACCGGACCCTTCATCAGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 17517,
                        "end": 18098,
                        "strand": 1,
                        "locus_tag": "AAA_02532",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02532</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02532</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,517 - 18,098,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTSDIDIDRTHKPDDRAEAPLYRSWARRLVHVSGMPWRIVAALAGVSPTSMHRLLFGRNGRPVEWIGINDARALMDIGIDDLASASTDRIPARESRELLVALHTLGWTDEHLSRWLTSSDLDLATTPKALYVTRLSAARIQATYDMLISQPVRRCGHPRTPPISSQTPVTSPQPGPEDAETFQPALFELADCA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=7517&amp;to=28098\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTSDIDIDRTHKPDDRAEAPLYRSWARRLVHVSGMPWRIVAALAGVSPTSMHRLLFGRNGRPVEWIGINDARALMDIGIDDLASASTDRIPARESRELLVALHTLGWTDEHLSRWLTSSDLDLATTPKALYVTRLSAARIQATYDMLISQPVRRCGHPRTPPISSQTPVTSPQPGPEDAETFQPALFELADCA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCAGCGACATTGACATTGACCGGACCCACAAACCCGACGACCGCGCCGAGGCTCCTCTTTACCGGTCCTGGGCCAGGAGACTCGTGCACGTCTCCGGGATGCCCTGGCGTATCGTCGCCGCCCTGGCCGGGGTCTCCCCCACCTCCATGCACCGGCTTCTATTCGGCCGCAACGGTCGACCCGTGGAATGGATCGGCATCAATGATGCTCGCGCCCTGATGGATATCGGCATCGATGATCTCGCCTCAGCGTCCACCGACCGTATCCCGGCCCGCGAATCCCGCGAGCTGTTGGTAGCCCTGCACACCCTCGGCTGGACCGATGAGCATCTAAGCCGCTGGCTGACCAGTTCCGACCTCGACCTGGCCACCACCCCCAAGGCCCTCTACGTCACCCGGCTATCCGCCGCCCGCATCCAGGCCACCTACGACATGCTCATCAGCCAACCCGTCCGCCGCTGCGGCCACCCCCGCACCCCGCCTATCTCGTCCCAGACTCCGGTTACCTCGCCCCAGCCCGGGCCCGAGGATGCCGAAACGTTCCAGCCCGCCCTGTTCGAGCTAGCCGACTGCGCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 18161,
                        "end": 18658,
                        "strand": 1,
                        "locus_tag": "AAA_02533",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02533</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02533</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,161 - 18,658,\n (total: 498 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRLYRAVLTHTDIQITVRIWSTTDHDWTWTPLDTWTPDPTPTTPAQLADELHRHGWTTPEDPTTLTKVTVIPENWQALVDHALAARNHQANQLRVAENILTDILGDAADAGLSVTFLAQAAGLSRAAFYKRSAKTINSMRHTDQPREDPSQLTRAEKTALSLGDE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=8161&amp;to=28658\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRLYRAVLTHTDIQITVRIWSTTDHDWTWTPLDTWTPDPTPTTPAQLADELHRHGWTTPEDPTTLTKVTVIPENWQALVDHALAARNHQANQLRVAENILTDILGDAADAGLSVTFLAQAAGLSRAAFYKRSAKTINSMRHTDQPREDPSQLTRAEKTALSLGDE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCGTCTATACCGCGCTGTTCTTACCCACACCGACATCCAGATCACCGTCCGCATCTGGAGCACCACCGACCACGACTGGACCTGGACTCCCCTCGACACCTGGACCCCCGACCCGACCCCGACCACACCAGCCCAACTGGCCGACGAACTCCACCGACACGGATGGACCACCCCCGAGGACCCCACCACCCTCACCAAGGTGACTGTGATCCCCGAGAACTGGCAGGCCCTCGTCGACCACGCCCTCGCTGCCCGAAACCACCAAGCCAACCAGCTGCGCGTCGCCGAGAACATCCTCACCGACATCCTCGGCGACGCCGCCGACGCCGGCCTTTCCGTGACCTTCCTCGCCCAGGCCGCCGGACTGTCCCGAGCTGCCTTCTACAAACGCAGCGCTAAGACCATCAACTCTATGAGGCACACCGACCAGCCGCGCGAAGACCCCTCCCAGCTCACCCGAGCCGAGAAAACAGCACTCAGCCTGGGCGACGAGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 18766,
                        "end": 19071,
                        "strand": -1,
                        "locus_tag": "AAA_02534",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02534</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02534</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,766 - 19,071,\n (total: 306 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNGPTGEGNNGCEEILAFIVVGIGGIALLKKMAPKIIGHLGAWLRDHGLLGVPGQGLFDLGLLGSVSASHLVVAVGVLIVVGALGAWFAGWVFARGSRGCR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=8766&amp;to=29071\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNGPTGEGNNGCEEILAFIVVGIGGIALLKKMAPKIIGHLGAWLRDHGLLGVPGQGLFDLGLLGSVSASHLVVAVGVLIVVGALGAWFAGWVFARGSRGCR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAACGGCCCCACCGGAGAAGGAAACAACGGATGCGAAGAAATCCTCGCCTTCATCGTTGTTGGTATCGGAGGGATAGCCCTGCTGAAGAAGATGGCCCCTAAAATCATCGGTCATCTCGGAGCATGGCTTCGCGATCACGGGCTGCTCGGCGTTCCCGGGCAGGGCCTGTTTGATCTTGGGTTGTTGGGGTCGGTTAGTGCTTCCCACCTGGTGGTCGCCGTGGGTGTGCTGATCGTGGTGGGCGCATTGGGGGCTTGGTTCGCTGGTTGGGTCTTCGCGAGGGGCAGTCGGGGGTGTAGGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 19068,
                        "end": 19385,
                        "strand": -1,
                        "locus_tag": "AAA_02535",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02535</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02535</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,068 - 19,385,\n (total: 318 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTPVALPSIADLDHAVNNLTDALITATDAAETSTDSGWYIESAIEELRTALTEVASLSRAAGAPASLLAGASRAWQAGQVELIETSGQVADNLIGWLAVHPEKAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=9068&amp;to=29385\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTPVALPSIADLDHAVNNLTDALITATDAAETSTDSGWYIESAIEELRTALTEVASLSRAAGAPASLLAGASRAWQAGQVELIETSGQVADNLIGWLAVHPEKAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACTCCCGTAGCTTTACCGAGCATCGCTGATCTCGACCATGCCGTCAACAACCTCACCGACGCCCTTATCACCGCCACCGACGCCGCCGAGACCAGTACCGACAGCGGCTGGTACATCGAAAGCGCCATCGAGGAGCTACGCACCGCCTTGACTGAAGTCGCTTCTCTCAGCCGCGCAGCAGGGGCCCCGGCATCACTGCTGGCCGGCGCATCGCGCGCATGGCAGGCTGGACAGGTCGAACTGATCGAAACCTCAGGACAGGTCGCCGACAACCTCATCGGCTGGCTGGCCGTCCACCCCGAGAAGGCAGCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 19856,
                        "end": 20125,
                        "strand": 1,
                        "locus_tag": "AAA_02536",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02536</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02536</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,856 - 20,125,\n (total: 270 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MAIIFTESAARHGFTRDDAIHAMETPEVFTPHFDHSRTGSPDVAAWIGPARGGLTIEVFATVIRPHTVVVFHCMEVRPSTREKLNGEQS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=9856&amp;to=30125\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MAIIFTESAARHGFTRDDAIHAMETPEVFTPHFDHSRTGSPDVAAWIGPARGGLTIEVFATVIRPHTVVVFHCMEVRPSTREKLNGEQS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCCATCATTTTTACTGAGAGCGCCGCTCGACATGGGTTCACCCGTGACGACGCAATTCACGCTATGGAGACTCCCGAGGTGTTCACGCCCCACTTTGATCATTCCCGTACTGGGAGTCCTGATGTGGCGGCATGGATTGGCCCGGCGAGAGGAGGGCTCACCATTGAGGTGTTCGCCACGGTGATCCGACCTCACACAGTCGTGGTCTTTCACTGCATGGAAGTGCGACCTTCAACCCGCGAGAAACTGAACGGAGAACAATCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 20122,
                        "end": 20448,
                        "strand": 1,
                        "locus_tag": "AAA_02537",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02537</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02537</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,122 - 20,448,\n (total: 327 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01402.21 (Ribbon-helix-helix protein, copG family): [70:105](score: 27.0, e-value: 3e-06)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSNSHEIRYGIDFTELADWAETDNATHDPQTSPVFWGKDARHASQALLKRGRPTLGEDHATGKGHSPRRQLRLDAETNTRLDAMAAETGRSPSDIMRTALIDYLDAAS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=10122&amp;to=30448\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSNSHEIRYGIDFTELADWAETDNATHDPQTSPVFWGKDARHASQALLKRGRPTLGEDHATGKGHSPRRQLRLDAETNTRLDAMAAETGRSPSDIMRTALIDYLDAAS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCAACAGCCACGAGATCCGTTACGGGATCGACTTCACCGAACTGGCCGACTGGGCCGAGACCGATAACGCCACCCATGACCCGCAAACCAGCCCTGTGTTTTGGGGTAAGGATGCCCGGCACGCCAGCCAAGCGCTGCTGAAGCGTGGACGCCCGACCCTTGGCGAGGACCATGCCACTGGCAAGGGACACTCACCACGCCGTCAACTCCGTCTGGACGCTGAGACAAACACACGCCTCGATGCAATGGCGGCCGAGACCGGGCGCAGCCCCTCCGACATCATGCGCACCGCCCTCATCGACTACCTCGATGCCGCAAGCTAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 20509,
                        "end": 20754,
                        "strand": -1,
                        "locus_tag": "AAA_02538",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02538</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02538</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,509 - 20,754,\n (total: 246 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSKSDNEHLADYVGRQYRQAAVLDFNYGSLARHGAESGAAIFLHYATRYTAGCVGMDSLSELTSTLRWIDPAQNPKIIILG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=10509&amp;to=30754\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSKSDNEHLADYVGRQYRQAAVLDFNYGSLARHGAESGAAIFLHYATRYTAGCVGMDSLSELTSTLRWIDPAQNPKIIILG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"TTGTCGAAGTCGGATAACGAGCACTTGGCGGACTACGTGGGCCGTCAGTACCGGCAAGCAGCCGTACTGGATTTCAACTATGGCTCGCTGGCGCGTCATGGTGCCGAGTCGGGGGCAGCGATCTTTTTGCATTATGCGACGCGTTACACTGCTGGGTGTGTGGGTATGGACTCACTGTCAGAGCTGACTAGCACGCTGCGATGGATTGACCCGGCTCAGAATCCCAAGATCATTATCTTGGGGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 21067,
                        "end": 21480,
                        "strand": -1,
                        "locus_tag": "AAA_02539",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02539</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02539</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,067 - 21,480,\n (total: 414 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSMTAEAGTVYDVIAHREVSPEANFWVFEIPALGAVGQAVKLGQVADEARGIITAWDEDGPDEKAFKVHVRLDGEADARRMWEEGEEEERQARKVLDHAAARKREAVTLLRVEKKYSANDTARVLGVTRQRVYQLTR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=11067&amp;to=31480\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSMTAEAGTVYDVIAHREVSPEANFWVFEIPALGAVGQAVKLGQVADEARGIITAWDEDGPDEKAFKVHVRLDGEADARRMWEEGEEEERQARKVLDHAAARKREAVTLLRVEKKYSANDTARVLGVTRQRVYQLTR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCATGACAGCAGAAGCTGGGACGGTCTATGACGTGATCGCCCATCGTGAGGTCTCACCTGAGGCGAATTTCTGGGTATTCGAGATTCCGGCCCTCGGGGCGGTTGGGCAAGCAGTGAAGTTGGGTCAGGTCGCAGACGAGGCCCGCGGAATCATTACCGCCTGGGATGAGGATGGACCCGATGAGAAGGCGTTTAAGGTTCACGTTCGCTTGGATGGTGAGGCCGACGCCCGCCGCATGTGGGAAGAAGGTGAGGAGGAAGAGCGCCAAGCCCGGAAGGTGCTTGATCACGCGGCCGCACGCAAGCGTGAGGCCGTCACTCTGCTGAGGGTCGAGAAGAAATACAGCGCCAACGACACCGCCCGCGTGCTTGGGGTGACCCGCCAAAGGGTTTACCAACTCACCCGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 22169,
                        "end": 22813,
                        "strand": -1,
                        "locus_tag": "AAA_02540",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02540</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02540</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,169 - 22,813,\n (total: 645 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MQQIVWVVAVMAIAAAGWPALTRVLPEPATASPDKIAYRDTYSLRSMIAVCAASATTMIAAVAWAPAPTWPAWALLATIGAWVAVIDAITTWIPAVLAWTGWVGWIGAVAMIALANQTAAIRAAIATVVISAAWMIVWVISRGGFGFSDVRITPLWAAPAAATGITTIHATVIAGLTLIALYALIDRCRHHTTRFLPWAPSLCSGALVGLAIAH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=12169&amp;to=32813\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MQQIVWVVAVMAIAAAGWPALTRVLPEPATASPDKIAYRDTYSLRSMIAVCAASATTMIAAVAWAPAPTWPAWALLATIGAWVAVIDAITTWIPAVLAWTGWVGWIGAVAMIALANQTAAIRAAIATVVISAAWMIVWVISRGGFGFSDVRITPLWAAPAAATGITTIHATVIAGLTLIALYALIDRCRHHTTRFLPWAPSLCSGALVGLAIAH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCAACAGATTGTGTGGGTGGTCGCCGTGATGGCTATCGCGGCCGCAGGGTGGCCTGCCCTCACCCGCGTCTTGCCAGAACCAGCTACCGCCAGCCCCGACAAAATCGCCTACCGCGACACCTACAGTCTCCGAAGCATGATCGCTGTCTGTGCTGCATCTGCGACAACCATGATCGCCGCCGTAGCGTGGGCCCCAGCACCCACCTGGCCGGCCTGGGCTCTGCTAGCCACCATCGGGGCATGGGTAGCCGTCATCGACGCCATCACCACATGGATACCGGCAGTCCTCGCCTGGACCGGCTGGGTTGGATGGATCGGGGCTGTGGCCATGATCGCTCTCGCGAACCAGACTGCGGCGATCCGTGCTGCTATCGCTACTGTCGTCATCTCCGCGGCGTGGATGATCGTCTGGGTCATCTCCCGAGGCGGATTCGGTTTCTCTGATGTGCGCATCACGCCGCTGTGGGCGGCCCCGGCCGCCGCAACCGGGATCACCACGATCCACGCCACGGTCATCGCCGGGCTGACTCTGATCGCCCTCTACGCCCTCATCGACCGCTGCCGACACCACACCACCCGATTCCTTCCCTGGGCGCCCAGCCTGTGCAGCGGCGCCCTCGTCGGCCTGGCCATCGCTCACTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 22863,
                        "end": 24860,
                        "strand": -1,
                        "locus_tag": "AAA_02541",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02541</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02541</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,863 - 24,860,\n (total: 1998 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01580.18 (FtsK/SpoIIIE family): [267:383](score: 31.5, e-value: 1.1e-07)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTIRSRPSVAAAKKTPSAQLAVSVKPAWTNTAAGWSGAVLATGGYAAAADPRWWLLCVGCAVAGTLHASRALRADRRTETAETARLAIQATLKVPVSQKVTWDRKGKHPRRLILTIPPEAAAGETVPMTLTQAAAAAWPPGQFTVASATIPAGRFILAYRDPTPEPDKTDLDRATERAKDVATQIYGSAVTVDSWSTDQGKLDGFTIHHQRGAHLSSPNIQLRLAAVTSAMMPGQWRSDFDLEHDTITVTRRRPLPSVAARPVALPAPDSPDWEKIPQAVDEDGNTCYWDISGVMAHQLKAGRTRTGKTVSMIGDAVEAARRDWRVFIIDPKRIEYLGLREWPNIEMVATTVPDQVALIHWLWALMEDRYRRIEEEGARETDFTRVLVLIDEYRQFYGNTKNWWSTIKVSGMPGECPVFGWIGSLLRMAAACRIHVDLGTQRPDAEFLGGEIRDNFSGRAATGPLSSDGARMMFGSEHVGVGIPFGKRGRGTYLSGESTPKEVQFFYTPDPRKARSPQDLKLLEQLRPATTTWTKKKFVWPTDKQIAKAMASAGKKTSPQWERILGADLAADTETARPAPPPVVEEPDEDPVCDIDRFYSPPHPVAATELTAGMLIDIDGDWVTIAESSVDGEQVIVDWESAGDDSGTLMLGAGEAMSTRTPLDG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=12863&amp;to=34860\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTIRSRPSVAAAKKTPSAQLAVSVKPAWTNTAAGWSGAVLATGGYAAAADPRWWLLCVGCAVAGTLHASRALRADRRTETAETARLAIQATLKVPVSQKVTWDRKGKHPRRLILTIPPEAAAGETVPMTLTQAAAAAWPPGQFTVASATIPAGRFILAYRDPTPEPDKTDLDRATERAKDVATQIYGSAVTVDSWSTDQGKLDGFTIHHQRGAHLSSPNIQLRLAAVTSAMMPGQWRSDFDLEHDTITVTRRRPLPSVAARPVALPAPDSPDWEKIPQAVDEDGNTCYWDISGVMAHQLKAGRTRTGKTVSMIGDAVEAARRDWRVFIIDPKRIEYLGLREWPNIEMVATTVPDQVALIHWLWALMEDRYRRIEEEGARETDFTRVLVLIDEYRQFYGNTKNWWSTIKVSGMPGECPVFGWIGSLLRMAAACRIHVDLGTQRPDAEFLGGEIRDNFSGRAATGPLSSDGARMMFGSEHVGVGIPFGKRGRGTYLSGESTPKEVQFFYTPDPRKARSPQDLKLLEQLRPATTTWTKKKFVWPTDKQIAKAMASAGKKTSPQWERILGADLAADTETARPAPPPVVEEPDEDPVCDIDRFYSPPHPVAATELTAGMLIDIDGDWVTIAESSVDGEQVIVDWESAGDDSGTLMLGAGEAMSTRTPLDG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCATCCGGTCTCGTCCCTCAGTTGCGGCCGCGAAGAAGACACCCTCCGCCCAGCTCGCTGTCAGCGTGAAACCGGCGTGGACGAACACTGCGGCCGGCTGGTCGGGTGCGGTACTGGCCACAGGAGGCTACGCCGCGGCCGCGGATCCCCGCTGGTGGCTGCTATGTGTGGGCTGCGCTGTGGCGGGGACTCTTCACGCCAGTCGTGCGTTGCGCGCCGACCGGCGCACTGAGACCGCTGAAACAGCCCGCCTGGCTATCCAGGCGACGCTGAAGGTGCCGGTGTCCCAGAAAGTTACGTGGGATCGCAAGGGCAAACACCCGCGCCGACTGATCCTCACTATTCCTCCTGAGGCGGCCGCGGGGGAGACCGTGCCAATGACGCTGACCCAGGCAGCTGCAGCTGCCTGGCCGCCAGGACAATTCACGGTGGCTTCCGCAACGATCCCGGCCGGACGGTTCATCCTGGCCTACCGTGACCCCACCCCCGAGCCTGACAAGACTGATCTGGATCGGGCCACCGAGCGCGCCAAAGACGTGGCCACCCAAATCTATGGGTCGGCGGTCACTGTCGATTCCTGGAGCACCGATCAGGGGAAGCTGGACGGGTTCACCATTCACCACCAGCGTGGCGCTCACCTGTCCAGCCCCAACATTCAGCTACGCCTGGCCGCGGTAACCTCGGCGATGATGCCCGGCCAATGGCGCAGCGACTTCGACTTGGAGCACGACACCATCACTGTCACTCGTCGACGCCCTTTGCCCTCGGTGGCGGCGCGACCGGTGGCCCTTCCTGCCCCAGATTCCCCAGATTGGGAGAAGATCCCTCAAGCCGTCGACGAGGACGGCAACACCTGCTACTGGGACATCTCTGGTGTCATGGCCCACCAGCTCAAAGCCGGCCGTACCCGCACCGGGAAAACGGTATCCATGATCGGTGACGCCGTCGAGGCCGCCCGCCGTGACTGGCGCGTCTTCATCATCGACCCCAAACGCATCGAATATCTGGGCTTGCGGGAGTGGCCCAACATCGAAATGGTCGCCACCACCGTGCCCGACCAGGTCGCCCTCATCCACTGGCTGTGGGCCCTCATGGAGGACCGCTACCGACGCATCGAGGAAGAAGGAGCACGAGAAACCGACTTCACCCGAGTGCTCGTCCTCATCGACGAATACCGCCAGTTCTACGGCAACACGAAAAACTGGTGGTCGACGATCAAAGTCTCCGGAATGCCCGGAGAATGCCCCGTCTTCGGATGGATCGGCTCCCTGCTGCGCATGGCAGCAGCCTGCCGCATCCACGTCGATCTAGGAACCCAACGCCCAGACGCCGAATTTCTGGGCGGCGAGATCCGAGACAACTTCTCCGGCCGAGCCGCCACCGGACCCCTGTCCTCCGATGGCGCCCGCATGATGTTCGGCTCCGAACACGTCGGCGTGGGCATCCCGTTCGGCAAACGCGGCCGCGGCACCTACCTATCCGGCGAATCAACCCCCAAAGAAGTCCAGTTCTTCTACACCCCCGACCCCCGCAAAGCCCGCTCCCCGCAAGACCTGAAGCTGCTGGAACAGCTGCGACCCGCCACCACGACCTGGACCAAGAAGAAGTTTGTGTGGCCCACTGACAAACAGATCGCTAAGGCCATGGCCTCAGCGGGCAAGAAAACCAGCCCGCAGTGGGAGCGCATCCTGGGAGCCGACCTGGCTGCCGACACCGAGACAGCCAGGCCCGCCCCGCCCCCGGTAGTCGAGGAACCCGACGAAGATCCCGTTTGCGACATCGACCGCTTCTACAGCCCACCCCACCCGGTGGCCGCCACCGAGTTGACTGCTGGGATGCTCATCGACATAGACGGAGATTGGGTGACCATCGCCGAGTCCAGCGTCGACGGTGAGCAGGTCATCGTCGATTGGGAATCGGCCGGCGACGATTCCGGAACCCTCATGCTCGGCGCAGGAGAAGCCATGTCCACCCGCACACCTCTCGACGGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 24857,
                        "end": 25135,
                        "strand": -1,
                        "locus_tag": "AAA_02542",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02542</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02542</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,857 - 25,135,\n (total: 279 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRVSRSVNLTREQVRAQLRLFTAISAVQQDGLVVPCTDDPPSWDKESMNPAACNGCPVFKLCTVYAATGAVRHGIIAGHHAYELTCHKETAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=14857&amp;to=35135\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRVSRSVNLTREQVRAQLRLFTAISAVQQDGLVVPCTDDPPSWDKESMNPAACNGCPVFKLCTVYAATGAVRHGIIAGHHAYELTCHKETAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCGTGTATCCCGCTCCGTCAACCTAACCCGGGAACAAGTTCGCGCCCAGCTGCGACTGTTCACCGCTATCAGTGCTGTCCAACAGGATGGCCTGGTTGTGCCGTGCACCGATGATCCGCCGTCGTGGGACAAAGAAAGCATGAACCCGGCGGCCTGTAATGGGTGCCCCGTGTTCAAGCTATGCACGGTCTATGCGGCCACCGGGGCGGTGCGTCACGGCATCATTGCTGGACATCATGCCTATGAGCTGACCTGCCACAAGGAAACTGCGGCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 25397,
                        "end": 26017,
                        "strand": 1,
                        "locus_tag": "AAA_02543",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02543</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02543</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,397 - 26,017,\n (total: 621 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00239.21 (Resolvase, N terminal domain): [58:188](score: 60.6, e-value: 1.8e-16)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNLKEWAGVRGISYQTALRWYHRGLMPVPVHRVGRLVLVDCDEHGLPFEGSTPEPTKTIIYARVCSADQKPDLDRQIARVMTWASAKELSVDGVVTEVGSGLDGHRKKFEKLLKDGSVRTILVEHRDRFCRFGSEYIEAALSAQNRRLLVVDDKEIEDDLVQDMTDVLTSMCARLYGKRSAKHRARKAVETAMTTGGEESVKDDHT&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=15397&amp;to=36017\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNLKEWAGVRGISYQTALRWYHRGLMPVPVHRVGRLVLVDCDEHGLPFEGSTPEPTKTIIYARVCSADQKPDLDRQIARVMTWASAKELSVDGVVTEVGSGLDGHRKKFEKLLKDGSVRTILVEHRDRFCRFGSEYIEAALSAQNRRLLVVDDKEIEDDLVQDMTDVLTSMCARLYGKRSAKHRARKAVETAMTTGGEESVKDDHT\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAATCTCAAGGAGTGGGCAGGAGTGCGCGGGATTTCGTATCAGACCGCGCTGCGGTGGTATCACCGTGGGCTTATGCCTGTTCCCGTGCATCGAGTGGGAAGGCTCGTGCTCGTTGATTGTGACGAGCATGGGTTGCCGTTCGAGGGATCGACCCCCGAGCCGACGAAAACGATCATTTATGCTCGGGTGTGCTCGGCGGATCAGAAACCCGATCTTGATAGACAGATCGCTCGAGTCATGACATGGGCGAGCGCGAAGGAATTGTCGGTTGATGGTGTTGTCACCGAGGTTGGTTCTGGTCTCGATGGGCATCGGAAGAAGTTCGAGAAATTGTTGAAGGATGGTTCTGTCAGGACGATTCTTGTGGAACATCGCGATCGATTCTGCCGATTCGGGTCGGAATACATTGAAGCGGCACTTTCGGCACAGAATCGTCGTCTCCTTGTTGTTGACGACAAGGAGATCGAAGACGATCTTGTGCAGGATATGACAGATGTGCTCACGTCCATGTGTGCGAGATTGTACGGAAAGAGATCAGCGAAACATCGCGCCCGAAAGGCCGTGGAAACGGCCATGACCACTGGCGGTGAAGAATCCGTTAAGGATGATCACACATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 26014,
                        "end": 27459,
                        "strand": 1,
                        "locus_tag": "AAA_02544",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02544</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02544</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,014 - 27,459,\n (total: 1446 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1192:transposase (Score: 296.7; E-value: 4.2e-90)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF12323.8 (Helix-turn-helix domain): [19:59](score: 48.9, e-value: 3.2e-13)<br>\n \n  PF01385.19 (Probable transposase): [212:338](score: 49.1, e-value: 6e-13)<br>\n \n  PF07282.11 (Putative transposase DNA-binding domain): [356:426](score: 72.5, e-value: 2e-20)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MITKPAAPKLDKNGPDVVVRSYKFALKPTKSQEQKLRQHTGAARFVYNYLISQWRDDIHTRAEEKKCGVPEDELTPFTFKLSAYDMRNYWNRTKGECAPWWPEVSKEIGNDAARRAHDSIENWYDSKGGKRKGRRVGFPRFHKRGCHESCTFSTGTIRVNPDRHSVALPRIGTIKTRENTRELQRKIAKGTARITQATISRGFNYWHVSFTVYEKKHIPETHAHSGSVVGVDMGVGDHVIVAATPNGDEVMRRGLPQSVKKDEARVRHLQRKLSRKHGPDKRTKTTPSNRWIRANNQVNKYRAKLANIRRDLAAKAAHGLATNYETVVIEDLNVQAMMTRGGAHKRGLNRAIAQASFADVRRRITYKTRWNGGRTVIADRWFPSSKTCSECGEVKSKLSLSEREYICHRCGVVVDRDLNAATNLAKLAAPKSGVDFHGTGSSPGMGRGGAGKTNSSSGELAPAGEASMARKDLSGRKAGTR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=16014&amp;to=37459\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_02544_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MITKPAAPKLDKNGPDVVVRSYKFALKPTKSQEQKLRQHTGAARFVYNYLISQWRDDIHTRAEEKKCGVPEDELTPFTFKLSAYDMRNYWNRTKGECAPWWPEVSKEIGNDAARRAHDSIENWYDSKGGKRKGRRVGFPRFHKRGCHESCTFSTGTIRVNPDRHSVALPRIGTIKTRENTRELQRKIAKGTARITQATISRGFNYWHVSFTVYEKKHIPETHAHSGSVVGVDMGVGDHVIVAATPNGDEVMRRGLPQSVKKDEARVRHLQRKLSRKHGPDKRTKTTPSNRWIRANNQVNKYRAKLANIRRDLAAKAAHGLATNYETVVIEDLNVQAMMTRGGAHKRGLNRAIAQASFADVRRRITYKTRWNGGRTVIADRWFPSSKTCSECGEVKSKLSLSEREYICHRCGVVVDRDLNAATNLAKLAAPKSGVDFHGTGSSPGMGRGGAGKTNSSSGELAPAGEASMARKDLSGRKAGTR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATCACGAAGCCCGCCGCCCCGAAATTGGACAAGAATGGCCCAGATGTTGTTGTCCGGTCCTACAAGTTTGCGTTGAAACCCACGAAGTCGCAGGAACAGAAATTGCGTCAGCATACGGGTGCAGCAAGGTTTGTCTACAATTATCTCATTTCCCAGTGGCGCGACGACATTCACACTCGTGCCGAAGAGAAGAAATGCGGCGTTCCTGAGGATGAATTGACGCCGTTCACGTTTAAGTTGTCTGCCTATGATATGCGTAATTACTGGAATCGCACCAAGGGCGAGTGTGCTCCGTGGTGGCCAGAAGTATCGAAGGAGATCGGCAACGATGCGGCACGTCGTGCCCATGACTCCATTGAGAACTGGTACGACTCCAAGGGCGGGAAACGCAAGGGCAGAAGAGTGGGCTTCCCCCGGTTCCACAAGCGCGGATGCCATGAATCATGCACGTTCTCAACCGGGACGATCCGTGTCAATCCTGACCGTCACTCGGTGGCACTGCCCCGAATCGGAACCATAAAGACTCGCGAAAATACGCGCGAATTGCAACGCAAAATCGCCAAAGGTACGGCAAGAATCACTCAGGCCACGATCTCTCGCGGGTTCAATTATTGGCACGTCTCCTTCACCGTGTACGAGAAGAAACACATTCCCGAAACCCACGCACATTCCGGCTCTGTTGTCGGGGTGGACATGGGTGTGGGAGATCACGTCATCGTTGCGGCAACCCCAAACGGTGATGAAGTCATGCGTAGGGGATTGCCGCAATCGGTCAAGAAGGATGAAGCGCGAGTGCGGCACCTTCAGCGCAAACTGTCGCGTAAGCATGGCCCGGATAAGAGGACGAAAACCACGCCCTCGAATCGGTGGATTCGCGCGAACAACCAAGTCAATAAGTATCGCGCGAAACTGGCTAACATACGTCGCGATCTTGCGGCGAAGGCTGCTCATGGGTTGGCGACGAATTATGAGACCGTCGTCATCGAGGACTTGAACGTTCAAGCCATGATGACGCGCGGAGGCGCACACAAACGTGGTCTGAATCGCGCGATAGCGCAGGCCTCATTTGCCGATGTCAGGCGACGAATCACCTACAAAACGAGGTGGAATGGCGGTAGAACCGTCATTGCCGATCGGTGGTTTCCATCGTCGAAAACGTGTTCGGAATGTGGAGAAGTGAAATCCAAGCTCTCCTTGTCCGAGCGTGAATACATCTGCCATCGTTGCGGTGTTGTCGTGGACAGAGACCTCAATGCTGCAACAAATCTGGCGAAATTAGCGGCACCGAAATCCGGTGTCGATTTTCACGGAACCGGGAGTTCGCCGGGGATGGGACGTGGAGGCGCGGGGAAGACCAACTCATCCTCGGGTGAGCTGGCACCGGCCGGTGAAGCGTCAATGGCCCGAAAGGACCTGAGCGGCCGCAAGGCCGGCACGAGATAA\">Copy to clipboard</span><br>\n</div>"
                    }
                ],
                "clusters": [
                    {
                        "start": 1,
                        "end": 28235,
                        "tool": "",
                        "neighbouring_start": 0,
                        "neighbouring_end": 28236,
                        "product": "CC 1: neighbouring",
                        "kind": "candidatecluster",
                        "prefix": "",
                        "height": 0
                    },
                    {
                        "start": 2,
                        "end": 24859,
                        "tool": "",
                        "neighbouring_start": 1,
                        "neighbouring_end": 24860,
                        "product": "CC 2: single",
                        "kind": "candidatecluster",
                        "prefix": "",
                        "height": 1
                    },
                    {
                        "start": 4939,
                        "end": 8236,
                        "tool": "rule-based-clusters",
                        "neighbouring_start": 0,
                        "neighbouring_end": 28236,
                        "product": "NRPS",
                        "height": 3,
                        "kind": "protocluster",
                        "prefix": ""
                    },
                    {
                        "start": 3177,
                        "end": 4917,
                        "tool": "rule-based-clusters",
                        "neighbouring_start": 1,
                        "neighbouring_end": 24860,
                        "product": "NRPS-like",
                        "height": 5,
                        "kind": "protocluster",
                        "prefix": ""
                    }
                ],
                "ttaCodons": [],
                "type": "NRPS,NRPS-like",
                "products": [
                    "NRPS",
                    "NRPS-like"
                ],
                "anchor": "r2c1"
            }
        ]
    }
];
var all_regions = {
    "order": [
        "r1c1",
        "r2c1"
    ],
    "r1c1": {
        "start": 1703547,
        "end": 1713879,
        "idx": 1,
        "orfs": [
            {
                "start": 1703829,
                "end": 1704422,
                "strand": 1,
                "locus_tag": "AAA_01665",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01665</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01665</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,703,829 - 1,704,422,\n (total: 594 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01850.21 (PIN domain): [4:117](score: 30.3, e-value: 4.9e-07)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTLVVEVSVLAEMLVGSTVGCAAWQQWGGEEFIAPQHLSAEIAHVVRNLSLGQLITDAEAMQILSDFRAFKVELYPVEPLMVDAWEMRHNVSAYDALYVVLARLLGACLLTRDHRLKPRAVLGRSPLRTDLTGRGSRSIRRAISFGSTPRPTRCALGPEPDCPAQSLGASSGSLACSACSDKAARSDLVWDASRGPP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1693829&amp;to=1714422\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTLVVEVSVLAEMLVGSTVGCAAWQQWGGEEFIAPQHLSAEIAHVVRNLSLGQLITDAEAMQILSDFRAFKVELYPVEPLMVDAWEMRHNVSAYDALYVVLARLLGACLLTRDHRLKPRAVLGRSPLRTDLTGRGSRSIRRAISFGSTPRPTRCALGPEPDCPAQSLGASSGSLACSACSDKAARSDLVWDASRGPP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACACTTGTCGTCGAAGTGTCCGTGCTCGCTGAAATGCTCGTTGGTAGCACGGTTGGGTGTGCGGCATGGCAGCAATGGGGCGGCGAGGAGTTCATTGCCCCCCAGCATCTGTCTGCAGAGATTGCCCATGTCGTACGAAACCTCTCCTTGGGGCAACTCATCACCGATGCGGAGGCAATGCAGATATTGTCGGACTTCCGAGCATTCAAGGTGGAGTTGTATCCGGTGGAACCACTGATGGTGGATGCGTGGGAGATGCGGCACAACGTGTCTGCTTATGATGCGCTGTACGTGGTGCTGGCGCGTCTGTTGGGTGCGTGTCTGTTGACGCGTGACCATCGTCTGAAGCCCAGGGCTGTGCTGGGCCGTTCGCCCTTGAGGACGGACCTCACCGGACGGGGGTCTCGGTCGATTCGTCGGGCGATCTCTTTTGGCTCCACCCCTCGGCCAACAAGGTGCGCACTAGGTCCTGAGCCTGACTGTCCTGCTCAGTCACTGGGCGCCTCCTCGGGAAGTCTTGCTTGCTCGGCCTGCTCTGACAAAGCGGCCCGTTCCGATCTGGTTTGGGACGCCTCTAGGGGCCCTCCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1704320,
                "end": 1704652,
                "strand": -1,
                "locus_tag": "AAA_01666",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01666</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01666</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,704,320 - 1,704,652,\n (total: 333 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MHHRGASLTAAVITIAALASGCQSNSSASAPSPTPTPTVTSATPSPTPSAGAVYTSSVATWTLHPSGQGRTAAPHGCHGGPLEASQTRSERAALSEQAEQARLPEEAPSD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1694320&amp;to=1714652\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MHHRGASLTAAVITIAALASGCQSNSSASAPSPTPTPTVTSATPSPTPSAGAVYTSSVATWTLHPSGQGRTAAPHGCHGGPLEASQTRSERAALSEQAEQARLPEEAPSD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCACCATCGTGGCGCATCCCTGACCGCAGCTGTTATCACGATCGCAGCCCTGGCCAGTGGCTGCCAATCCAACAGTTCAGCATCCGCACCCTCACCCACGCCGACCCCGACTGTTACCTCGGCTACCCCCAGCCCGACCCCGTCAGCCGGAGCGGTCTACACCAGCAGCGTGGCCACCTGGACGCTCCACCCAAGTGGGCAAGGACGGACGGCTGCGCCTCACGGGTGTCATGGAGGGCCCCTAGAGGCGTCCCAAACCAGATCGGAACGGGCCGCTTTGTCAGAGCAGGCCGAGCAAGCAAGACTTCCCGAGGAGGCGCCCAGTGACTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1704690,
                "end": 1704917,
                "strand": -1,
                "locus_tag": "AAA_01667",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01667</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01667</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,704,690 - 1,704,917,\n (total: 228 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MELARWALTQGLLVSPDHEDLVAGCLRTEYQAGNMDKVCELVDHLSATARRLGVDLGEDTTRIIDTVTDTHTRAS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1694690&amp;to=1714917\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MELARWALTQGLLVSPDHEDLVAGCLRTEYQAGNMDKVCELVDHLSATARRLGVDLGEDTTRIIDTVTDTHTRAS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGGAGTTGGCCCGGTGGGCCCTGACCCAAGGACTCCTCGTATCACCCGATCATGAGGACCTGGTCGCCGGATGCCTACGCACCGAGTACCAGGCCGGGAACATGGACAAAGTCTGCGAACTCGTCGATCACCTGTCGGCCACCGCCCGCCGGCTGGGCGTCGACCTGGGCGAAGACACCACCCGCATCATCGATACGGTCACCGATACACACACAAGAGCGTCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1705288,
                "end": 1705446,
                "strand": 1,
                "locus_tag": "AAA_01668",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01668</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01668</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,705,288 - 1,705,446,\n (total: 159 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKLTTTLEHRTRSVQSPITSAFGGASVTVDLLAPGGSTCSSAGSRRPARRAL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1695288&amp;to=1715446\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKLTTTLEHRTRSVQSPITSAFGGASVTVDLLAPGGSTCSSAGSRRPARRAL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAGCTCACCACCACCCTTGAGCATCGCACCCGCAGCGTTCAGAGCCCGATCACCTCGGCCTTCGGCGGCGCCTCGGTCACCGTCGACCTCTTGGCCCCGGGTGGCTCGACTTGCTCCAGCGCTGGCTCTCGTCGTCCTGCTCGACGTGCGCTGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1705537,
                "end": 1705833,
                "strand": -1,
                "locus_tag": "AAA_01669",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01669</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01669</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,705,537 - 1,705,833,\n (total: 297 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01061.24 (ABC-2 type transporter): [1:61](score: 38.0, e-value: 1.2e-09)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSYALALRTKSEAALSAIFNVALLPLLLLSGIMLPLSFAPRWIGAVARFNPLWYLVSGTRDQFERGDLTGSAVIAWAIAFGGMVVAYLWGSHEFGKRR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1695537&amp;to=1715833\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_01669_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSYALALRTKSEAALSAIFNVALLPLLLLSGIMLPLSFAPRWIGAVARFNPLWYLVSGTRDQFERGDLTGSAVIAWAIAFGGMVVAYLWGSHEFGKRR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCCTACGCTCTGGCGCTGCGGACTAAGAGCGAAGCAGCCTTGTCCGCGATCTTCAATGTCGCCCTGCTGCCCCTCCTCCTGCTATCGGGGATCATGCTGCCGCTGTCCTTCGCCCCGCGCTGGATCGGAGCCGTCGCTCGCTTCAATCCGCTCTGGTACCTCGTGTCAGGCACGCGTGATCAGTTCGAGCGAGGTGATCTCACCGGCTCAGCTGTCATCGCATGGGCTATCGCCTTTGGCGGGATGGTCGTGGCATATCTCTGGGGCTCCCACGAGTTTGGGAAGCGTCGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1705940,
                "end": 1706269,
                "strand": -1,
                "locus_tag": "AAA_01670",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01670</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01670</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,705,940 - 1,706,269,\n (total: 330 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01061.24 (ABC-2 type transporter): [2:92](score: 30.4, e-value: 2.4e-07)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTACFRRYLTLAARNRRDFALSFVQPLVYIVLFGPLFVASVNMAQHLTQGRSYALYVSGLCLQIAMTIGAFSGLSIILEYRLGILERIWSTPSLAAQRSGGESAATWCS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1695940&amp;to=1716269\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTACFRRYLTLAARNRRDFALSFVQPLVYIVLFGPLFVASVNMAQHLTQGRSYALYVSGLCLQIAMTIGAFSGLSIILEYRLGILERIWSTPSLAAQRSGGESAATWCS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGGCATGCTTCCGCAGGTATCTGACGTTGGCGGCGCGCAATCGCCGTGATTTCGCGTTGTCATTCGTTCAACCGCTCGTGTACATCGTGTTGTTCGGGCCACTCTTCGTCGCCTCGGTGAACATGGCGCAACACTTGACACAGGGCCGCTCGTATGCGCTGTACGTGAGTGGACTCTGCCTCCAGATCGCCATGACCATCGGCGCGTTCTCGGGGCTGTCGATCATCTTGGAGTATCGACTCGGAATCTTGGAACGCATATGGAGCACCCCCTCACTGGCCGCGCAGCGATCGGGGGGCGAATCGGCAGCGACGTGGTGCTCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1706266,
                "end": 1707246,
                "strand": -1,
                "locus_tag": "AAA_01671",
                "type": "transport",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01671</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01671</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,706,266 - 1,707,246,\n (total: 981 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 170.1; E-value: 1e-51)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00005.27 (ABC transporter): [32:172](score: 95.1, e-value: 4.9e-27)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDANASSPVPTTLSIRNLVKKYKVRGGYQVPALNGVSLELGRGEMLSLFGPNGAGKTTLVRIIAGLLSADSGTIEWPGNESRNPRSLLGYVSQKGGLQYGLTCREEMTFHVRCFGLGDREAARRVERVTEMLHCGYLLDWNVDRLSGGQRRVVEVGMALLHEPAVILLDEPTLGLDPATRLSLWETVGSARRESDAAFLVTTHYIDEVAQQLSNVSVINHGTVIASGTPEELQSTYSTGSVSIMVPRERLSEATQALQPISPDVYAVSGKVVVPAPSPDRVVTAALQALEGHGIRALAVAVRKPSLNEAFLALTSTPSASEGEWTA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1696266&amp;to=1717246\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_01671_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%0AMDANASSPVPTTLSIRNLVKKYKVRGGYQVPALNGVSLELGRGEMLSLFGPNGAGKTTLVRIIAGLLSADSGTIEWPGNESRNPRSLLGYVSQKGGLQYGLTCREEMTFHVRCFGLGDREAARRVERVTEMLHCGYLLDWNVDRLSGGQRRVVEVGMALLHEPAVILLDEPTLGLDPATRLSLWETVGSARRESDAAFLVTTHYIDEVAQQLSNVSVINHGTVIASGTPEELQSTYSTGSVSIMVPRERLSEATQALQPISPDVYAVSGKVVVPAPSPDRVVTAALQALEGHGIRALAVAVRKPSLNEAFLALTSTPSASEGEWTA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDANASSPVPTTLSIRNLVKKYKVRGGYQVPALNGVSLELGRGEMLSLFGPNGAGKTTLVRIIAGLLSADSGTIEWPGNESRNPRSLLGYVSQKGGLQYGLTCREEMTFHVRCFGLGDREAARRVERVTEMLHCGYLLDWNVDRLSGGQRRVVEVGMALLHEPAVILLDEPTLGLDPATRLSLWETVGSARRESDAAFLVTTHYIDEVAQQLSNVSVINHGTVIASGTPEELQSTYSTGSVSIMVPRERLSEATQALQPISPDVYAVSGKVVVPAPSPDRVVTAALQALEGHGIRALAVAVRKPSLNEAFLALTSTPSASEGEWTA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGGACGCGAACGCCTCCTCGCCTGTTCCCACGACCCTGTCCATCAGGAATCTCGTCAAGAAGTACAAGGTCCGGGGCGGGTACCAGGTCCCCGCTCTCAACGGGGTCTCGCTTGAGCTCGGTCGCGGTGAGATGCTCAGTCTGTTCGGTCCCAACGGTGCAGGAAAGACCACCTTGGTCAGGATCATTGCAGGGCTCCTGTCGGCAGACTCTGGGACGATCGAATGGCCCGGCAACGAGAGTCGGAACCCGAGGTCGTTGCTGGGGTACGTTTCGCAGAAGGGCGGCCTGCAGTACGGACTGACGTGCCGCGAAGAGATGACCTTTCATGTCCGTTGCTTCGGTCTGGGGGACCGCGAGGCTGCGCGGCGCGTTGAAAGAGTCACCGAGATGCTCCATTGTGGCTACCTGCTCGACTGGAACGTAGACCGCCTGTCCGGTGGGCAACGACGTGTCGTCGAAGTGGGTATGGCACTGCTGCACGAGCCGGCGGTGATCCTCCTGGACGAACCGACTCTCGGGCTCGACCCGGCCACGCGTCTATCCCTGTGGGAGACGGTGGGCTCGGCTAGGCGGGAGTCCGATGCAGCCTTCCTTGTGACCACGCATTACATCGACGAAGTCGCGCAGCAGCTCTCCAATGTGAGCGTCATCAACCATGGCACGGTCATCGCGTCAGGCACCCCGGAAGAGCTGCAATCCACGTACTCCACCGGCAGTGTCTCGATCATGGTTCCAAGGGAGCGACTAAGTGAGGCGACCCAAGCACTGCAACCAATCTCCCCAGACGTCTATGCGGTGTCCGGCAAGGTCGTAGTGCCGGCCCCGTCGCCGGATCGAGTGGTCACGGCGGCACTGCAGGCTTTGGAGGGCCATGGCATCCGTGCGTTGGCGGTCGCCGTTCGCAAACCATCCCTCAATGAGGCATTCCTGGCGCTGACCTCGACCCCGTCCGCATCAGAAGGAGAATGGACCGCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1707256,
                "end": 1707768,
                "strand": -1,
                "locus_tag": "AAA_01672",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01672</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01672</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,707,256 - 1,707,768,\n (total: 513 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MFMPTRNVYVSDKDQALFREAAEIAGGLSPAVSEALHEYVQRRRLVAASLKQIEVDLRSEGVDRRVSFMGRRLARVQRDHKQGHRVDTVYVTAKSQIAVVSKVQRSLPGWAEGRENLWSHPETWDRNFWTAGDRTLAVFADLDELRTADTDLADRVESAMRVVPYQVLDI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1697256&amp;to=1717768\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MFMPTRNVYVSDKDQALFREAAEIAGGLSPAVSEALHEYVQRRRLVAASLKQIEVDLRSEGVDRRVSFMGRRLARVQRDHKQGHRVDTVYVTAKSQIAVVSKVQRSLPGWAEGRENLWSHPETWDRNFWTAGDRTLAVFADLDELRTADTDLADRVESAMRVVPYQVLDI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTTCATGCCTACTCGAAACGTGTACGTGTCTGACAAAGACCAGGCTTTGTTCCGCGAGGCGGCCGAGATAGCGGGAGGATTGTCGCCGGCGGTCAGTGAGGCCTTGCATGAGTACGTCCAACGCCGTCGGCTTGTGGCGGCGAGTCTCAAGCAGATCGAGGTGGACCTGCGCAGTGAGGGTGTTGATCGCCGTGTCTCTTTCATGGGTAGACGACTGGCGCGGGTGCAACGGGACCACAAACAGGGCCACCGTGTCGACACCGTGTACGTAACGGCCAAGAGCCAGATCGCCGTTGTGTCCAAGGTTCAGCGTTCCCTGCCTGGTTGGGCCGAGGGGAGAGAGAATCTCTGGTCTCATCCGGAGACCTGGGACAGGAACTTCTGGACGGCTGGGGACCGCACCCTCGCCGTCTTCGCAGACTTGGACGAGCTGCGCACCGCCGATACCGACCTTGCTGATCGGGTGGAGTCGGCAATGCGAGTCGTGCCCTACCAGGTTCTGGACATCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1708022,
                "end": 1708243,
                "strand": 1,
                "locus_tag": "AAA_01673",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01673</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01673</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,708,022 - 1,708,243,\n (total: 222 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF10991.8 (Protein of unknown function (DUF2815)): [8:50](score: 43.7, e-value: 2.7e-11)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSTTNPTRVVTGEVRLSYTNIFEAKSIQGGKPKYSVSVIIPKGERVTGIEPAYPARESDPRLDSGVPTSLWER&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1698022&amp;to=1718243\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSTTNPTRVVTGEVRLSYTNIFEAKSIQGGKPKYSVSVIIPKGERVTGIEPAYPARESDPRLDSGVPTSLWER\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCTACAACTAATCCGACCCGTGTGGTCACCGGCGAAGTCCGCCTGTCCTACACCAACATCTTCGAGGCGAAGAGTATCCAGGGCGGAAAGCCCAAGTACTCCGTCAGCGTGATCATCCCGAAGGGCGAGCGGGTGACGGGAATCGAACCCGCATATCCAGCTCGGGAATCCGATCCACGGTTGGATTCAGGCGTGCCGACGAGCTTATGGGAGCGGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1708547,
                "end": 1708879,
                "strand": 1,
                "locus_tag": "AAA_01674",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01674</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01674</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,708,547 - 1,708,879,\n (total: 333 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RiPP-like: Lactococcin_972<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF09683.10 (Bacteriocin (Lactococcin_972)): [52:107](score: 42.4, e-value: 7.7e-11)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MFSSPLQGNHNWKIPRYYLSEEKDTRKVLGIAAAVAVFVGVGTLPALAWDNAGGGLWDHGSDMSSVWSNYYHRTSNHGSTAAGNEVKYSGCKRPTVTSHASAPLSWYKTV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1698547&amp;to=1718879\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MFSSPLQGNHNWKIPRYYLSEEKDTRKVLGIAAAVAVFVGVGTLPALAWDNAGGGLWDHGSDMSSVWSNYYHRTSNHGSTAAGNEVKYSGCKRPTVTSHASAPLSWYKTV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTTCAGTAGCCCCCTGCAAGGGAATCACAATTGGAAGATTCCTCGATATTATCTCAGTGAGGAGAAAGACACGCGTAAGGTGCTAGGGATTGCTGCAGCGGTGGCGGTCTTCGTTGGAGTGGGTACGCTTCCGGCATTGGCTTGGGACAACGCTGGTGGAGGGTTGTGGGATCATGGATCGGATATGTCGAGCGTCTGGTCTAATTATTATCACCGGACCTCTAACCATGGATCCACGGCAGCGGGCAACGAGGTCAAGTACTCCGGATGTAAGCGCCCCACGGTGACGTCGCATGCATCGGCGCCGCTCTCCTGGTACAAGACGGTATAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1709026,
                "end": 1710342,
                "strand": 1,
                "locus_tag": "AAA_01675",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01675</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01675</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,709,026 - 1,710,342,\n (total: 1317 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPSRVLKFSFVFMLILTLGMAFAVLRDYDGQTLTGCHYSLIVDGPLKRVEDSFKGLVSKLQSFSENHSVMIAKRDIGLDETQAARVVYVTSGSSLGREWLGEGYPSVNTDLTTVVKPIADVAVLDPRGIYLTTASRVQTEEIASIFQEAGLGVQVENERSVQRIVGFYFHSGPFAILIATIAVCSAIFLLGALILDLRRYTTQVLNGWSIGNIVASDGICIARVCLLWLLVLGAISFGGLVIFSGVTAATILVFLWLGMFIPGALLLLVLERVSLGIIFSDSIGTLLKGGVNSKYLVILLRGIQVLCICIAISLSNSLAAGVAQANSIARSNADWERFAHLAVVGLKTAQSVDGDMPVQVGSYGARELTSGRAVLALNSDPQASLGEVPSSFSGWKVLVVNDTYLRVSGMSKGWGVDEDSSDVQVLTPRGFLGTDSEN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1699026&amp;to=1720342\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPSRVLKFSFVFMLILTLGMAFAVLRDYDGQTLTGCHYSLIVDGPLKRVEDSFKGLVSKLQSFSENHSVMIAKRDIGLDETQAARVVYVTSGSSLGREWLGEGYPSVNTDLTTVVKPIADVAVLDPRGIYLTTASRVQTEEIASIFQEAGLGVQVENERSVQRIVGFYFHSGPFAILIATIAVCSAIFLLGALILDLRRYTTQVLNGWSIGNIVASDGICIARVCLLWLLVLGAISFGGLVIFSGVTAATILVFLWLGMFIPGALLLLVLERVSLGIIFSDSIGTLLKGGVNSKYLVILLRGIQVLCICIAISLSNSLAAGVAQANSIARSNADWERFAHLAVVGLKTAQSVDGDMPVQVGSYGARELTSGRAVLALNSDPQASLGEVPSSFSGWKVLVVNDTYLRVSGMSKGWGVDEDSSDVQVLTPRGFLGTDSEN\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCATCCCGGGTCCTGAAATTCAGCTTCGTATTCATGCTCATTCTTACCTTGGGTATGGCATTCGCAGTGTTGCGAGACTATGACGGTCAGACTCTCACCGGATGCCATTACTCCCTGATTGTAGATGGGCCGTTGAAGAGGGTTGAGGATTCCTTTAAGGGCCTTGTATCAAAGCTGCAATCCTTTTCGGAGAATCATTCCGTAATGATTGCGAAGCGTGACATTGGACTGGATGAGACTCAGGCTGCCAGAGTGGTTTACGTGACTTCGGGGTCCTCTTTGGGACGCGAGTGGCTGGGGGAGGGTTATCCCAGTGTGAACACCGATCTGACCACAGTGGTTAAACCGATTGCCGATGTAGCCGTATTGGATCCCCGTGGGATCTATCTGACGACGGCGAGTAGAGTACAGACGGAAGAGATTGCCTCCATTTTTCAAGAAGCTGGACTGGGCGTCCAAGTCGAAAATGAACGATCGGTTCAAAGAATTGTGGGATTTTATTTCCACAGCGGTCCCTTTGCGATTTTGATTGCAACAATTGCTGTATGCTCTGCGATCTTTCTTCTCGGGGCCCTAATTTTAGATCTGCGACGCTATACGACTCAAGTGCTCAACGGATGGAGCATTGGTAATATTGTCGCCTCCGATGGCATTTGTATTGCGAGGGTTTGCCTACTTTGGCTGTTGGTGCTAGGTGCCATTTCATTCGGGGGCCTGGTGATTTTTAGTGGTGTCACTGCGGCAACGATCTTGGTATTCCTCTGGTTGGGAATGTTTATTCCCGGGGCCCTTCTCCTACTTGTCTTGGAGAGAGTTTCCCTAGGAATTATCTTTTCTGACAGTATCGGGACCCTACTTAAGGGCGGGGTTAATTCAAAGTACCTGGTAATACTTTTGAGGGGCATCCAAGTCTTATGTATCTGTATAGCCATTTCGTTGAGTAATAGTCTAGCTGCCGGAGTTGCTCAGGCTAACTCGATTGCAAGATCAAACGCTGACTGGGAAAGATTTGCTCACCTAGCGGTAGTTGGGCTGAAGACGGCACAGTCTGTTGATGGTGACATGCCGGTACAGGTGGGGTCTTATGGCGCTCGTGAGCTGACGTCTGGGCGAGCCGTTCTCGCGCTCAACTCTGACCCCCAGGCCAGCTTAGGTGAGGTACCCTCGAGCTTTTCCGGATGGAAGGTGCTCGTGGTGAACGACACTTACCTGCGTGTGAGCGGAATGTCCAAGGGGTGGGGTGTAGACGAAGATAGTTCCGACGTTCAAGTGCTTACTCCGAGAGGTTTCTTGGGAACTGATAGCGAAAATTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1710434,
                "end": 1711093,
                "strand": 1,
                "locus_tag": "AAA_01676",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01676</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01676</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,710,434 - 1,711,093,\n (total: 660 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTIGAVPPIGSVGESSSRYARTIIAVLPEKFGKLSPNDVMAMISNGSILFTSARKVVDDVSQDAGLTRYVSSVTPLQSVALKKEEDLLNSNSQLLAALLLSISALLGMSLANDIVYFKISRQRIKAQLMNGWFSIRMHWLFECTELLLVSAVIYWQYYRQHSYGVILANPQSTSFAYFKASLAVSRWAVPGAVAVSLISLLGAGGALVLGTRRILRNKF&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1700434&amp;to=1721093\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTIGAVPPIGSVGESSSRYARTIIAVLPEKFGKLSPNDVMAMISNGSILFTSARKVVDDVSQDAGLTRYVSSVTPLQSVALKKEEDLLNSNSQLLAALLLSISALLGMSLANDIVYFKISRQRIKAQLMNGWFSIRMHWLFECTELLLVSAVIYWQYYRQHSYGVILANPQSTSFAYFKASLAVSRWAVPGAVAVSLISLLGAGGALVLGTRRILRNKF\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACTATCGGCGCGGTTCCCCCTATCGGCTCTGTCGGAGAGTCGTCATCTCGTTACGCGCGGACCATCATCGCGGTGCTACCTGAGAAATTTGGAAAACTCTCGCCTAATGATGTGATGGCAATGATTAGTAACGGATCAATCTTGTTTACGAGCGCACGCAAGGTGGTTGATGACGTGTCTCAGGATGCTGGCTTGACGAGATATGTTTCCTCAGTAACTCCGCTGCAGAGTGTTGCTCTCAAGAAGGAGGAGGATCTGTTGAATTCGAACTCTCAACTGCTCGCGGCGCTACTCTTATCGATTTCAGCCCTGCTGGGTATGTCCCTGGCCAACGACATCGTGTATTTCAAAATTTCCAGGCAACGTATTAAGGCGCAGCTGATGAATGGCTGGTTCAGTATAAGAATGCACTGGCTATTTGAATGCACTGAGTTGCTCTTGGTGAGTGCTGTGATTTATTGGCAATATTATCGACAGCACTCTTATGGGGTGATTTTAGCTAATCCACAATCGACATCATTTGCCTATTTCAAGGCAAGCCTTGCGGTGAGTAGGTGGGCTGTACCTGGAGCTGTTGCTGTCTCGCTTATCTCCCTTCTGGGTGCTGGGGGTGCCTTAGTGCTTGGAACTCGGCGCATTCTGCGCAATAAGTTCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1711142,
                "end": 1711780,
                "strand": 1,
                "locus_tag": "AAA_01677",
                "type": "transport",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01677</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01677</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,711,142 - 1,711,780,\n (total: 639 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1000:ABC transporter ATP-binding protein (Score: 170.2; E-value: 9.6e-52)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00005.27 (ABC transporter): [19:165](score: 108.8, e-value: 2.9e-31)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSLGVENLSKSFGSRELWRGISFEVSRGKIFGITGPSGGGKTTLLNCLGALEKPTSGNIFLNGRRISGLSVRKSRRLWAKDIGFLFQDYALVDRMNVRSNVSMGVPHLIGRRGLDDGISSALAGVGLPGCGVNPTYQLSGGEQQRVALARLMLKSPSLVLADEPTGSLDALNEEMVLKHLRSFAKQGSMVVVASHSNSVLECCDQVLEVGLH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1701142&amp;to=1721780\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_01677_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%0AMSLGVENLSKSFGSRELWRGISFEVSRGKIFGITGPSGGGKTTLLNCLGALEKPTSGNIFLNGRRISGLSVRKSRRLWAKDIGFLFQDYALVDRMNVRSNVSMGVPHLIGRRGLDDGISSALAGVGLPGCGVNPTYQLSGGEQQRVALARLMLKSPSLVLADEPTGSLDALNEEMVLKHLRSFAKQGSMVVVASHSNSVLECCDQVLEVGLH\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSLGVENLSKSFGSRELWRGISFEVSRGKIFGITGPSGGGKTTLLNCLGALEKPTSGNIFLNGRRISGLSVRKSRRLWAKDIGFLFQDYALVDRMNVRSNVSMGVPHLIGRRGLDDGISSALAGVGLPGCGVNPTYQLSGGEQQRVALARLMLKSPSLVLADEPTGSLDALNEEMVLKHLRSFAKQGSMVVVASHSNSVLECCDQVLEVGLH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGTCTTGGCGTCGAAAATCTAAGTAAGAGTTTTGGCTCGAGGGAGCTGTGGCGGGGAATATCCTTTGAAGTCTCTCGAGGGAAGATTTTTGGGATCACTGGCCCGAGTGGAGGTGGGAAGACCACGCTCCTGAACTGTCTCGGAGCACTAGAAAAACCTACGAGCGGGAATATTTTTCTGAATGGCAGGCGTATATCGGGTTTGAGTGTGCGTAAATCCAGAAGGCTTTGGGCTAAAGACATCGGTTTTCTATTTCAGGACTACGCCCTGGTAGATCGCATGAACGTCCGTTCGAATGTTTCTATGGGTGTTCCCCATTTGATAGGTAGACGAGGCTTGGATGATGGAATCAGCTCAGCGCTGGCGGGTGTGGGGCTGCCAGGATGTGGGGTGAACCCTACCTATCAGCTTTCAGGGGGTGAGCAGCAGCGTGTTGCTCTTGCTCGTCTTATGCTCAAGAGCCCGTCCCTAGTGCTTGCGGATGAGCCGACTGGTTCTCTCGACGCGTTGAATGAGGAGATGGTGTTGAAGCATCTTCGGTCATTTGCTAAGCAGGGATCCATGGTGGTTGTCGCGTCGCATAGCAACTCTGTTTTGGAGTGCTGTGACCAAGTGCTGGAGGTTGGCCTCCATTAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1712373,
                "end": 1712579,
                "strand": -1,
                "locus_tag": "AAA_01678",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01678</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01678</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,712,373 - 1,712,579,\n (total: 207 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MFRISADNHARAPRTLFHERYEVTRTSALLNGHPSRPNKNMTVRDAVVSVGNFATGEGAEVKNVPAST&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1702373&amp;to=1722579\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MFRISADNHARAPRTLFHERYEVTRTSALLNGHPSRPNKNMTVRDAVVSVGNFATGEGAEVKNVPAST\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGTTCCGAATATCGGCAGATAACCATGCCCGCGCTCCACGAACGTTATTCCACGAACGTTATGAGGTGACGCGCACCAGTGCCCTGCTCAACGGCCACCCCAGCAGGCCGAACAAAAATATGACTGTACGCGACGCCGTGGTCTCGGTAGGCAACTTCGCGACAGGCGAAGGGGCTGAGGTCAAGAACGTGCCCGCGTCAACGTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1713148,
                "end": 1713330,
                "strand": -1,
                "locus_tag": "AAA_01679",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01679</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01679</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,713,148 - 1,713,330,\n (total: 183 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MQLIAPADRLGLVGISLNMLYQDISNALLVELVENGLHTYQRSPLIQTTTPHTSRMSKKA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1703148&amp;to=1723330\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MQLIAPADRLGLVGISLNMLYQDISNALLVELVENGLHTYQRSPLIQTTTPHTSRMSKKA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCAACTGATCGCGCCTGCAGATCGGCTGGGCCTGGTCGGCATCAGCCTCAACATGCTGTACCAGGACATTTCGAATGCTCTGCTGGTCGAGCTCGTCGAGAACGGCTTACACACCTACCAGCGCTCTCCCTTGATCCAGACTACGACGCCACATACCAGCAGGATGTCAAAGAAGGCTTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1713397,
                "end": 1713606,
                "strand": -1,
                "locus_tag": "AAA_01680",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_01680</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_01680</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,713,397 - 1,713,606,\n (total: 210 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLGEALRPSRADVVVTAYSLHGLSLDARLPDTFERKPHYPTTKDIDLVQMRADLDRVIASLHPNSNNGP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017040.1&amp;from=1703397&amp;to=1723606\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLGEALRPSRADVVVTAYSLHGLSLDARLPDTFERKPHYPTTKDIDLVQMRADLDRVIASLHPNSNNGP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTTGGCGAGGCCCTTCGCCCTTCCCGCGCAGACGTGGTAGTGACCGCTTACTCACTGCACGGGCTCTCACTCGACGCACGGCTGCCGGACACTTTCGAACGCAAGCCGCACTACCCGACGACGAAGGACATCGATCTGGTCCAAATGCGAGCCGACCTCGATCGAGTGATCGCGTCACTCCACCCCAATTCCAATAACGGGCCATAG\">Copy to clipboard</span><br>\n</div>"
            }
        ],
        "clusters": [
            {
                "start": 1708546,
                "end": 1708879,
                "tool": "rule-based-clusters",
                "neighbouring_start": 1703546,
                "neighbouring_end": 1713879,
                "product": "RiPP-like",
                "height": 2,
                "kind": "protocluster",
                "prefix": ""
            }
        ],
        "ttaCodons": [],
        "type": "RiPP-like",
        "products": [
            "RiPP-like"
        ],
        "anchor": "r1c1"
    },
    "r2c1": {
        "start": 1,
        "end": 28236,
        "idx": 1,
        "orfs": [
            {
                "start": 2,
                "end": 583,
                "strand": -1,
                "locus_tag": "AAA_02515",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02515</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02515</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2 - 583,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKTIGTRSKPSKSRLPGRVFNLIMADQVLSQSSYFALLPVLPLLLTLKFGSTQERLIAGSVSVLTLMTRGGALFLASPLHRLSVRSCVRIALTLISVSYAVVALTANPYAIIAALGAAGLGFSVNGTGVRSFIALATPDRASQNRGFAVIQVVANCTAAVGPILGNMILDRNIYEQFLLGVSVALFIAAILAPM&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=0&amp;to=10583\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKTIGTRSKPSKSRLPGRVFNLIMADQVLSQSSYFALLPVLPLLLTLKFGSTQERLIAGSVSVLTLMTRGGALFLASPLHRLSVRSCVRIALTLISVSYAVVALTANPYAIIAALGAAGLGFSVNGTGVRSFIALATPDRASQNRGFAVIQVVANCTAAVGPILGNMILDRNIYEQFLLGVSVALFIAAILAPM\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGAAGACAATAGGGACACGAAGTAAACCGTCGAAGTCTCGGCTTCCTGGGCGCGTATTCAACCTCATTATGGCAGACCAAGTTCTCAGCCAATCATCTTACTTTGCGTTGCTACCGGTCCTCCCTCTATTGCTTACATTGAAATTTGGAAGTACGCAGGAACGACTCATCGCGGGGTCGGTAAGCGTGCTTACACTGATGACTCGTGGTGGTGCTCTATTTCTTGCTTCGCCACTTCACCGTTTATCAGTGCGAAGTTGCGTAAGAATTGCTCTTACTCTGATCTCGGTTTCTTACGCTGTTGTGGCGCTTACGGCAAACCCCTATGCGATAATTGCTGCTCTGGGCGCTGCGGGCCTAGGGTTCAGTGTTAATGGTACTGGTGTGCGAAGCTTTATAGCGCTAGCAACTCCTGATAGAGCTTCCCAAAACCGCGGTTTCGCTGTCATTCAAGTTGTCGCGAATTGCACTGCGGCGGTAGGTCCTATTCTCGGTAATATGATACTTGATAGAAATATTTATGAGCAGTTTCTATTAGGAGTCAGTGTAGCGCTCTTTATCGCTGCGATATTAGCGCCAATG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1174,
                "end": 2481,
                "strand": -1,
                "locus_tag": "AAA_02516",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02516</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02516</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,174 - 2,481,\n (total: 1308 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1063:argininosuccinate lyase/adenylosuccinate lyase (Score: 75.8; E-value: 5.9e-23)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF13535.6 (ATP-grasp domain): [183:317](score: 42.6, e-value: 4.6e-11)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MFSRDSVVAERKWAVLVGVTTSGSHASTHWFKSFYEACQKRHIMICGVDFEEELKNKIPPISVDCLIRISGPYRRSLDADEIAKIATEIETRCPGKIALSTALRENYQLQNSLLAEAIGVARNTADCIERIQDKPACRDALRKAGIYQPQSLRIVGVTSDGCLQFSDASGAVVEKPTDSPRGWIVKPSIGMGSVGVRHILNVEDTSGLDAVVLEGNYCLEEFITGIEYSVEGIAIDGRVCIYTTTAKTTNEDFVEIGHIQPADLNSISSKLEFEEQLQSCVNALGIECGNLHVEFWVTPEKKIVWGEFHVRQGGDFIAPDLVSAVRPGIDYYGNLIDSLCGLPLHPLPEITQCAASKFIEASPGVVSEVSLYDSVPEEIDLYWECFPGEVAHAVNGSHARVAAIVARGNDEHTVTQLLDRAANACVVRVAPVSRD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=0&amp;to=12481\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_02516_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MFSRDSVVAERKWAVLVGVTTSGSHASTHWFKSFYEACQKRHIMICGVDFEEELKNKIPPISVDCLIRISGPYRRSLDADEIAKIATEIETRCPGKIALSTALRENYQLQNSLLAEAIGVARNTADCIERIQDKPACRDALRKAGIYQPQSLRIVGVTSDGCLQFSDASGAVVEKPTDSPRGWIVKPSIGMGSVGVRHILNVEDTSGLDAVVLEGNYCLEEFITGIEYSVEGIAIDGRVCIYTTTAKTTNEDFVEIGHIQPADLNSISSKLEFEEQLQSCVNALGIECGNLHVEFWVTPEKKIVWGEFHVRQGGDFIAPDLVSAVRPGIDYYGNLIDSLCGLPLHPLPEITQCAASKFIEASPGVVSEVSLYDSVPEEIDLYWECFPGEVAHAVNGSHARVAAIVARGNDEHTVTQLLDRAANACVVRVAPVSRD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTTTTCTCGTGACAGCGTAGTGGCTGAAAGAAAATGGGCGGTTTTGGTAGGTGTCACCACATCTGGATCTCATGCCTCAACGCATTGGTTTAAAAGCTTCTATGAAGCGTGCCAGAAGCGCCACATAATGATATGTGGCGTAGATTTCGAGGAAGAACTAAAGAACAAAATTCCGCCGATTTCTGTCGATTGTTTAATTAGAATATCCGGACCCTACAGGAGAAGCTTAGATGCTGATGAGATCGCTAAAATAGCGACAGAAATTGAAACCCGATGCCCTGGAAAGATAGCTCTTTCAACGGCACTGCGCGAAAATTATCAGTTGCAGAATAGTCTTTTAGCTGAAGCTATTGGTGTTGCTAGAAATACTGCTGATTGTATTGAACGTATCCAAGATAAACCAGCGTGCCGCGATGCGCTTCGAAAAGCTGGTATCTATCAGCCACAAAGCTTGCGTATTGTTGGAGTGACTTCTGATGGGTGCCTACAATTTAGTGATGCATCAGGCGCTGTCGTTGAAAAACCAACCGATAGCCCAAGAGGCTGGATTGTTAAGCCATCCATAGGAATGGGCAGTGTTGGCGTTAGACACATCTTAAATGTTGAAGATACTTCTGGACTTGATGCTGTCGTTCTCGAGGGGAATTACTGCTTAGAAGAGTTTATCACGGGTATTGAGTACTCAGTTGAGGGTATTGCTATAGATGGACGGGTATGCATCTACACAACCACAGCAAAAACAACCAACGAAGATTTCGTTGAAATTGGTCATATCCAGCCAGCTGATCTGAACAGTATATCCAGCAAACTTGAATTTGAAGAACAGCTTCAAAGCTGTGTAAATGCGCTTGGAATTGAGTGTGGAAATCTGCATGTTGAATTTTGGGTCACACCTGAGAAAAAAATTGTATGGGGAGAATTTCACGTGCGTCAAGGTGGAGATTTTATTGCGCCGGATCTTGTGTCAGCTGTGCGACCAGGGATCGACTACTATGGAAATCTGATTGATTCTTTGTGTGGACTTCCTCTCCATCCTTTGCCTGAGATAACCCAGTGTGCTGCTTCAAAGTTTATCGAAGCCTCGCCTGGAGTGGTATCAGAGGTTTCGCTCTATGACAGTGTCCCTGAAGAAATCGATTTGTATTGGGAATGCTTCCCAGGAGAAGTAGCACATGCAGTAAATGGTTCGCATGCAAGGGTAGCTGCTATTGTTGCCCGTGGTAATGACGAGCATACAGTGACTCAGTTATTGGATCGCGCTGCTAATGCTTGCGTAGTGCGTGTCGCTCCTGTAAGCAGAGATTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 2468,
                "end": 3181,
                "strand": -1,
                "locus_tag": "AAA_02517",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02517</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02517</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,468 - 3,181,\n (total: 714 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1004:thioesterase (Score: 94; E-value: 1.3e-28)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00975.20 (Thioesterase domain): [18:221](score: 45.8, e-value: 7.7e-12)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNPEVWQRISSATTSCCSTVLIFPPTGAGAPAFQSMSVLEGDTTVWGYCPPGRGQRLLEPGIRTMGEFVSKFRSSFEIPTGPLILAGVSFGAMLSFVAANILENDGIFATRLVALCGQSPKSYRGEREGWNLERARQRMRSYGLTPKSILNSDESDDLFVRPTLDDLLLAESCCGNQLKQIHVPITCVSAIDDKIVSSEEAVQWREATSETYRLIEVTGGHYAHEGFGRREWLNVFS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=0&amp;to=13181\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNPEVWQRISSATTSCCSTVLIFPPTGAGAPAFQSMSVLEGDTTVWGYCPPGRGQRLLEPGIRTMGEFVSKFRSSFEIPTGPLILAGVSFGAMLSFVAANILENDGIFATRLVALCGQSPKSYRGEREGWNLERARQRMRSYGLTPKSILNSDESDDLFVRPTLDDLLLAESCCGNQLKQIHVPITCVSAIDDKIVSSEEAVQWREATSETYRLIEVTGGHYAHEGFGRREWLNVFS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"TTGAATCCGGAAGTTTGGCAGCGTATTAGTTCAGCAACTACCTCTTGTTGCTCCACAGTCCTGATATTCCCTCCTACGGGTGCCGGAGCTCCTGCCTTTCAATCGATGTCTGTCTTAGAGGGGGATACTACAGTTTGGGGTTACTGCCCGCCTGGCAGGGGTCAACGATTACTTGAACCCGGCATCAGAACCATGGGAGAGTTCGTCAGCAAGTTTCGATCATCCTTCGAAATTCCGACTGGGCCGTTGATACTCGCCGGGGTTAGCTTTGGCGCGATGTTGTCGTTCGTAGCTGCTAATATTTTAGAAAATGACGGAATTTTCGCGACTCGTTTGGTTGCCTTATGTGGGCAAAGTCCTAAGAGTTACAGGGGGGAGCGAGAGGGATGGAACTTGGAACGTGCACGGCAGCGTATGCGTAGCTACGGATTGACTCCTAAAAGTATTCTGAACTCCGATGAATCCGATGATCTGTTTGTTCGCCCTACGCTCGATGATCTCTTACTGGCGGAATCGTGTTGTGGTAACCAACTTAAGCAGATTCATGTCCCTATAACCTGTGTTTCCGCTATTGATGATAAGATTGTTTCTTCCGAAGAGGCCGTCCAATGGCGTGAAGCTACGAGTGAGACGTACAGATTGATCGAAGTGACCGGAGGGCATTATGCACATGAAGGTTTTGGAAGAAGGGAATGGTTAAATGTTTTCTCGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 3178,
                "end": 4917,
                "strand": -1,
                "locus_tag": "AAA_02518",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02518</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02518</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,178 - 4,917,\n (total: 1740 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 166.1; E-value: 1.6e-50)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00501.28 (AMP-binding enzyme): [103:395](score: 148.0, e-value: 2.9e-43)<br>\n \n  PF00550.25 (Phosphopantetheine attachment site): [506:569](score: 45.4, e-value: 7.6e-12)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MQPSHDLLEGFRNIVIQKPGDVCLTGPAGEQCSWEQLVKNILAWRRWFNREQSEGVTFAARLDLSAKSVALVIAAVTLPVKIAWIPLNIPASRERDMIINLGSKTVLIDDSTAEEAIFAGNWISDVRSLTWSDKSKFLYFTSGSEGVPKAVQVGMDAVRNRITWMWNAYPYESSDLVVVQKPLSFVASFWEVLGTLLAGVTGVLITNIERSRPDVMFDRLASSGATHLFTTPPALASLCDIATEQGSTLPQLRLACSSADQLMASVVRQFFEIAPRARVVNLYGATETSANTTSFEVSRSGSIPDPIPLGEPICATKIVIRDMKGNEKLSGEEGQICVQGAPVADGYIVNGQLSPGDDAFFTLGSGQREIRTGDLGIIKDGVLSLVGRLDNAVNIAGHKIHLEEVERAAARVANSTKQCGAVYHQGSGGFLALVIPREWESQVTTSRLAEFLPSYMIPLKIVTTQNVPRSRTGKIDRCECLKLVAQSELYDHDRISQGQMQRNSVHDQVQNIWDMVLGKKIHGEDRDFFSAGGNSLRAVQLLTAIGKQFGVRVPLRNFYSNPTISCLVSLLMPVEEREH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=0&amp;to=14917\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_02518_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MQPSHDLLEGFRNIVIQKPGDVCLTGPAGEQCSWEQLVKNILAWRRWFNREQSEGVTFAARLDLSAKSVALVIAAVTLPVKIAWIPLNIPASRERDMIINLGSKTVLIDDSTAEEAIFAGNWISDVRSLTWSDKSKFLYFTSGSEGVPKAVQVGMDAVRNRITWMWNAYPYESSDLVVVQKPLSFVASFWEVLGTLLAGVTGVLITNIERSRPDVMFDRLASSGATHLFTTPPALASLCDIATEQGSTLPQLRLACSSADQLMASVVRQFFEIAPRARVVNLYGATETSANTTSFEVSRSGSIPDPIPLGEPICATKIVIRDMKGNEKLSGEEGQICVQGAPVADGYIVNGQLSPGDDAFFTLGSGQREIRTGDLGIIKDGVLSLVGRLDNAVNIAGHKIHLEEVERAAARVANSTKQCGAVYHQGSGGFLALVIPREWESQVTTSRLAEFLPSYMIPLKIVTTQNVPRSRTGKIDRCECLKLVAQSELYDHDRISQGQMQRNSVHDQVQNIWDMVLGKKIHGEDRDFFSAGGNSLRAVQLLTAIGKQFGVRVPLRNFYSNPTISCLVSLLMPVEEREH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCAACCGTCACATGATTTGCTGGAGGGGTTTCGTAATATAGTCATTCAGAAACCAGGTGATGTCTGTCTGACCGGTCCCGCCGGCGAGCAATGCTCATGGGAACAGCTAGTTAAAAATATCCTTGCGTGGAGAAGGTGGTTCAACCGAGAACAAAGTGAGGGCGTTACTTTTGCTGCTCGACTCGATTTATCCGCCAAATCTGTTGCCCTTGTAATAGCAGCTGTGACGTTGCCTGTCAAGATTGCTTGGATTCCGTTGAATATTCCGGCTTCACGAGAGCGGGACATGATTATTAATCTTGGGTCTAAAACGGTTCTGATCGACGACTCAACAGCGGAAGAAGCAATTTTTGCAGGGAACTGGATAAGTGATGTCAGGTCCTTGACCTGGAGCGATAAATCAAAATTCTTATATTTCACATCTGGATCAGAAGGAGTTCCGAAAGCCGTCCAAGTAGGAATGGATGCGGTGCGGAACCGTATCACGTGGATGTGGAACGCCTACCCTTACGAGTCAAGCGATCTTGTGGTCGTCCAGAAGCCACTCTCATTTGTTGCTTCATTTTGGGAAGTGTTGGGGACTCTGCTGGCAGGTGTTACTGGTGTTTTGATTACTAATATCGAGCGTAGCAGACCTGACGTGATGTTCGATCGACTTGCGTCTAGTGGTGCTACCCACCTTTTTACGACACCTCCAGCACTAGCCAGCTTGTGTGACATTGCCACAGAGCAAGGGAGCACTCTTCCTCAGCTCCGTCTAGCGTGCAGCAGTGCAGACCAGCTGATGGCAAGCGTTGTCCGTCAATTCTTCGAGATCGCGCCCCGTGCGCGAGTAGTGAATCTTTACGGAGCTACTGAGACGTCGGCTAACACAACAAGTTTCGAGGTTTCTCGGTCAGGTAGCATTCCGGACCCTATCCCCCTTGGCGAGCCGATCTGTGCTACGAAAATTGTAATTCGGGACATGAAAGGTAACGAAAAGTTATCTGGGGAAGAGGGACAGATATGCGTACAGGGTGCCCCAGTGGCCGATGGATATATCGTTAATGGTCAACTCAGTCCAGGGGACGATGCGTTCTTTACACTTGGAAGTGGACAACGTGAAATACGGACTGGTGATCTGGGAATCATCAAGGATGGTGTCCTTTCACTGGTTGGCAGGCTCGATAATGCGGTAAATATCGCTGGACACAAGATCCACTTGGAAGAGGTTGAAAGAGCTGCAGCTCGAGTTGCTAACTCCACGAAACAATGTGGTGCAGTTTATCACCAAGGCAGTGGTGGATTTTTGGCGCTCGTGATTCCACGCGAATGGGAGTCTCAGGTCACGACTTCTCGTCTTGCCGAATTTCTACCTTCCTATATGATTCCTCTCAAGATCGTAACTACGCAGAATGTTCCTAGATCAAGAACGGGAAAAATAGATCGGTGCGAGTGCCTGAAATTGGTAGCACAGAGCGAACTCTACGATCACGACAGAATATCCCAAGGACAAATGCAGCGTAACAGTGTTCACGATCAAGTGCAAAATATCTGGGATATGGTCCTTGGAAAGAAGATCCACGGTGAAGATCGTGATTTTTTCTCCGCAGGTGGAAATTCGTTGCGCGCTGTTCAGCTTTTGACCGCCATCGGTAAACAGTTTGGTGTTCGTGTCCCCTTGCGGAACTTCTATTCCAATCCAACGATTTCCTGCTTGGTCAGCTTGCTGATGCCTGTTGAGGAGCGTGAGCATTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 4940,
                "end": 8236,
                "strand": -1,
                "locus_tag": "AAA_02519",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02519</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02519</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,940 - 8,236,\n (total: 3297 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS: AMP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS: Condensation<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 263.9; E-value: 3.9e-80)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00501.28 (AMP-binding enzyme): [40:427](score: 214.8, e-value: 1.6e-63)<br>\n \n  PF00550.25 (Phosphopantetheine attachment site): [568:624](score: 23.8, e-value: 4.3e-05)<br>\n \n  PF00668.20 (Condensation domain): [656:1045](score: 124.4, e-value: 4.9e-36)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MINLTKSLEKNGLSLLATRSALVGENVDWPLERTLYSYLVEWAQITSHHVAVIDIHGEEITYEMLLNRVNNRAYLLEKKHAFGRVVISEHSRGIECLVDILACSAVGAIYTPIDPQWPEARRKHIKTITNAVAIFTENTSHVTEAKAPLGVTFLERVDDPFNAPSYCFFTSGSTGEPKGALIAHMGMMNHLHSKAHLLHLGVDSVVAQTAPTTFDVSIWQFCSALLVGGAVRIVPNGISQDPHELFSLLEEKHITHIELVPTVFRELIHEIGSSVSFSGLEYVLVTGEELPLRLARDWADKFPFVPLINAYGPTECSDDVTHAIVDGESLNSGEVPIGIPIPNTSLYVLEYAEGTWRPVSPGAQGELFVAGLCVGLGYIGSPDKTAQAFARIDGYPFRIYRTGDLVHQRADGQLVYDGRADRQIKISGVRIEPGEIENRILREIPELEDVVVVKFHPRVRERRAMVLRETTHQFLRQGDASLAAFYLPRADCLVTPKMLNNRAKSSLPRVMCPSRWIEVTDIPTTSNGKVDIKLLERRAGELLLNEIQESREGSIPGRVEQNQDSFILLVQDVLGTPVNPELTFIESGGDSLRAIQLANIVRSRGSYVRVRDLLSSYTLGSLAKEYQAQQISPKKSTSAKRSPSRFDDVKIPLTCDMNPAQQGIYFQWLLEPESPYYNYQILLECAGSNTDRIRRALGQALRANPQLMAKFGVDSTGRFTQTFPISAIDMDEISIHEVASAQEAREICWMKAAVPFNLEEGPAIAVDEIRINGYSTWFVLTMNEILIDGWGAMKFMEQLISLFECRNMDDQEIEVKTAMTSALEYFQHLSKPEEISAEAREFWSKSLDGVKSCFPLRDTLNSSCDPYAASVIEVSLDDEATAEIRSTAHALSTSPFAVFVAAYSLALAAVSDQHDFVVGAPVAGRNDEYEIGVPTLMLNMIAIRTRIDVEKKISDTVRSMISNVTEAVSFGDSVFSKVVSEFADHTNEDPLFSTMVNMLTYPSLEFWDGDRSLHLTELNTGFTKYDASLYIQRHGEDYTLQLAYKVAYVTPERANKVLALTAWFLTSDWLSGKTTVANAIKTALNDCDTSQITMLKSY&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=0&amp;to=18236\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_02519_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MINLTKSLEKNGLSLLATRSALVGENVDWPLERTLYSYLVEWAQITSHHVAVIDIHGEEITYEMLLNRVNNRAYLLEKKHAFGRVVISEHSRGIECLVDILACSAVGAIYTPIDPQWPEARRKHIKTITNAVAIFTENTSHVTEAKAPLGVTFLERVDDPFNAPSYCFFTSGSTGEPKGALIAHMGMMNHLHSKAHLLHLGVDSVVAQTAPTTFDVSIWQFCSALLVGGAVRIVPNGISQDPHELFSLLEEKHITHIELVPTVFRELIHEIGSSVSFSGLEYVLVTGEELPLRLARDWADKFPFVPLINAYGPTECSDDVTHAIVDGESLNSGEVPIGIPIPNTSLYVLEYAEGTWRPVSPGAQGELFVAGLCVGLGYIGSPDKTAQAFARIDGYPFRIYRTGDLVHQRADGQLVYDGRADRQIKISGVRIEPGEIENRILREIPELEDVVVVKFHPRVRERRAMVLRETTHQFLRQGDASLAAFYLPRADCLVTPKMLNNRAKSSLPRVMCPSRWIEVTDIPTTSNGKVDIKLLERRAGELLLNEIQESREGSIPGRVEQNQDSFILLVQDVLGTPVNPELTFIESGGDSLRAIQLANIVRSRGSYVRVRDLLSSYTLGSLAKEYQAQQISPKKSTSAKRSPSRFDDVKIPLTCDMNPAQQGIYFQWLLEPESPYYNYQILLECAGSNTDRIRRALGQALRANPQLMAKFGVDSTGRFTQTFPISAIDMDEISIHEVASAQEAREICWMKAAVPFNLEEGPAIAVDEIRINGYSTWFVLTMNEILIDGWGAMKFMEQLISLFECRNMDDQEIEVKTAMTSALEYFQHLSKPEEISAEAREFWSKSLDGVKSCFPLRDTLNSSCDPYAASVIEVSLDDEATAEIRSTAHALSTSPFAVFVAAYSLALAAVSDQHDFVVGAPVAGRNDEYEIGVPTLMLNMIAIRTRIDVEKKISDTVRSMISNVTEAVSFGDSVFSKVVSEFADHTNEDPLFSTMVNMLTYPSLEFWDGDRSLHLTELNTGFTKYDASLYIQRHGEDYTLQLAYKVAYVTPERANKVLALTAWFLTSDWLSGKTTVANAIKTALNDCDTSQITMLKSY\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGATAAACCTTACCAAAAGTTTGGAAAAAAATGGGTTGAGCTTGCTCGCTACCCGGAGTGCACTGGTCGGGGAAAACGTCGACTGGCCTTTAGAACGCACACTCTACTCGTATTTAGTTGAATGGGCCCAGATCACTTCACATCACGTTGCCGTAATAGATATTCATGGTGAAGAAATCACCTACGAAATGTTATTGAATCGAGTTAACAATCGAGCCTATCTCTTGGAAAAGAAACATGCCTTTGGAAGAGTAGTCATTTCAGAGCACTCGCGCGGTATCGAATGTCTTGTCGATATCCTAGCTTGTAGTGCCGTAGGTGCCATCTATACACCCATTGATCCTCAGTGGCCAGAGGCTCGTCGTAAACATATTAAGACAATCACGAACGCGGTCGCCATTTTCACTGAAAATACCTCGCACGTAACGGAAGCAAAGGCACCATTAGGAGTCACATTTCTGGAGCGTGTGGATGATCCTTTCAACGCTCCAAGCTACTGCTTTTTCACCTCGGGTAGCACAGGTGAACCGAAAGGTGCGCTAATCGCGCATATGGGCATGATGAATCACTTGCATAGCAAAGCCCATCTCCTTCATCTTGGTGTTGACTCAGTTGTGGCCCAGACGGCACCTACCACCTTTGATGTATCCATTTGGCAATTTTGTTCAGCTTTACTGGTAGGCGGTGCAGTACGTATCGTCCCCAACGGTATTTCACAGGATCCACATGAGCTTTTTTCTTTACTGGAAGAGAAACATATAACACACATTGAACTAGTTCCGACAGTATTTCGTGAACTTATTCACGAAATTGGGTCAAGCGTGTCTTTCTCTGGGCTTGAGTATGTTCTGGTGACTGGTGAAGAATTACCCCTTCGGTTGGCTAGAGACTGGGCAGACAAATTTCCGTTTGTCCCGTTGATTAATGCGTATGGTCCTACGGAATGTTCTGATGATGTAACGCATGCGATCGTGGATGGCGAATCGCTTAACTCAGGTGAAGTTCCCATCGGAATTCCAATACCTAATACGTCTTTATACGTCCTAGAGTACGCAGAAGGTACTTGGCGTCCAGTTTCTCCTGGAGCGCAAGGCGAGCTTTTTGTTGCTGGTCTTTGTGTGGGTTTAGGTTATATCGGAAGCCCAGATAAAACCGCTCAAGCATTTGCCAGGATTGATGGATACCCATTCCGAATATACCGCACCGGAGATCTCGTTCACCAGCGAGCGGATGGTCAGCTGGTTTACGATGGCCGCGCTGATCGACAGATAAAAATTAGTGGAGTACGGATTGAGCCCGGTGAAATCGAGAACCGTATCCTTCGAGAAATCCCAGAGCTTGAAGACGTTGTAGTGGTTAAATTCCACCCTCGTGTCCGTGAACGTCGCGCAATGGTGCTCCGAGAAACGACGCACCAGTTTCTTCGCCAAGGAGACGCTAGCTTGGCCGCATTCTATCTTCCTCGCGCCGATTGTTTAGTTACTCCCAAAATGCTTAATAATCGCGCGAAAAGCAGTCTCCCTAGAGTGATGTGTCCATCCCGTTGGATAGAGGTTACTGATATTCCCACTACTTCAAATGGCAAGGTAGATATTAAGTTATTAGAGCGCCGTGCCGGGGAACTGTTACTGAATGAAATTCAAGAGTCAAGAGAGGGATCCATTCCCGGTAGAGTTGAACAGAATCAGGACTCTTTCATTCTTCTCGTTCAGGACGTGCTTGGCACTCCTGTGAATCCAGAACTAACATTCATCGAATCCGGAGGCGATTCTCTTCGAGCAATTCAGCTAGCCAATATTGTCCGCTCACGAGGATCTTACGTAAGAGTACGAGATTTGCTTTCTTCATATACGTTAGGCTCTCTAGCAAAAGAATATCAAGCACAACAGATATCTCCGAAGAAATCGACCTCTGCAAAAAGATCTCCTTCCCGCTTTGATGACGTCAAAATTCCTTTGACTTGTGATATGAATCCGGCTCAGCAAGGAATTTATTTTCAATGGCTACTGGAGCCTGAAAGCCCTTACTATAATTATCAGATATTGTTAGAATGCGCTGGGTCGAACACCGATAGAATCCGTCGTGCTCTTGGCCAGGCATTACGGGCGAATCCACAGCTAATGGCGAAGTTTGGAGTGGATTCAACTGGGAGATTTACACAGACGTTTCCTATCTCTGCTATCGATATGGATGAAATCTCAATACACGAAGTGGCCTCTGCGCAAGAGGCTCGTGAGATCTGTTGGATGAAAGCAGCAGTCCCTTTTAACCTGGAGGAAGGTCCCGCTATCGCCGTGGACGAGATCCGTATAAATGGATATTCTACCTGGTTCGTTTTGACCATGAACGAGATCCTTATCGATGGCTGGGGAGCAATGAAGTTCATGGAACAGTTAATTTCTCTTTTTGAGTGTCGTAACATGGACGATCAGGAGATCGAAGTCAAGACAGCTATGACTTCAGCTCTGGAATATTTCCAACATCTGTCGAAACCTGAAGAGATATCCGCTGAAGCACGAGAATTTTGGTCAAAATCACTCGATGGAGTGAAATCATGTTTCCCATTGCGCGATACATTAAATAGTTCGTGTGATCCCTACGCTGCTTCTGTTATAGAGGTCTCTCTAGATGACGAAGCGACTGCTGAGATCCGTTCCACTGCGCATGCATTGAGTACAAGCCCATTTGCAGTATTCGTGGCTGCTTATTCGTTAGCGTTGGCAGCGGTCTCTGACCAACATGATTTTGTTGTCGGTGCACCAGTAGCAGGGCGAAACGATGAGTATGAAATTGGCGTCCCAACTCTGATGCTTAACATGATTGCAATACGAACTCGTATAGATGTCGAAAAGAAAATTAGTGACACAGTACGTTCGATGATATCTAATGTGACTGAAGCTGTCTCATTCGGTGACAGCGTATTTAGCAAGGTTGTTTCTGAGTTCGCTGATCACACGAACGAGGATCCATTGTTTAGCACGATGGTGAATATGCTTACTTACCCGTCTCTGGAGTTTTGGGATGGTGATCGAAGCCTTCACTTAACTGAATTGAATACTGGGTTTACGAAATATGATGCGTCTCTTTATATCCAGCGACACGGCGAAGATTATACCTTGCAACTTGCTTATAAAGTGGCGTATGTGACACCAGAACGCGCTAATAAAGTACTGGCTCTTACAGCGTGGTTCCTTACCTCTGATTGGCTCTCGGGGAAGACGACTGTCGCTAATGCCATAAAAACTGCCCTTAATGATTGTGATACATCTCAGATAACAATGCTCAAAAGCTATTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 8244,
                "end": 9233,
                "strand": -1,
                "locus_tag": "AAA_02520",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02520</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02520</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,244 - 9,233,\n (total: 990 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1158:ornithine cyclodeaminase (Score: 360.4; E-value: 1.1e-109)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF02423.15 (Ornithine cyclodeaminase/mu-crystallin family): [25:312](score: 91.2, e-value: 5.5e-26)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTKYGEMLIIDAKLVETFLKGRESFLIDLVERVYRAHHAGNTVCPDSYFLRFPDAPRDRIIALPSYINDQTCVSGIKWISSFPENVDHGLQRASAVIVLNNTDNGYAYAFIEASRISAARTAASAALAVRVLHGAPTSIGVVGSGPIAQTTLHFIKSLYTTAVPVKIHDLNSELVARIVTRHGPECSVVSLEEALGCDLVLLATSAGTPYVPMSVRFQPNQLVLNISLRDLHPETIRTANNVFDDVEHCLKANTTPHLLEQLNGNRNFITGTLAEFICSEKQLDPDHPTVFSPFGLGILDLAVAQSLYEHVQISGDGLRVPDFHGDMKR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=0&amp;to=19233\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_02520_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTKYGEMLIIDAKLVETFLKGRESFLIDLVERVYRAHHAGNTVCPDSYFLRFPDAPRDRIIALPSYINDQTCVSGIKWISSFPENVDHGLQRASAVIVLNNTDNGYAYAFIEASRISAARTAASAALAVRVLHGAPTSIGVVGSGPIAQTTLHFIKSLYTTAVPVKIHDLNSELVARIVTRHGPECSVVSLEEALGCDLVLLATSAGTPYVPMSVRFQPNQLVLNISLRDLHPETIRTANNVFDDVEHCLKANTTPHLLEQLNGNRNFITGTLAEFICSEKQLDPDHPTVFSPFGLGILDLAVAQSLYEHVQISGDGLRVPDFHGDMKR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGAAATATGGTGAAATGCTAATTATAGACGCCAAGCTTGTCGAAACATTTTTAAAAGGCAGAGAGTCGTTTCTCATCGATCTTGTTGAACGTGTTTATCGAGCACATCACGCTGGAAATACAGTATGTCCCGATAGTTATTTTCTTCGGTTTCCAGATGCTCCACGAGATCGTATCATAGCGTTGCCATCTTATATCAATGATCAAACCTGTGTGTCGGGAATTAAATGGATTTCTAGCTTTCCTGAGAATGTTGATCATGGGCTACAAAGAGCTTCAGCAGTCATCGTGCTAAATAACACAGATAACGGCTATGCTTATGCGTTCATCGAGGCCAGCCGCATTAGTGCGGCTCGTACAGCTGCCTCGGCTGCGCTTGCAGTTCGAGTTCTTCACGGTGCTCCTACGAGTATCGGTGTAGTAGGCAGTGGCCCTATCGCACAGACAACTTTACATTTTATTAAGTCGCTATACACGACAGCGGTTCCAGTGAAAATTCACGATTTAAATAGTGAATTAGTCGCACGTATAGTCACTCGCCACGGCCCCGAGTGTTCGGTAGTCAGTTTAGAAGAAGCTCTTGGCTGTGATCTCGTGCTATTAGCCACCAGCGCCGGAACTCCTTATGTGCCGATGAGTGTACGTTTCCAACCGAACCAGCTCGTTCTCAATATCTCGCTTCGTGATTTACACCCTGAGACCATTCGAACGGCTAATAACGTGTTTGATGATGTTGAACATTGCCTGAAGGCAAACACTACACCCCACCTCCTCGAACAATTGAACGGAAATCGAAATTTCATCACAGGCACACTGGCGGAATTCATATGCTCTGAGAAGCAGCTTGACCCTGATCATCCAACCGTATTCTCTCCTTTTGGTTTAGGAATTTTGGACCTTGCTGTTGCTCAAAGCTTGTACGAGCACGTTCAAATATCCGGCGATGGATTACGTGTTCCAGACTTTCACGGAGACATGAAACGGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 9234,
                "end": 10235,
                "strand": -1,
                "locus_tag": "AAA_02521",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02521</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02521</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,234 - 10,235,\n (total: 1002 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1081:cysteine synthase (Score: 324; E-value: 1.3e-98)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00291.25 (Pyridoxal-phosphate dependent enzyme): [11:291](score: 166.3, e-value: 9.7e-49)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIAGSIEELDENSQFVRLKNSFPKHDVYAKLEGLNTAGSVKLKTAIALVDSLEKLHGLQPGGWVVESSSGSLGIALSGVCARRGYKLTIVTDLNANSRSISHMRALGAEVEVVQSLDAAGGFLGTRLARVRELVEMPGGPLWTNQYENVANPEVHSKKTYRAIVEELGDPDYLFVGAGTTGTLMGVSRAVMKRGSCTKVYAIDSTGSVTFGGAPSRRYIPGLGASVKPPIFDEKFPLKRYYIDEIDTVRQCRRIAQVEGFLPGGSTGTVLAAFDALRDKIPEGSRVVIIAPDLGERYLDGVYNDDWVMENFGESAFNYAIRPVAHEVKETEGI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=0&amp;to=20235\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_02521_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIAGSIEELDENSQFVRLKNSFPKHDVYAKLEGLNTAGSVKLKTAIALVDSLEKLHGLQPGGWVVESSSGSLGIALSGVCARRGYKLTIVTDLNANSRSISHMRALGAEVEVVQSLDAAGGFLGTRLARVRELVEMPGGPLWTNQYENVANPEVHSKKTYRAIVEELGDPDYLFVGAGTTGTLMGVSRAVMKRGSCTKVYAIDSTGSVTFGGAPSRRYIPGLGASVKPPIFDEKFPLKRYYIDEIDTVRQCRRIAQVEGFLPGGSTGTVLAAFDALRDKIPEGSRVVIIAPDLGERYLDGVYNDDWVMENFGESAFNYAIRPVAHEVKETEGI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATTGCAGGATCTATTGAAGAACTAGATGAAAACTCTCAATTTGTCCGCTTGAAAAATTCATTTCCTAAACATGATGTTTACGCAAAATTAGAAGGTTTAAACACTGCTGGTTCCGTAAAACTCAAGACGGCTATTGCACTCGTCGATAGCTTAGAAAAGCTTCATGGTCTTCAGCCAGGAGGTTGGGTCGTAGAGTCTTCTTCTGGGAGTTTAGGCATAGCACTTTCCGGTGTATGTGCGCGCCGAGGATACAAATTAACAATTGTTACAGATCTGAATGCAAATTCAAGGTCGATTTCGCATATGCGTGCACTGGGCGCGGAAGTGGAAGTTGTTCAATCATTGGATGCAGCGGGCGGATTTCTTGGGACGCGACTTGCTAGAGTTCGCGAATTAGTAGAGATGCCAGGAGGGCCTTTATGGACAAACCAGTACGAAAATGTAGCCAATCCTGAGGTTCATTCCAAAAAGACATATAGAGCGATCGTCGAAGAGTTAGGAGATCCTGATTACCTATTTGTAGGTGCTGGTACCACTGGCACGCTTATGGGTGTATCTAGGGCTGTCATGAAGCGTGGTTCATGCACCAAAGTTTATGCTATTGATAGCACTGGTTCAGTGACTTTCGGAGGAGCTCCTTCGCGGCGATATATCCCTGGTCTAGGCGCTAGTGTAAAGCCACCAATCTTTGACGAAAAATTTCCTCTAAAACGGTATTATATTGATGAAATCGATACCGTGAGACAGTGCCGACGCATTGCGCAGGTAGAAGGATTTTTACCGGGTGGATCGACTGGCACTGTGCTAGCAGCTTTTGATGCTCTTCGAGATAAAATTCCCGAGGGAAGCCGCGTTGTCATTATTGCGCCGGATCTTGGTGAAAGGTATCTGGATGGAGTATATAACGACGATTGGGTTATGGAAAACTTTGGGGAATCAGCATTTAATTATGCCATTCGTCCTGTTGCGCACGAAGTGAAAGAAACGGAAGGTATTTAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 10232,
                "end": 10369,
                "strand": -1,
                "locus_tag": "AAA_02522",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02522</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02522</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,232 - 10,369,\n (total: 138 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIKILNFLPKPLLITPIACTRLLIIICLYVMKTSDVMSCAVGANK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=232&amp;to=20369\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIKILNFLPKPLLITPIACTRLLIIICLYVMKTSDVMSCAVGANK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATCAAGATCCTTAACTTCTTGCCTAAACCTCTTCTAATAACGCCCATAGCCTGTACAAGACTCCTCATTATAATTTGCTTGTATGTTATGAAAACTTCCGATGTCATGTCATGCGCAGTAGGAGCAAATAAATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 10627,
                "end": 11250,
                "strand": 1,
                "locus_tag": "AAA_02523",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02523</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02523</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,627 - 11,250,\n (total: 624 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1012:4&#39;-phosphopantetheinyl transferase (Score: 113.9; E-value: 1.1e-34)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01648.20 (4&#39;-phosphopantetheinyl transferase superfamily): [66:167](score: 43.7, e-value: 2.4e-11)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRIDDCLRCLIADELRAYSLKLDYKVPVQSEVSKNAFGKPLLANRDGPKFNLSHDGKWIVCATSPHPVGVDVEAVAEPGLAVVSNDFSVEEVEALRTTATAPLSIARAMIWTRKEAYLKYLGLGLTVQLDSFSVIDQTLLSPAEGMTDGIQFYSWCDADNSHVISVCGHGEEVVISCVSGQELLDGLPPSHCSEEPQEQLRWLPNLS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=627&amp;to=21250\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_02523_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRIDDCLRCLIADELRAYSLKLDYKVPVQSEVSKNAFGKPLLANRDGPKFNLSHDGKWIVCATSPHPVGVDVEAVAEPGLAVVSNDFSVEEVEALRTTATAPLSIARAMIWTRKEAYLKYLGLGLTVQLDSFSVIDQTLLSPAEGMTDGIQFYSWCDADNSHVISVCGHGEEVVISCVSGQELLDGLPPSHCSEEPQEQLRWLPNLS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCGAATCGATGACTGCTTGCGCTGCCTCATAGCTGACGAACTCCGGGCCTATTCATTGAAGCTTGATTACAAGGTGCCAGTACAGTCAGAGGTATCGAAGAACGCTTTCGGGAAGCCGCTACTAGCAAACCGCGATGGTCCTAAGTTCAACTTGTCGCACGATGGGAAGTGGATTGTCTGTGCCACAAGCCCACATCCTGTAGGCGTAGACGTCGAGGCAGTCGCTGAGCCAGGTTTAGCGGTGGTCTCGAACGATTTTTCAGTGGAAGAAGTGGAGGCCTTGCGGACGACCGCTACGGCTCCCCTCTCCATCGCTCGAGCGATGATCTGGACACGGAAGGAGGCATACCTCAAATATCTGGGGTTGGGTCTCACTGTTCAGTTAGATTCTTTTTCAGTAATAGATCAAACCTTGCTGTCGCCAGCTGAAGGGATGACAGACGGTATTCAGTTTTATAGTTGGTGCGATGCCGATAACTCGCATGTGATCTCTGTCTGTGGCCACGGCGAGGAAGTCGTCATCTCTTGCGTCAGCGGGCAAGAATTACTAGATGGACTGCCACCATCTCACTGTTCAGAAGAACCTCAAGAGCAACTTCGTTGGTTGCCCAATCTTAGTTAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 11350,
                "end": 12051,
                "strand": -1,
                "locus_tag": "AAA_02524",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02524</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02524</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,350 - 12,051,\n (total: 702 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKLMKISSSCELSSYLPLNQLVWHEECETLRLKRLTKLLEHEALRESIHVAQGAPYIILDGAHRCRAAFYLGFDSIPAHVVPMAPEQSVSGWVHVYNTRKFSSMPPLVHGEDRGSTIAILHDGDLRQEVHSKSDLASDLFYAYWDLAELLGGFDYRRSADVPAQGQSVEWVLPSWGAIAKIATNYGPLPAGITRFGSVFFKKCPRCIAEHEKSIMSDPVLDRDEVKSLAVMKD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=1350&amp;to=22051\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKLMKISSSCELSSYLPLNQLVWHEECETLRLKRLTKLLEHEALRESIHVAQGAPYIILDGAHRCRAAFYLGFDSIPAHVVPMAPEQSVSGWVHVYNTRKFSSMPPLVHGEDRGSTIAILHDGDLRQEVHSKSDLASDLFYAYWDLAELLGGFDYRRSADVPAQGQSVEWVLPSWGAIAKIATNYGPLPAGITRFGSVFFKKCPRCIAEHEKSIMSDPVLDRDEVKSLAVMKD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAATTGATGAAAATTAGTAGTAGCTGTGAGTTATCATCGTATCTTCCGCTAAACCAACTCGTATGGCATGAGGAATGTGAGACTTTGCGTCTCAAGCGTCTTACAAAATTGCTAGAACATGAAGCATTACGAGAAAGCATCCACGTAGCCCAAGGGGCACCTTACATCATCCTTGATGGAGCCCACAGGTGTCGAGCAGCTTTTTATTTAGGATTCGATTCCATACCAGCACATGTTGTCCCGATGGCTCCAGAGCAATCCGTATCTGGTTGGGTACATGTCTATAATACTCGGAAATTTTCTTCCATGCCACCATTGGTGCATGGGGAGGATCGGGGATCCACTATCGCTATTTTACACGATGGTGACTTGCGACAAGAAGTCCATTCGAAGAGCGATTTGGCCTCGGATCTATTTTATGCTTATTGGGATCTTGCGGAGCTCTTGGGTGGATTTGATTATCGACGTTCAGCGGATGTACCTGCTCAAGGACAGTCTGTGGAATGGGTTCTTCCTTCATGGGGAGCTATAGCCAAGATAGCTACTAATTACGGGCCACTACCAGCAGGTATAACTCGTTTCGGATCAGTTTTTTTCAAAAAGTGCCCACGATGCATTGCTGAGCACGAAAAATCTATCATGAGTGATCCAGTACTTGATCGTGACGAGGTGAAGAGCCTAGCTGTCATGAAGGATTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 12454,
                "end": 12585,
                "strand": -1,
                "locus_tag": "AAA_02525",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02525</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02525</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,454 - 12,585,\n (total: 132 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MASTMVRKLVSELVVAADRFCKPILQALFDVVINDGLLAPKGG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=2454&amp;to=22585\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MASTMVRKLVSELVVAADRFCKPILQALFDVVINDGLLAPKGG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCATCAACAATGGTACGTAAGCTTGTGTCAGAACTGGTGGTAGCGGCGGATCGGTTTTGTAAACCTATCCTGCAGGCCTTGTTCGATGTAGTGATCAACGACGGTCTCTTAGCTCCCAAGGGGGGATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 12957,
                "end": 13754,
                "strand": -1,
                "locus_tag": "AAA_02526",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02526</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02526</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,957 - 13,754,\n (total: 798 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTERDNRAQDLVRTLLAEGWSQAEIARRIGRDPRLVRFVLKGLKPGTNLVEALTQLERGEEVTPPRRRHDRKGRTAKVRGKRGKPSHRPTEPDAELLHPRRSRAPQQSDEEVLGEKHIETLPRKRRHGTTPSTSQPERLERQMRKRNLLRHEVTNLPHHRSSHTLQFPRDNEDARGQASDLLTEILSEGRGQRMHAKLWIEVDEGGRRERQMVRLGDKGGYDCGFALEDVRMFRDALSWLEDQAGQQYGNVADRGRLVGVEIDVW&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=2957&amp;to=23754\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTERDNRAQDLVRTLLAEGWSQAEIARRIGRDPRLVRFVLKGLKPGTNLVEALTQLERGEEVTPPRRRHDRKGRTAKVRGKRGKPSHRPTEPDAELLHPRRSRAPQQSDEEVLGEKHIETLPRKRRHGTTPSTSQPERLERQMRKRNLLRHEVTNLPHHRSSHTLQFPRDNEDARGQASDLLTEILSEGRGQRMHAKLWIEVDEGGRRERQMVRLGDKGGYDCGFALEDVRMFRDALSWLEDQAGQQYGNVADRGRLVGVEIDVW\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACTGAGCGTGACAATCGGGCTCAGGACCTGGTGCGCACCCTGTTAGCCGAAGGGTGGAGCCAAGCCGAGATTGCCCGACGAATCGGCCGAGACCCCCGCCTGGTGCGGTTCGTGCTAAAAGGGCTTAAGCCTGGCACCAACCTGGTCGAGGCGTTAACACAGTTGGAGCGGGGCGAGGAGGTTACCCCGCCGCGGCGTCGGCATGATCGCAAAGGCCGGACCGCGAAGGTACGCGGTAAGCGCGGAAAACCATCTCACCGTCCCACCGAACCGGATGCCGAACTCCTGCACCCGAGACGAAGCCGCGCACCACAACAGTCCGACGAGGAGGTGCTGGGCGAGAAACACATTGAAACCCTGCCGAGGAAACGCCGCCACGGCACAACCCCGTCAACGAGTCAGCCCGAGCGCCTCGAACGGCAGATGCGCAAGCGCAACCTGCTGCGTCACGAGGTCACAAACCTGCCCCACCACCGTTCTTCCCACACACTCCAATTCCCTCGCGACAACGAGGATGCGCGAGGACAAGCCTCCGATCTGCTCACCGAGATCCTGTCAGAAGGCCGAGGCCAGCGGATGCACGCGAAACTATGGATCGAAGTCGATGAAGGTGGCCGTCGGGAGCGCCAGATGGTGCGGTTGGGGGATAAGGGCGGCTACGACTGCGGTTTCGCTTTGGAAGACGTGCGGATGTTCCGGGATGCGTTGTCGTGGCTAGAGGACCAGGCGGGTCAGCAGTATGGCAATGTCGCCGATAGGGGTCGGCTAGTCGGTGTAGAAATCGATGTTTGGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 13747,
                "end": 15453,
                "strand": -1,
                "locus_tag": "AAA_02527",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02527</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02527</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,747 - 15,453,\n (total: 1707 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRDDQEQRRPAPHRPPDPETVWLDIDTARGVDAAGNEILPVLGGRRTKHATLSDLLTTALHHNARRLIVCGNIPDQPQSWLLPDTPAHTREFNQDWHVRGLFMLSGRPARGRFTHKETDRNLDILVADEWFPGQTLTPIQARWAWRELTHIIATRIDRDWALMDRPGAEGINLWKLRTPESYRMEPMDPELGALIQHTSPQHRYELCVDDGNPEDREKGWRPTVPAGPIPNFVYIDGRFMYAGSVTGEIGAAPATLLSATEARDLFTNNPWHPARYHIRFTVPSWWDDIGLLPVKRTKGRAGWFWPNVPGTTHETWVDTAELKLAIDEGWDTEAGPNGPITQPIEFLEGIKLTKVDPIRGWVKTIQDMIDIAEKRWADKNPTATTILTSALKNMLRVTIGQMSASNPVTTTVVYDADDIPSDIEGFDVIRNKTGDTIAYQYQTARRRPDPDTWHPEIAARIWALSRVRTLNTPIADPTTGKNATTKGGALRMNSRTLLAIHGDAIYTSNVPPWALPVAQGGGDDGKDGRLRVKGVLPGPLEAPQTGSERAALSEQAEQVGLPEEATSD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=3747&amp;to=25453\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRDDQEQRRPAPHRPPDPETVWLDIDTARGVDAAGNEILPVLGGRRTKHATLSDLLTTALHHNARRLIVCGNIPDQPQSWLLPDTPAHTREFNQDWHVRGLFMLSGRPARGRFTHKETDRNLDILVADEWFPGQTLTPIQARWAWRELTHIIATRIDRDWALMDRPGAEGINLWKLRTPESYRMEPMDPELGALIQHTSPQHRYELCVDDGNPEDREKGWRPTVPAGPIPNFVYIDGRFMYAGSVTGEIGAAPATLLSATEARDLFTNNPWHPARYHIRFTVPSWWDDIGLLPVKRTKGRAGWFWPNVPGTTHETWVDTAELKLAIDEGWDTEAGPNGPITQPIEFLEGIKLTKVDPIRGWVKTIQDMIDIAEKRWADKNPTATTILTSALKNMLRVTIGQMSASNPVTTTVVYDADDIPSDIEGFDVIRNKTGDTIAYQYQTARRRPDPDTWHPEIAARIWALSRVRTLNTPIADPTTGKNATTKGGALRMNSRTLLAIHGDAIYTSNVPPWALPVAQGGGDDGKDGRLRVKGVLPGPLEAPQTGSERAALSEQAEQVGLPEEATSD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGAGACGACCAGGAGCAGCGCCGTCCCGCCCCACATCGGCCCCCCGACCCCGAAACAGTGTGGCTAGACATCGACACCGCCCGGGGAGTCGACGCGGCCGGAAACGAGATCCTGCCAGTGCTGGGGGGACGACGCACCAAGCACGCAACCCTGTCAGACCTGCTAACAACCGCGCTACACCACAACGCCCGACGCCTGATCGTCTGCGGTAACATCCCCGACCAGCCTCAATCCTGGCTGCTGCCTGACACCCCCGCTCACACCCGCGAGTTCAACCAGGACTGGCACGTGCGGGGCCTGTTCATGCTGTCCGGGCGGCCCGCCCGAGGCCGGTTCACCCACAAAGAAACCGACCGCAACCTCGACATTCTGGTCGCTGATGAATGGTTCCCTGGCCAGACCCTCACCCCAATCCAGGCCCGCTGGGCATGGCGCGAATTAACCCACATCATCGCCACCAGAATCGACCGCGACTGGGCCCTCATGGACCGCCCCGGAGCAGAAGGAATCAACCTCTGGAAGCTACGGACCCCCGAGTCCTATCGCATGGAGCCGATGGACCCCGAACTGGGCGCACTCATCCAACACACCTCCCCTCAGCACCGCTACGAACTATGCGTCGACGACGGCAACCCCGAGGACCGCGAAAAGGGCTGGCGCCCCACCGTGCCTGCCGGCCCTATCCCTAACTTCGTGTACATCGACGGCCGATTCATGTATGCCGGATCAGTGACCGGAGAGATCGGTGCCGCACCCGCCACTCTGCTCAGCGCCACCGAAGCCCGCGACCTGTTCACCAACAACCCCTGGCACCCGGCCCGCTACCACATCCGCTTCACCGTGCCATCCTGGTGGGACGACATCGGCCTACTACCGGTCAAACGCACCAAAGGACGAGCAGGATGGTTTTGGCCCAACGTGCCCGGCACCACCCACGAAACATGGGTCGATACCGCCGAACTGAAACTAGCCATCGACGAAGGCTGGGACACCGAAGCCGGACCAAATGGGCCCATCACCCAGCCCATCGAGTTCCTCGAAGGGATCAAACTGACCAAAGTCGATCCCATCCGAGGATGGGTCAAAACCATCCAAGACATGATCGACATCGCCGAGAAACGCTGGGCAGACAAAAACCCCACCGCCACGACAATCCTCACCTCCGCGTTGAAAAACATGCTGCGCGTGACCATCGGCCAAATGTCGGCCTCCAACCCCGTCACCACCACCGTCGTCTACGACGCCGACGACATCCCCTCCGACATCGAAGGCTTCGACGTCATCCGCAACAAAACCGGTGACACCATCGCCTACCAATACCAAACCGCCCGCCGCCGCCCCGACCCCGACACCTGGCACCCCGAAATCGCCGCCCGCATCTGGGCCCTGTCCCGCGTACGCACCCTCAACACACCCATCGCCGACCCCACCACCGGAAAAAACGCCACAACCAAGGGAGGAGCACTACGCATGAACTCCCGCACCCTGCTGGCTATCCACGGCGACGCTATCTACACCAGCAACGTGCCCCCCTGGGCGCTCCCTGTGGCCCAGGGGGGCGGCGATGACGGCAAGGACGGGCGGCTGCGTGTCAAAGGTGTCTTGCCGGGCCCTTTGGAAGCGCCTCAGACCGGATCGGAGCGGGCTGCTCTATCAGAGCAGGCCGAGCAAGTAGGACTCCCCGAGGAGGCGACCAGTGACTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 15450,
                "end": 15971,
                "strand": -1,
                "locus_tag": "AAA_02528",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02528</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02528</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,450 - 15,971,\n (total: 522 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPSYRTTPDGKDYRLVITVTDEVTTCVIERIREGTWVPVQTWNTDVTARTRAPERRLKITESAANHGWQVPADAWGPIRHNRIVVKTIHPTGWASVVADATRRRDEALAQLGTIDLAWRDVLADAAAIGHLPATTIAEAAGVSRGRVYQLREEQRERMNALDAGRSLAQRRKP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=5450&amp;to=25971\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPSYRTTPDGKDYRLVITVTDEVTTCVIERIREGTWVPVQTWNTDVTARTRAPERRLKITESAANHGWQVPADAWGPIRHNRIVVKTIHPTGWASVVADATRRRDEALAQLGTIDLAWRDVLADAAAIGHLPATTIAEAAGVSRGRVYQLREEQRERMNALDAGRSLAQRRKP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCCAGCTACCGAACCACCCCAGACGGGAAAGATTATCGTCTGGTCATCACAGTCACCGACGAGGTCACCACGTGCGTCATCGAACGCATCCGAGAAGGGACGTGGGTACCAGTCCAGACCTGGAACACCGACGTCACTGCCCGCACCCGCGCACCTGAGCGACGCCTCAAGATCACCGAGTCCGCCGCCAATCACGGCTGGCAAGTCCCCGCTGATGCATGGGGCCCCATCCGCCACAACCGAATCGTCGTCAAGACCATCCACCCCACAGGGTGGGCCTCCGTAGTGGCTGATGCCACCCGCCGCCGCGACGAAGCTCTAGCCCAGCTGGGAACCATTGACCTGGCCTGGCGTGACGTCCTTGCCGACGCTGCCGCCATCGGCCACCTGCCGGCCACCACCATCGCCGAGGCAGCAGGAGTGTCACGAGGCCGGGTCTACCAACTACGCGAAGAACAACGCGAGCGCATGAACGCCCTCGACGCCGGCCGCTCCCTGGCCCAAAGGAGGAAACCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 16041,
                "end": 16601,
                "strand": -1,
                "locus_tag": "AAA_02529",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02529</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02529</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,041 - 16,601,\n (total: 561 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00583.25 (Acetyltransferase (GNAT) family): [115:163](score: 24.3, e-value: 2.9e-05)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIQESWEFSLSWHRSEITEIMAGHRRSALLIPIAAGVEAAIIWALRDWIICGNWPGQGELAMIGAATLVVVAVIMVALEAHHWRTATWRSWQTTPDWHGGAYVAPPARRHGPMLMCVHAVPRTQGHGSQILTQVCQWADEHGLTLELKPSGPAAERFYKRFGFVKTSRRVMRRECLSGRADPHKGV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=6041&amp;to=26601\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIQESWEFSLSWHRSEITEIMAGHRRSALLIPIAAGVEAAIIWALRDWIICGNWPGQGELAMIGAATLVVVAVIMVALEAHHWRTATWRSWQTTPDWHGGAYVAPPARRHGPMLMCVHAVPRTQGHGSQILTQVCQWADEHGLTLELKPSGPAAERFYKRFGFVKTSRRVMRRECLSGRADPHKGV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATTCAAGAGTCGTGGGAATTCTCCTTGTCGTGGCATCGCAGCGAGATCACCGAGATCATGGCAGGACACCGTCGTTCTGCCTTGCTCATCCCGATCGCAGCAGGCGTGGAAGCCGCGATCATCTGGGCGTTAAGAGACTGGATCATCTGCGGGAACTGGCCTGGCCAGGGTGAGCTGGCCATGATCGGGGCCGCAACGCTCGTCGTCGTCGCGGTGATCATGGTGGCCCTCGAAGCCCACCACTGGCGTACCGCGACATGGCGAAGCTGGCAGACCACACCGGACTGGCATGGCGGAGCCTACGTGGCCCCGCCAGCGCGCCGCCACGGCCCCATGCTCATGTGCGTCCACGCCGTCCCCCGCACTCAAGGCCACGGCTCACAGATCCTCACACAAGTCTGCCAATGGGCCGACGAGCACGGTCTCACCCTCGAACTGAAGCCCTCCGGGCCCGCTGCGGAGCGGTTCTATAAGCGGTTTGGTTTCGTTAAGACGTCGCGGCGGGTCATGAGACGTGAGTGCCTGTCTGGGCGGGCGGATCCACACAAAGGCGTCTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 16598,
                "end": 16975,
                "strand": -1,
                "locus_tag": "AAA_02530",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02530</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02530</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,598 - 16,975,\n (total: 378 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRINATRTPLPPVRTMTASQLKIGDLVAGHTADGSYPFHVERADSYDGMVHLRLIEISHASGLTDEQHPGIESVHAPDEPVITLSRHFGVCSECGRLSPCPDELAERRLEKLWQGEAEEAVHTSA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=6598&amp;to=26975\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRINATRTPLPPVRTMTASQLKIGDLVAGHTADGSYPFHVERADSYDGMVHLRLIEISHASGLTDEQHPGIESVHAPDEPVITLSRHFGVCSECGRLSPCPDELAERRLEKLWQGEAEEAVHTSA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGGATCAACGCGACCCGGACCCCGCTGCCGCCGGTGCGAACCATGACCGCCAGCCAGTTGAAGATCGGGGACCTGGTTGCAGGCCACACCGCGGACGGCTCCTACCCGTTCCATGTCGAGAGAGCCGACAGCTACGACGGCATGGTCCACCTCCGTCTGATCGAGATCAGCCACGCTTCGGGACTCACCGATGAGCAGCACCCGGGCATCGAGTCGGTTCATGCTCCCGACGAGCCGGTCATCACTCTCTCGCGCCACTTCGGGGTCTGCTCCGAGTGCGGCAGGCTGTCGCCGTGTCCCGACGAGCTGGCTGAGCGTCGTTTGGAGAAACTATGGCAGGGCGAAGCCGAAGAAGCCGTTCACACATCAGCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 17132,
                "end": 17500,
                "strand": 1,
                "locus_tag": "AAA_02531",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02531</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02531</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,132 - 17,500,\n (total: 369 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIEPTTISTTPRVAIISPSGPARFWGEPPSIALRRHGRSPMRSLPSGALLLVWDVTVLTGPTLGHRVRPLSKDAELTARRWLDQVADNPGFLDTLIEAARITNGWHHATPPHIQAPYRTLHQ&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=7132&amp;to=27500\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIEPTTISTTPRVAIISPSGPARFWGEPPSIALRRHGRSPMRSLPSGALLLVWDVTVLTGPTLGHRVRPLSKDAELTARRWLDQVADNPGFLDTLIEAARITNGWHHATPPHIQAPYRTLHQ\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATCGAACCCACAACCATCTCCACCACGCCCCGCGTGGCCATCATCTCCCCCAGCGGGCCAGCACGGTTCTGGGGCGAGCCTCCCAGCATCGCACTGCGCCGACACGGCCGGTCCCCCATGAGGTCCCTTCCTTCCGGGGCCCTGCTGCTGGTGTGGGACGTCACCGTTTTGACCGGGCCCACTCTCGGCCACCGCGTGCGTCCTCTCAGTAAGGACGCCGAGCTGACTGCCCGGCGCTGGCTCGACCAGGTCGCCGACAACCCCGGCTTCCTCGACACCCTTATCGAGGCCGCCCGCATCACCAATGGATGGCATCACGCGACGCCTCCGCACATTCAGGCCCCTTACCGGACCCTTCATCAGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 17517,
                "end": 18098,
                "strand": 1,
                "locus_tag": "AAA_02532",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02532</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02532</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 17,517 - 18,098,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTSDIDIDRTHKPDDRAEAPLYRSWARRLVHVSGMPWRIVAALAGVSPTSMHRLLFGRNGRPVEWIGINDARALMDIGIDDLASASTDRIPARESRELLVALHTLGWTDEHLSRWLTSSDLDLATTPKALYVTRLSAARIQATYDMLISQPVRRCGHPRTPPISSQTPVTSPQPGPEDAETFQPALFELADCA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=7517&amp;to=28098\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTSDIDIDRTHKPDDRAEAPLYRSWARRLVHVSGMPWRIVAALAGVSPTSMHRLLFGRNGRPVEWIGINDARALMDIGIDDLASASTDRIPARESRELLVALHTLGWTDEHLSRWLTSSDLDLATTPKALYVTRLSAARIQATYDMLISQPVRRCGHPRTPPISSQTPVTSPQPGPEDAETFQPALFELADCA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCAGCGACATTGACATTGACCGGACCCACAAACCCGACGACCGCGCCGAGGCTCCTCTTTACCGGTCCTGGGCCAGGAGACTCGTGCACGTCTCCGGGATGCCCTGGCGTATCGTCGCCGCCCTGGCCGGGGTCTCCCCCACCTCCATGCACCGGCTTCTATTCGGCCGCAACGGTCGACCCGTGGAATGGATCGGCATCAATGATGCTCGCGCCCTGATGGATATCGGCATCGATGATCTCGCCTCAGCGTCCACCGACCGTATCCCGGCCCGCGAATCCCGCGAGCTGTTGGTAGCCCTGCACACCCTCGGCTGGACCGATGAGCATCTAAGCCGCTGGCTGACCAGTTCCGACCTCGACCTGGCCACCACCCCCAAGGCCCTCTACGTCACCCGGCTATCCGCCGCCCGCATCCAGGCCACCTACGACATGCTCATCAGCCAACCCGTCCGCCGCTGCGGCCACCCCCGCACCCCGCCTATCTCGTCCCAGACTCCGGTTACCTCGCCCCAGCCCGGGCCCGAGGATGCCGAAACGTTCCAGCCCGCCCTGTTCGAGCTAGCCGACTGCGCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 18161,
                "end": 18658,
                "strand": 1,
                "locus_tag": "AAA_02533",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02533</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02533</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,161 - 18,658,\n (total: 498 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRLYRAVLTHTDIQITVRIWSTTDHDWTWTPLDTWTPDPTPTTPAQLADELHRHGWTTPEDPTTLTKVTVIPENWQALVDHALAARNHQANQLRVAENILTDILGDAADAGLSVTFLAQAAGLSRAAFYKRSAKTINSMRHTDQPREDPSQLTRAEKTALSLGDE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=8161&amp;to=28658\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRLYRAVLTHTDIQITVRIWSTTDHDWTWTPLDTWTPDPTPTTPAQLADELHRHGWTTPEDPTTLTKVTVIPENWQALVDHALAARNHQANQLRVAENILTDILGDAADAGLSVTFLAQAAGLSRAAFYKRSAKTINSMRHTDQPREDPSQLTRAEKTALSLGDE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCGTCTATACCGCGCTGTTCTTACCCACACCGACATCCAGATCACCGTCCGCATCTGGAGCACCACCGACCACGACTGGACCTGGACTCCCCTCGACACCTGGACCCCCGACCCGACCCCGACCACACCAGCCCAACTGGCCGACGAACTCCACCGACACGGATGGACCACCCCCGAGGACCCCACCACCCTCACCAAGGTGACTGTGATCCCCGAGAACTGGCAGGCCCTCGTCGACCACGCCCTCGCTGCCCGAAACCACCAAGCCAACCAGCTGCGCGTCGCCGAGAACATCCTCACCGACATCCTCGGCGACGCCGCCGACGCCGGCCTTTCCGTGACCTTCCTCGCCCAGGCCGCCGGACTGTCCCGAGCTGCCTTCTACAAACGCAGCGCTAAGACCATCAACTCTATGAGGCACACCGACCAGCCGCGCGAAGACCCCTCCCAGCTCACCCGAGCCGAGAAAACAGCACTCAGCCTGGGCGACGAGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 18766,
                "end": 19071,
                "strand": -1,
                "locus_tag": "AAA_02534",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02534</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02534</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,766 - 19,071,\n (total: 306 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNGPTGEGNNGCEEILAFIVVGIGGIALLKKMAPKIIGHLGAWLRDHGLLGVPGQGLFDLGLLGSVSASHLVVAVGVLIVVGALGAWFAGWVFARGSRGCR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=8766&amp;to=29071\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNGPTGEGNNGCEEILAFIVVGIGGIALLKKMAPKIIGHLGAWLRDHGLLGVPGQGLFDLGLLGSVSASHLVVAVGVLIVVGALGAWFAGWVFARGSRGCR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAACGGCCCCACCGGAGAAGGAAACAACGGATGCGAAGAAATCCTCGCCTTCATCGTTGTTGGTATCGGAGGGATAGCCCTGCTGAAGAAGATGGCCCCTAAAATCATCGGTCATCTCGGAGCATGGCTTCGCGATCACGGGCTGCTCGGCGTTCCCGGGCAGGGCCTGTTTGATCTTGGGTTGTTGGGGTCGGTTAGTGCTTCCCACCTGGTGGTCGCCGTGGGTGTGCTGATCGTGGTGGGCGCATTGGGGGCTTGGTTCGCTGGTTGGGTCTTCGCGAGGGGCAGTCGGGGGTGTAGGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 19068,
                "end": 19385,
                "strand": -1,
                "locus_tag": "AAA_02535",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02535</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02535</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,068 - 19,385,\n (total: 318 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTPVALPSIADLDHAVNNLTDALITATDAAETSTDSGWYIESAIEELRTALTEVASLSRAAGAPASLLAGASRAWQAGQVELIETSGQVADNLIGWLAVHPEKAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=9068&amp;to=29385\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTPVALPSIADLDHAVNNLTDALITATDAAETSTDSGWYIESAIEELRTALTEVASLSRAAGAPASLLAGASRAWQAGQVELIETSGQVADNLIGWLAVHPEKAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACTCCCGTAGCTTTACCGAGCATCGCTGATCTCGACCATGCCGTCAACAACCTCACCGACGCCCTTATCACCGCCACCGACGCCGCCGAGACCAGTACCGACAGCGGCTGGTACATCGAAAGCGCCATCGAGGAGCTACGCACCGCCTTGACTGAAGTCGCTTCTCTCAGCCGCGCAGCAGGGGCCCCGGCATCACTGCTGGCCGGCGCATCGCGCGCATGGCAGGCTGGACAGGTCGAACTGATCGAAACCTCAGGACAGGTCGCCGACAACCTCATCGGCTGGCTGGCCGTCCACCCCGAGAAGGCAGCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 19856,
                "end": 20125,
                "strand": 1,
                "locus_tag": "AAA_02536",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02536</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02536</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,856 - 20,125,\n (total: 270 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MAIIFTESAARHGFTRDDAIHAMETPEVFTPHFDHSRTGSPDVAAWIGPARGGLTIEVFATVIRPHTVVVFHCMEVRPSTREKLNGEQS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=9856&amp;to=30125\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MAIIFTESAARHGFTRDDAIHAMETPEVFTPHFDHSRTGSPDVAAWIGPARGGLTIEVFATVIRPHTVVVFHCMEVRPSTREKLNGEQS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCCATCATTTTTACTGAGAGCGCCGCTCGACATGGGTTCACCCGTGACGACGCAATTCACGCTATGGAGACTCCCGAGGTGTTCACGCCCCACTTTGATCATTCCCGTACTGGGAGTCCTGATGTGGCGGCATGGATTGGCCCGGCGAGAGGAGGGCTCACCATTGAGGTGTTCGCCACGGTGATCCGACCTCACACAGTCGTGGTCTTTCACTGCATGGAAGTGCGACCTTCAACCCGCGAGAAACTGAACGGAGAACAATCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 20122,
                "end": 20448,
                "strand": 1,
                "locus_tag": "AAA_02537",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02537</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02537</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,122 - 20,448,\n (total: 327 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01402.21 (Ribbon-helix-helix protein, copG family): [70:105](score: 27.0, e-value: 3e-06)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSNSHEIRYGIDFTELADWAETDNATHDPQTSPVFWGKDARHASQALLKRGRPTLGEDHATGKGHSPRRQLRLDAETNTRLDAMAAETGRSPSDIMRTALIDYLDAAS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=10122&amp;to=30448\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSNSHEIRYGIDFTELADWAETDNATHDPQTSPVFWGKDARHASQALLKRGRPTLGEDHATGKGHSPRRQLRLDAETNTRLDAMAAETGRSPSDIMRTALIDYLDAAS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCAACAGCCACGAGATCCGTTACGGGATCGACTTCACCGAACTGGCCGACTGGGCCGAGACCGATAACGCCACCCATGACCCGCAAACCAGCCCTGTGTTTTGGGGTAAGGATGCCCGGCACGCCAGCCAAGCGCTGCTGAAGCGTGGACGCCCGACCCTTGGCGAGGACCATGCCACTGGCAAGGGACACTCACCACGCCGTCAACTCCGTCTGGACGCTGAGACAAACACACGCCTCGATGCAATGGCGGCCGAGACCGGGCGCAGCCCCTCCGACATCATGCGCACCGCCCTCATCGACTACCTCGATGCCGCAAGCTAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 20509,
                "end": 20754,
                "strand": -1,
                "locus_tag": "AAA_02538",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02538</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02538</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 20,509 - 20,754,\n (total: 246 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSKSDNEHLADYVGRQYRQAAVLDFNYGSLARHGAESGAAIFLHYATRYTAGCVGMDSLSELTSTLRWIDPAQNPKIIILG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=10509&amp;to=30754\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSKSDNEHLADYVGRQYRQAAVLDFNYGSLARHGAESGAAIFLHYATRYTAGCVGMDSLSELTSTLRWIDPAQNPKIIILG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"TTGTCGAAGTCGGATAACGAGCACTTGGCGGACTACGTGGGCCGTCAGTACCGGCAAGCAGCCGTACTGGATTTCAACTATGGCTCGCTGGCGCGTCATGGTGCCGAGTCGGGGGCAGCGATCTTTTTGCATTATGCGACGCGTTACACTGCTGGGTGTGTGGGTATGGACTCACTGTCAGAGCTGACTAGCACGCTGCGATGGATTGACCCGGCTCAGAATCCCAAGATCATTATCTTGGGGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 21067,
                "end": 21480,
                "strand": -1,
                "locus_tag": "AAA_02539",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02539</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02539</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,067 - 21,480,\n (total: 414 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSMTAEAGTVYDVIAHREVSPEANFWVFEIPALGAVGQAVKLGQVADEARGIITAWDEDGPDEKAFKVHVRLDGEADARRMWEEGEEEERQARKVLDHAAARKREAVTLLRVEKKYSANDTARVLGVTRQRVYQLTR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=11067&amp;to=31480\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSMTAEAGTVYDVIAHREVSPEANFWVFEIPALGAVGQAVKLGQVADEARGIITAWDEDGPDEKAFKVHVRLDGEADARRMWEEGEEEERQARKVLDHAAARKREAVTLLRVEKKYSANDTARVLGVTRQRVYQLTR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCATGACAGCAGAAGCTGGGACGGTCTATGACGTGATCGCCCATCGTGAGGTCTCACCTGAGGCGAATTTCTGGGTATTCGAGATTCCGGCCCTCGGGGCGGTTGGGCAAGCAGTGAAGTTGGGTCAGGTCGCAGACGAGGCCCGCGGAATCATTACCGCCTGGGATGAGGATGGACCCGATGAGAAGGCGTTTAAGGTTCACGTTCGCTTGGATGGTGAGGCCGACGCCCGCCGCATGTGGGAAGAAGGTGAGGAGGAAGAGCGCCAAGCCCGGAAGGTGCTTGATCACGCGGCCGCACGCAAGCGTGAGGCCGTCACTCTGCTGAGGGTCGAGAAGAAATACAGCGCCAACGACACCGCCCGCGTGCTTGGGGTGACCCGCCAAAGGGTTTACCAACTCACCCGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 22169,
                "end": 22813,
                "strand": -1,
                "locus_tag": "AAA_02540",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02540</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02540</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,169 - 22,813,\n (total: 645 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MQQIVWVVAVMAIAAAGWPALTRVLPEPATASPDKIAYRDTYSLRSMIAVCAASATTMIAAVAWAPAPTWPAWALLATIGAWVAVIDAITTWIPAVLAWTGWVGWIGAVAMIALANQTAAIRAAIATVVISAAWMIVWVISRGGFGFSDVRITPLWAAPAAATGITTIHATVIAGLTLIALYALIDRCRHHTTRFLPWAPSLCSGALVGLAIAH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=12169&amp;to=32813\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MQQIVWVVAVMAIAAAGWPALTRVLPEPATASPDKIAYRDTYSLRSMIAVCAASATTMIAAVAWAPAPTWPAWALLATIGAWVAVIDAITTWIPAVLAWTGWVGWIGAVAMIALANQTAAIRAAIATVVISAAWMIVWVISRGGFGFSDVRITPLWAAPAAATGITTIHATVIAGLTLIALYALIDRCRHHTTRFLPWAPSLCSGALVGLAIAH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCAACAGATTGTGTGGGTGGTCGCCGTGATGGCTATCGCGGCCGCAGGGTGGCCTGCCCTCACCCGCGTCTTGCCAGAACCAGCTACCGCCAGCCCCGACAAAATCGCCTACCGCGACACCTACAGTCTCCGAAGCATGATCGCTGTCTGTGCTGCATCTGCGACAACCATGATCGCCGCCGTAGCGTGGGCCCCAGCACCCACCTGGCCGGCCTGGGCTCTGCTAGCCACCATCGGGGCATGGGTAGCCGTCATCGACGCCATCACCACATGGATACCGGCAGTCCTCGCCTGGACCGGCTGGGTTGGATGGATCGGGGCTGTGGCCATGATCGCTCTCGCGAACCAGACTGCGGCGATCCGTGCTGCTATCGCTACTGTCGTCATCTCCGCGGCGTGGATGATCGTCTGGGTCATCTCCCGAGGCGGATTCGGTTTCTCTGATGTGCGCATCACGCCGCTGTGGGCGGCCCCGGCCGCCGCAACCGGGATCACCACGATCCACGCCACGGTCATCGCCGGGCTGACTCTGATCGCCCTCTACGCCCTCATCGACCGCTGCCGACACCACACCACCCGATTCCTTCCCTGGGCGCCCAGCCTGTGCAGCGGCGCCCTCGTCGGCCTGGCCATCGCTCACTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 22863,
                "end": 24860,
                "strand": -1,
                "locus_tag": "AAA_02541",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02541</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02541</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,863 - 24,860,\n (total: 1998 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01580.18 (FtsK/SpoIIIE family): [267:383](score: 31.5, e-value: 1.1e-07)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTIRSRPSVAAAKKTPSAQLAVSVKPAWTNTAAGWSGAVLATGGYAAAADPRWWLLCVGCAVAGTLHASRALRADRRTETAETARLAIQATLKVPVSQKVTWDRKGKHPRRLILTIPPEAAAGETVPMTLTQAAAAAWPPGQFTVASATIPAGRFILAYRDPTPEPDKTDLDRATERAKDVATQIYGSAVTVDSWSTDQGKLDGFTIHHQRGAHLSSPNIQLRLAAVTSAMMPGQWRSDFDLEHDTITVTRRRPLPSVAARPVALPAPDSPDWEKIPQAVDEDGNTCYWDISGVMAHQLKAGRTRTGKTVSMIGDAVEAARRDWRVFIIDPKRIEYLGLREWPNIEMVATTVPDQVALIHWLWALMEDRYRRIEEEGARETDFTRVLVLIDEYRQFYGNTKNWWSTIKVSGMPGECPVFGWIGSLLRMAAACRIHVDLGTQRPDAEFLGGEIRDNFSGRAATGPLSSDGARMMFGSEHVGVGIPFGKRGRGTYLSGESTPKEVQFFYTPDPRKARSPQDLKLLEQLRPATTTWTKKKFVWPTDKQIAKAMASAGKKTSPQWERILGADLAADTETARPAPPPVVEEPDEDPVCDIDRFYSPPHPVAATELTAGMLIDIDGDWVTIAESSVDGEQVIVDWESAGDDSGTLMLGAGEAMSTRTPLDG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=12863&amp;to=34860\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTIRSRPSVAAAKKTPSAQLAVSVKPAWTNTAAGWSGAVLATGGYAAAADPRWWLLCVGCAVAGTLHASRALRADRRTETAETARLAIQATLKVPVSQKVTWDRKGKHPRRLILTIPPEAAAGETVPMTLTQAAAAAWPPGQFTVASATIPAGRFILAYRDPTPEPDKTDLDRATERAKDVATQIYGSAVTVDSWSTDQGKLDGFTIHHQRGAHLSSPNIQLRLAAVTSAMMPGQWRSDFDLEHDTITVTRRRPLPSVAARPVALPAPDSPDWEKIPQAVDEDGNTCYWDISGVMAHQLKAGRTRTGKTVSMIGDAVEAARRDWRVFIIDPKRIEYLGLREWPNIEMVATTVPDQVALIHWLWALMEDRYRRIEEEGARETDFTRVLVLIDEYRQFYGNTKNWWSTIKVSGMPGECPVFGWIGSLLRMAAACRIHVDLGTQRPDAEFLGGEIRDNFSGRAATGPLSSDGARMMFGSEHVGVGIPFGKRGRGTYLSGESTPKEVQFFYTPDPRKARSPQDLKLLEQLRPATTTWTKKKFVWPTDKQIAKAMASAGKKTSPQWERILGADLAADTETARPAPPPVVEEPDEDPVCDIDRFYSPPHPVAATELTAGMLIDIDGDWVTIAESSVDGEQVIVDWESAGDDSGTLMLGAGEAMSTRTPLDG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCATCCGGTCTCGTCCCTCAGTTGCGGCCGCGAAGAAGACACCCTCCGCCCAGCTCGCTGTCAGCGTGAAACCGGCGTGGACGAACACTGCGGCCGGCTGGTCGGGTGCGGTACTGGCCACAGGAGGCTACGCCGCGGCCGCGGATCCCCGCTGGTGGCTGCTATGTGTGGGCTGCGCTGTGGCGGGGACTCTTCACGCCAGTCGTGCGTTGCGCGCCGACCGGCGCACTGAGACCGCTGAAACAGCCCGCCTGGCTATCCAGGCGACGCTGAAGGTGCCGGTGTCCCAGAAAGTTACGTGGGATCGCAAGGGCAAACACCCGCGCCGACTGATCCTCACTATTCCTCCTGAGGCGGCCGCGGGGGAGACCGTGCCAATGACGCTGACCCAGGCAGCTGCAGCTGCCTGGCCGCCAGGACAATTCACGGTGGCTTCCGCAACGATCCCGGCCGGACGGTTCATCCTGGCCTACCGTGACCCCACCCCCGAGCCTGACAAGACTGATCTGGATCGGGCCACCGAGCGCGCCAAAGACGTGGCCACCCAAATCTATGGGTCGGCGGTCACTGTCGATTCCTGGAGCACCGATCAGGGGAAGCTGGACGGGTTCACCATTCACCACCAGCGTGGCGCTCACCTGTCCAGCCCCAACATTCAGCTACGCCTGGCCGCGGTAACCTCGGCGATGATGCCCGGCCAATGGCGCAGCGACTTCGACTTGGAGCACGACACCATCACTGTCACTCGTCGACGCCCTTTGCCCTCGGTGGCGGCGCGACCGGTGGCCCTTCCTGCCCCAGATTCCCCAGATTGGGAGAAGATCCCTCAAGCCGTCGACGAGGACGGCAACACCTGCTACTGGGACATCTCTGGTGTCATGGCCCACCAGCTCAAAGCCGGCCGTACCCGCACCGGGAAAACGGTATCCATGATCGGTGACGCCGTCGAGGCCGCCCGCCGTGACTGGCGCGTCTTCATCATCGACCCCAAACGCATCGAATATCTGGGCTTGCGGGAGTGGCCCAACATCGAAATGGTCGCCACCACCGTGCCCGACCAGGTCGCCCTCATCCACTGGCTGTGGGCCCTCATGGAGGACCGCTACCGACGCATCGAGGAAGAAGGAGCACGAGAAACCGACTTCACCCGAGTGCTCGTCCTCATCGACGAATACCGCCAGTTCTACGGCAACACGAAAAACTGGTGGTCGACGATCAAAGTCTCCGGAATGCCCGGAGAATGCCCCGTCTTCGGATGGATCGGCTCCCTGCTGCGCATGGCAGCAGCCTGCCGCATCCACGTCGATCTAGGAACCCAACGCCCAGACGCCGAATTTCTGGGCGGCGAGATCCGAGACAACTTCTCCGGCCGAGCCGCCACCGGACCCCTGTCCTCCGATGGCGCCCGCATGATGTTCGGCTCCGAACACGTCGGCGTGGGCATCCCGTTCGGCAAACGCGGCCGCGGCACCTACCTATCCGGCGAATCAACCCCCAAAGAAGTCCAGTTCTTCTACACCCCCGACCCCCGCAAAGCCCGCTCCCCGCAAGACCTGAAGCTGCTGGAACAGCTGCGACCCGCCACCACGACCTGGACCAAGAAGAAGTTTGTGTGGCCCACTGACAAACAGATCGCTAAGGCCATGGCCTCAGCGGGCAAGAAAACCAGCCCGCAGTGGGAGCGCATCCTGGGAGCCGACCTGGCTGCCGACACCGAGACAGCCAGGCCCGCCCCGCCCCCGGTAGTCGAGGAACCCGACGAAGATCCCGTTTGCGACATCGACCGCTTCTACAGCCCACCCCACCCGGTGGCCGCCACCGAGTTGACTGCTGGGATGCTCATCGACATAGACGGAGATTGGGTGACCATCGCCGAGTCCAGCGTCGACGGTGAGCAGGTCATCGTCGATTGGGAATCGGCCGGCGACGATTCCGGAACCCTCATGCTCGGCGCAGGAGAAGCCATGTCCACCCGCACACCTCTCGACGGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 24857,
                "end": 25135,
                "strand": -1,
                "locus_tag": "AAA_02542",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02542</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02542</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,857 - 25,135,\n (total: 279 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRVSRSVNLTREQVRAQLRLFTAISAVQQDGLVVPCTDDPPSWDKESMNPAACNGCPVFKLCTVYAATGAVRHGIIAGHHAYELTCHKETAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=14857&amp;to=35135\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRVSRSVNLTREQVRAQLRLFTAISAVQQDGLVVPCTDDPPSWDKESMNPAACNGCPVFKLCTVYAATGAVRHGIIAGHHAYELTCHKETAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCGTGTATCCCGCTCCGTCAACCTAACCCGGGAACAAGTTCGCGCCCAGCTGCGACTGTTCACCGCTATCAGTGCTGTCCAACAGGATGGCCTGGTTGTGCCGTGCACCGATGATCCGCCGTCGTGGGACAAAGAAAGCATGAACCCGGCGGCCTGTAATGGGTGCCCCGTGTTCAAGCTATGCACGGTCTATGCGGCCACCGGGGCGGTGCGTCACGGCATCATTGCTGGACATCATGCCTATGAGCTGACCTGCCACAAGGAAACTGCGGCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 25397,
                "end": 26017,
                "strand": 1,
                "locus_tag": "AAA_02543",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02543</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02543</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,397 - 26,017,\n (total: 621 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00239.21 (Resolvase, N terminal domain): [58:188](score: 60.6, e-value: 1.8e-16)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNLKEWAGVRGISYQTALRWYHRGLMPVPVHRVGRLVLVDCDEHGLPFEGSTPEPTKTIIYARVCSADQKPDLDRQIARVMTWASAKELSVDGVVTEVGSGLDGHRKKFEKLLKDGSVRTILVEHRDRFCRFGSEYIEAALSAQNRRLLVVDDKEIEDDLVQDMTDVLTSMCARLYGKRSAKHRARKAVETAMTTGGEESVKDDHT&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=15397&amp;to=36017\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNLKEWAGVRGISYQTALRWYHRGLMPVPVHRVGRLVLVDCDEHGLPFEGSTPEPTKTIIYARVCSADQKPDLDRQIARVMTWASAKELSVDGVVTEVGSGLDGHRKKFEKLLKDGSVRTILVEHRDRFCRFGSEYIEAALSAQNRRLLVVDDKEIEDDLVQDMTDVLTSMCARLYGKRSAKHRARKAVETAMTTGGEESVKDDHT\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAATCTCAAGGAGTGGGCAGGAGTGCGCGGGATTTCGTATCAGACCGCGCTGCGGTGGTATCACCGTGGGCTTATGCCTGTTCCCGTGCATCGAGTGGGAAGGCTCGTGCTCGTTGATTGTGACGAGCATGGGTTGCCGTTCGAGGGATCGACCCCCGAGCCGACGAAAACGATCATTTATGCTCGGGTGTGCTCGGCGGATCAGAAACCCGATCTTGATAGACAGATCGCTCGAGTCATGACATGGGCGAGCGCGAAGGAATTGTCGGTTGATGGTGTTGTCACCGAGGTTGGTTCTGGTCTCGATGGGCATCGGAAGAAGTTCGAGAAATTGTTGAAGGATGGTTCTGTCAGGACGATTCTTGTGGAACATCGCGATCGATTCTGCCGATTCGGGTCGGAATACATTGAAGCGGCACTTTCGGCACAGAATCGTCGTCTCCTTGTTGTTGACGACAAGGAGATCGAAGACGATCTTGTGCAGGATATGACAGATGTGCTCACGTCCATGTGTGCGAGATTGTACGGAAAGAGATCAGCGAAACATCGCGCCCGAAAGGCCGTGGAAACGGCCATGACCACTGGCGGTGAAGAATCCGTTAAGGATGATCACACATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 26014,
                "end": 27459,
                "strand": 1,
                "locus_tag": "AAA_02544",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">AAA_02544</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">AAA_02544</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,014 - 27,459,\n (total: 1446 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1192:transposase (Score: 296.7; E-value: 4.2e-90)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF12323.8 (Helix-turn-helix domain): [19:59](score: 48.9, e-value: 3.2e-13)<br>\n \n  PF01385.19 (Probable transposase): [212:338](score: 49.1, e-value: 6e-13)<br>\n \n  PF07282.11 (Putative transposase DNA-binding domain): [356:426](score: 72.5, e-value: 2e-20)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MITKPAAPKLDKNGPDVVVRSYKFALKPTKSQEQKLRQHTGAARFVYNYLISQWRDDIHTRAEEKKCGVPEDELTPFTFKLSAYDMRNYWNRTKGECAPWWPEVSKEIGNDAARRAHDSIENWYDSKGGKRKGRRVGFPRFHKRGCHESCTFSTGTIRVNPDRHSVALPRIGTIKTRENTRELQRKIAKGTARITQATISRGFNYWHVSFTVYEKKHIPETHAHSGSVVGVDMGVGDHVIVAATPNGDEVMRRGLPQSVKKDEARVRHLQRKLSRKHGPDKRTKTTPSNRWIRANNQVNKYRAKLANIRRDLAAKAAHGLATNYETVVIEDLNVQAMMTRGGAHKRGLNRAIAQASFADVRRRITYKTRWNGGRTVIADRWFPSSKTCSECGEVKSKLSLSEREYICHRCGVVVDRDLNAATNLAKLAAPKSGVDFHGTGSSPGMGRGGAGKTNSSSGELAPAGEASMARKDLSGRKAGTR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=CP017041.1&amp;from=16014&amp;to=37459\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/AAA_02544_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MITKPAAPKLDKNGPDVVVRSYKFALKPTKSQEQKLRQHTGAARFVYNYLISQWRDDIHTRAEEKKCGVPEDELTPFTFKLSAYDMRNYWNRTKGECAPWWPEVSKEIGNDAARRAHDSIENWYDSKGGKRKGRRVGFPRFHKRGCHESCTFSTGTIRVNPDRHSVALPRIGTIKTRENTRELQRKIAKGTARITQATISRGFNYWHVSFTVYEKKHIPETHAHSGSVVGVDMGVGDHVIVAATPNGDEVMRRGLPQSVKKDEARVRHLQRKLSRKHGPDKRTKTTPSNRWIRANNQVNKYRAKLANIRRDLAAKAAHGLATNYETVVIEDLNVQAMMTRGGAHKRGLNRAIAQASFADVRRRITYKTRWNGGRTVIADRWFPSSKTCSECGEVKSKLSLSEREYICHRCGVVVDRDLNAATNLAKLAAPKSGVDFHGTGSSPGMGRGGAGKTNSSSGELAPAGEASMARKDLSGRKAGTR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATCACGAAGCCCGCCGCCCCGAAATTGGACAAGAATGGCCCAGATGTTGTTGTCCGGTCCTACAAGTTTGCGTTGAAACCCACGAAGTCGCAGGAACAGAAATTGCGTCAGCATACGGGTGCAGCAAGGTTTGTCTACAATTATCTCATTTCCCAGTGGCGCGACGACATTCACACTCGTGCCGAAGAGAAGAAATGCGGCGTTCCTGAGGATGAATTGACGCCGTTCACGTTTAAGTTGTCTGCCTATGATATGCGTAATTACTGGAATCGCACCAAGGGCGAGTGTGCTCCGTGGTGGCCAGAAGTATCGAAGGAGATCGGCAACGATGCGGCACGTCGTGCCCATGACTCCATTGAGAACTGGTACGACTCCAAGGGCGGGAAACGCAAGGGCAGAAGAGTGGGCTTCCCCCGGTTCCACAAGCGCGGATGCCATGAATCATGCACGTTCTCAACCGGGACGATCCGTGTCAATCCTGACCGTCACTCGGTGGCACTGCCCCGAATCGGAACCATAAAGACTCGCGAAAATACGCGCGAATTGCAACGCAAAATCGCCAAAGGTACGGCAAGAATCACTCAGGCCACGATCTCTCGCGGGTTCAATTATTGGCACGTCTCCTTCACCGTGTACGAGAAGAAACACATTCCCGAAACCCACGCACATTCCGGCTCTGTTGTCGGGGTGGACATGGGTGTGGGAGATCACGTCATCGTTGCGGCAACCCCAAACGGTGATGAAGTCATGCGTAGGGGATTGCCGCAATCGGTCAAGAAGGATGAAGCGCGAGTGCGGCACCTTCAGCGCAAACTGTCGCGTAAGCATGGCCCGGATAAGAGGACGAAAACCACGCCCTCGAATCGGTGGATTCGCGCGAACAACCAAGTCAATAAGTATCGCGCGAAACTGGCTAACATACGTCGCGATCTTGCGGCGAAGGCTGCTCATGGGTTGGCGACGAATTATGAGACCGTCGTCATCGAGGACTTGAACGTTCAAGCCATGATGACGCGCGGAGGCGCACACAAACGTGGTCTGAATCGCGCGATAGCGCAGGCCTCATTTGCCGATGTCAGGCGACGAATCACCTACAAAACGAGGTGGAATGGCGGTAGAACCGTCATTGCCGATCGGTGGTTTCCATCGTCGAAAACGTGTTCGGAATGTGGAGAAGTGAAATCCAAGCTCTCCTTGTCCGAGCGTGAATACATCTGCCATCGTTGCGGTGTTGTCGTGGACAGAGACCTCAATGCTGCAACAAATCTGGCGAAATTAGCGGCACCGAAATCCGGTGTCGATTTTCACGGAACCGGGAGTTCGCCGGGGATGGGACGTGGAGGCGCGGGGAAGACCAACTCATCCTCGGGTGAGCTGGCACCGGCCGGTGAAGCGTCAATGGCCCGAAAGGACCTGAGCGGCCGCAAGGCCGGCACGAGATAA\">Copy to clipboard</span><br>\n</div>"
            }
        ],
        "clusters": [
            {
                "start": 1,
                "end": 28235,
                "tool": "",
                "neighbouring_start": 0,
                "neighbouring_end": 28236,
                "product": "CC 1: neighbouring",
                "kind": "candidatecluster",
                "prefix": "",
                "height": 0
            },
            {
                "start": 2,
                "end": 24859,
                "tool": "",
                "neighbouring_start": 1,
                "neighbouring_end": 24860,
                "product": "CC 2: single",
                "kind": "candidatecluster",
                "prefix": "",
                "height": 1
            },
            {
                "start": 4939,
                "end": 8236,
                "tool": "rule-based-clusters",
                "neighbouring_start": 0,
                "neighbouring_end": 28236,
                "product": "NRPS",
                "height": 3,
                "kind": "protocluster",
                "prefix": ""
            },
            {
                "start": 3177,
                "end": 4917,
                "tool": "rule-based-clusters",
                "neighbouring_start": 1,
                "neighbouring_end": 24860,
                "product": "NRPS-like",
                "height": 5,
                "kind": "protocluster",
                "prefix": ""
            }
        ],
        "ttaCodons": [],
        "type": "NRPS,NRPS-like",
        "products": [
            "NRPS",
            "NRPS-like"
        ],
        "anchor": "r2c1"
    }
};
var details_data = {
    "nrpspks": {
        "r2c1": {
            "id": "r2c1",
            "orfs": [
                {
                    "id": "AAA_02517",
                    "sequence": "MNPEVWQRISSATTSCCSTVLIFPPTGAGAPAFQSMSVLEGDTTVWGYCPPGRGQRLLEPGIRTMGEFVSKFRSSFEIPTGPLILAGVSFGAMLSFVAANILENDGIFATRLVALCGQSPKSYRGEREGWNLERARQRMRSYGLTPKSILNSDESDDLFVRPTLDDLLLAESCCGNQLKQIHVPITCVSAIDDKIVSSEEAVQWREATSETYRLIEVTGGHYAHEGFGRREWLNVFS",
                    "domains": [
                        {
                            "type": "Thioesterase",
                            "start": 18,
                            "end": 221,
                            "predictions": [],
                            "napdoslink": "",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=TVLIFPPTGAGAPAFQSMSVLEGDTTVWGYCPPGRGQRLLEPGIRTMGEFVSKFRSSFEIPTGPLILAGVSFGAMLSFVAANILENDGIFATRLVALCGQSPKSYRGEREGWNLERARQRMRSYGLTPKSILNSDESDDLFVRPTLDDLLLAESCCGNQLKQIHVPITCVSAIDDKIVSSEEAVQWREATSETYRLIEVTGGH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "TVLIFPPTGAGAPAFQSMSVLEGDTTVWGYCPPGRGQRLLEPGIRTMGEFVSKFRSSFEIPTGPLILAGVSFGAMLSFVAANILENDGIFATRLVALCGQSPKSYRGEREGWNLERARQRMRSYGLTPKSILNSDESDDLFVRPTLDDLLLAESCCGNQLKQIHVPITCVSAIDDKIVSSEEAVQWREATSETYRLIEVTGGH",
                            "dna_sequence": "TTGAATCCGGAAGTTTGGCAGCGTATTAGTTCAGCAACTACCTCTTGTTGCTCCACAGTCCTGATATTCCCTCCTACGGGTGCCGGAGCTCCTGCCTTTCAATCGATGTCTGTCTTAGAGGGGGATACTACAGTTTGGGGTTACTGCCCGCCTGGCAGGGGTCAACGATTACTTGAACCCGGCATCAGAACCATGGGAGAGTTCGTCAGCAAGTTTCGATCATCCTTCGAAATTCCGACTGGGCCGTTGATACTCGCCGGGGTTAGCTTTGGCGCGATGTTGTCGTTCGTAGCTGCTAATATTTTAGAAAATGACGGAATTTTCGCGACTCGTTTGGTTGCCTTATGTGGGCAAAGTCCTAAGAGTTACAGGGGGGAGCGAGAGGGATGGAACTTGGAACGTGCACGGCAGCGTATGCGTAGCTACGGATTGACTCCTAAAAGTATTCTGAACTCCGATGAATCCGATGATCTGTTTGTTCGCCCTACGCTCGATGATCTCTTACTGGCGGAATCGTGTTGTGGTAACCAACTTAAGCAGATTCATGTCCCTATAACCTGTGTTTCCGCTATTGATGATAAGATTGTTTCTTCCGAAGAGGCCGTCCAATGGCGTGAAGCTACGAGTGAGACGTACAGATTGATCGAAGTGACCGGAGGGCATTATGCACATGAAGGTTTTGGAAGAAGGGAATGGTTAAATGTTTTCTCGTGA",
                            "abbreviation": "TE",
                            "html_class": "jsdomain-terminal"
                        }
                    ],
                    "modules": [
                        {
                            "start": 18,
                            "end": 221,
                            "complete": false,
                            "iterative": false,
                            "monomer": "",
                            "multi_cds": null,
                            "match_id": null
                        }
                    ]
                },
                {
                    "id": "AAA_02518",
                    "sequence": "MQPSHDLLEGFRNIVIQKPGDVCLTGPAGEQCSWEQLVKNILAWRRWFNREQSEGVTFAARLDLSAKSVALVIAAVTLPVKIAWIPLNIPASRERDMIINLGSKTVLIDDSTAEEAIFAGNWISDVRSLTWSDKSKFLYFTSGSEGVPKAVQVGMDAVRNRITWMWNAYPYESSDLVVVQKPLSFVASFWEVLGTLLAGVTGVLITNIERSRPDVMFDRLASSGATHLFTTPPALASLCDIATEQGSTLPQLRLACSSADQLMASVVRQFFEIAPRARVVNLYGATETSANTTSFEVSRSGSIPDPIPLGEPICATKIVIRDMKGNEKLSGEEGQICVQGAPVADGYIVNGQLSPGDDAFFTLGSGQREIRTGDLGIIKDGVLSLVGRLDNAVNIAGHKIHLEEVERAAARVANSTKQCGAVYHQGSGGFLALVIPREWESQVTTSRLAEFLPSYMIPLKIVTTQNVPRSRTGKIDRCECLKLVAQSELYDHDRISQGQMQRNSVHDQVQNIWDMVLGKKIHGEDRDFFSAGGNSLRAVQLLTAIGKQFGVRVPLRNFYSNPTISCLVSLLMPVEEREH",
                    "domains": [
                        {
                            "type": "AMP-binding",
                            "start": 16,
                            "end": 395,
                            "predictions": [
                                [
                                    "consensus",
                                    "X"
                                ]
                            ],
                            "napdoslink": "",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=QKPGDVCLTGPAGEQCSWEQLVKNILAWRRWFNREQSEGVTFAARLDLSAKSVALVIAAVTLPVKIAWIPLNIPASRERDMIINLGSKTVLIDDSTAEEAIFAGNWISDVRSLTWSDKSKFLYFTSGSEGVPKAVQVGMDAVRNRITWMWNAYPYESSDLVVVQKPLSFVASFWEVLGTLLAGVTGVLITNIERSRPDVMFDRLASSGATHLFTTPPALASLCDIATEQGSTLPQLRLACSSADQLMASVVRQFFEIAPRARVVNLYGATETSANTTSFEVSRSGSIPDPIPLGEPICATKIVIRDMKGNEKLSGEEGQICVQGAPVADGYIVNGQLSPGDDAFFTLGSGQREIRTGDLGIIKDGVLSLVGRLDNAVNI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "QKPGDVCLTGPAGEQCSWEQLVKNILAWRRWFNREQSEGVTFAARLDLSAKSVALVIAAVTLPVKIAWIPLNIPASRERDMIINLGSKTVLIDDSTAEEAIFAGNWISDVRSLTWSDKSKFLYFTSGSEGVPKAVQVGMDAVRNRITWMWNAYPYESSDLVVVQKPLSFVASFWEVLGTLLAGVTGVLITNIERSRPDVMFDRLASSGATHLFTTPPALASLCDIATEQGSTLPQLRLACSSADQLMASVVRQFFEIAPRARVVNLYGATETSANTTSFEVSRSGSIPDPIPLGEPICATKIVIRDMKGNEKLSGEEGQICVQGAPVADGYIVNGQLSPGDDAFFTLGSGQREIRTGDLGIIKDGVLSLVGRLDNAVNI",
                            "dna_sequence": "ATGCAACCGTCACATGATTTGCTGGAGGGGTTTCGTAATATAGTCATTCAGAAACCAGGTGATGTCTGTCTGACCGGTCCCGCCGGCGAGCAATGCTCATGGGAACAGCTAGTTAAAAATATCCTTGCGTGGAGAAGGTGGTTCAACCGAGAACAAAGTGAGGGCGTTACTTTTGCTGCTCGACTCGATTTATCCGCCAAATCTGTTGCCCTTGTAATAGCAGCTGTGACGTTGCCTGTCAAGATTGCTTGGATTCCGTTGAATATTCCGGCTTCACGAGAGCGGGACATGATTATTAATCTTGGGTCTAAAACGGTTCTGATCGACGACTCAACAGCGGAAGAAGCAATTTTTGCAGGGAACTGGATAAGTGATGTCAGGTCCTTGACCTGGAGCGATAAATCAAAATTCTTATATTTCACATCTGGATCAGAAGGAGTTCCGAAAGCCGTCCAAGTAGGAATGGATGCGGTGCGGAACCGTATCACGTGGATGTGGAACGCCTACCCTTACGAGTCAAGCGATCTTGTGGTCGTCCAGAAGCCACTCTCATTTGTTGCTTCATTTTGGGAAGTGTTGGGGACTCTGCTGGCAGGTGTTACTGGTGTTTTGATTACTAATATCGAGCGTAGCAGACCTGACGTGATGTTCGATCGACTTGCGTCTAGTGGTGCTACCCACCTTTTTACGACACCTCCAGCACTAGCCAGCTTGTGTGACATTGCCACAGAGCAAGGGAGCACTCTTCCTCAGCTCCGTCTAGCGTGCAGCAGTGCAGACCAGCTGATGGCAAGCGTTGTCCGTCAATTCTTCGAGATCGCGCCCCGTGCGCGAGTAGTGAATCTTTACGGAGCTACTGAGACGTCGGCTAACACAACAAGTTTCGAGGTTTCTCGGTCAGGTAGCATTCCGGACCCTATCCCCCTTGGCGAGCCGATCTGTGCTACGAAAATTGTAATTCGGGACATGAAAGGTAACGAAAAGTTATCTGGGGAAGAGGGACAGATATGCGTACAGGGTGCCCCAGTGGCCGATGGATATATCGTTAATGGTCAACTCAGTCCAGGGGACGATGCGTTCTTTACACTTGGAAGTGGACAACGTGAAATACGGACTGGTGATCTGGGAATCATCAAGGATGGTGTCCTTTCACTGGTTGGCAGGCTCGATAATGCGGTAAATATCGCTGGACACAAGATCCACTTGGAAGAGGTTGAAAGAGCTGCAGCTCGAGTTGCTAACTCCACGAAACAATGTGGTGCAGTTTATCACCAAGGCAGTGGTGGATTTTTGGCGCTCGTGATTCCACGCGAATGGGAGTCTCAGGTCACGACTTCTCGTCTTGCCGAATTTCTACCTTCCTATATGATTCCTCTCAAGATCGTAACTACGCAGAATGTTCCTAGATCAAGAACGGGAAAAATAGATCGGTGCGAGTGCCTGAAATTGGTAGCACAGAGCGAACTCTACGATCACGACAGAATATCCCAAGGACAAATGCAGCGTAACAGTGTTCACGATCAAGTGCAAAATATCTGGGATATGGTCCTTGGAAAGAAGATCCACGGTGAAGATCGTGATTTTTTCTCCGCAGGTGGAAATTCGTTGCGCGCTGTTCAGCTTTTGACCGCCATCGGTAAACAGTTTGGTGTTCGTGTCCCCTTGCGGAACTTCTATTCCAATCCAACGATTTCCTGCTTGGTCAGCTTGCTGATGCCTGTTGAGGAGCGTGAGCATTGA",
                            "abbreviation": "A",
                            "html_class": "jsdomain-adenylation"
                        },
                        {
                            "type": "PP-binding",
                            "start": 506,
                            "end": 568,
                            "predictions": [],
                            "napdoslink": "",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=DQVQNIWDMVLGKKIHGEDRDFFSAGGNSLRAVQLLTAIGKQFGVRVPLRNFYSNPTISCLV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "DQVQNIWDMVLGKKIHGEDRDFFSAGGNSLRAVQLLTAIGKQFGVRVPLRNFYSNPTISCLV",
                            "dna_sequence": "ATGCAACCGTCACATGATTTGCTGGAGGGGTTTCGTAATATAGTCATTCAGAAACCAGGTGATGTCTGTCTGACCGGTCCCGCCGGCGAGCAATGCTCATGGGAACAGCTAGTTAAAAATATCCTTGCGTGGAGAAGGTGGTTCAACCGAGAACAAAGTGAGGGCGTTACTTTTGCTGCTCGACTCGATTTATCCGCCAAATCTGTTGCCCTTGTAATAGCAGCTGTGACGTTGCCTGTCAAGATTGCTTGGATTCCGTTGAATATTCCGGCTTCACGAGAGCGGGACATGATTATTAATCTTGGGTCTAAAACGGTTCTGATCGACGACTCAACAGCGGAAGAAGCAATTTTTGCAGGGAACTGGATAAGTGATGTCAGGTCCTTGACCTGGAGCGATAAATCAAAATTCTTATATTTCACATCTGGATCAGAAGGAGTTCCGAAAGCCGTCCAAGTAGGAATGGATGCGGTGCGGAACCGTATCACGTGGATGTGGAACGCCTACCCTTACGAGTCAAGCGATCTTGTGGTCGTCCAGAAGCCACTCTCATTTGTTGCTTCATTTTGGGAAGTGTTGGGGACTCTGCTGGCAGGTGTTACTGGTGTTTTGATTACTAATATCGAGCGTAGCAGACCTGACGTGATGTTCGATCGACTTGCGTCTAGTGGTGCTACCCACCTTTTTACGACACCTCCAGCACTAGCCAGCTTGTGTGACATTGCCACAGAGCAAGGGAGCACTCTTCCTCAGCTCCGTCTAGCGTGCAGCAGTGCAGACCAGCTGATGGCAAGCGTTGTCCGTCAATTCTTCGAGATCGCGCCCCGTGCGCGAGTAGTGAATCTTTACGGAGCTACTGAGACGTCGGCTAACACAACAAGTTTCGAGGTTTCTCGGTCAGGTAGCATTCCGGACCCTATCCCCCTTGGCGAGCCGATCTGTGCTACGAAAATTGTAATTCGGGACATGAAAGGTAACGAAAAGTTATCTGGGGAAGAGGGACAGATATGCGTACAGGGTGCCCCAGTGGCCGATGGATATATCGTTAATGGTCAACTCAGTCCAGGGGACGATGCGTTCTTTACACTTGGAAGTGGACAACGTGAAATACGGACTGGTGATCTGGGAATCATCAAGGATGGTGTCCTTTCACTGGTTGGCAGGCTCGATAATGCGGTAAATATCGCTGGACACAAGATCCACTTGGAAGAGGTTGAAAGAGCTGCAGCTCGAGTTGCTAACTCCACGAAACAATGTGGTGCAGTTTATCACCAAGGCAGTGGTGGATTTTTGGCGCTCGTGATTCCACGCGAATGGGAGTCTCAGGTCACGACTTCTCGTCTTGCCGAATTTCTACCTTCCTATATGATTCCTCTCAAGATCGTAACTACGCAGAATGTTCCTAGATCAAGAACGGGAAAAATAGATCGGTGCGAGTGCCTGAAATTGGTAGCACAGAGCGAACTCTACGATCACGACAGAATATCCCAAGGACAAATGCAGCGTAACAGTGTTCACGATCAAGTGCAAAATATCTGGGATATGGTCCTTGGAAAGAAGATCCACGGTGAAGATCGTGATTTTTTCTCCGCAGGTGGAAATTCGTTGCGCGCTGTTCAGCTTTTGACCGCCATCGGTAAACAGTTTGGTGTTCGTGTCCCCTTGCGGAACTTCTATTCCAATCCAACGATTTCCTGCTTGGTCAGCTTGCTGATGCCTGTTGAGGAGCGTGAGCATTGA",
                            "abbreviation": "",
                            "html_class": "jsdomain-transport"
                        }
                    ],
                    "modules": [
                        {
                            "start": 16,
                            "end": 568,
                            "complete": true,
                            "iterative": false,
                            "monomer": "?",
                            "multi_cds": null,
                            "match_id": null
                        }
                    ]
                },
                {
                    "id": "AAA_02519",
                    "sequence": "MINLTKSLEKNGLSLLATRSALVGENVDWPLERTLYSYLVEWAQITSHHVAVIDIHGEEITYEMLLNRVNNRAYLLEKKHAFGRVVISEHSRGIECLVDILACSAVGAIYTPIDPQWPEARRKHIKTITNAVAIFTENTSHVTEAKAPLGVTFLERVDDPFNAPSYCFFTSGSTGEPKGALIAHMGMMNHLHSKAHLLHLGVDSVVAQTAPTTFDVSIWQFCSALLVGGAVRIVPNGISQDPHELFSLLEEKHITHIELVPTVFRELIHEIGSSVSFSGLEYVLVTGEELPLRLARDWADKFPFVPLINAYGPTECSDDVTHAIVDGESLNSGEVPIGIPIPNTSLYVLEYAEGTWRPVSPGAQGELFVAGLCVGLGYIGSPDKTAQAFARIDGYPFRIYRTGDLVHQRADGQLVYDGRADRQIKISGVRIEPGEIENRILREIPELEDVVVVKFHPRVRERRAMVLRETTHQFLRQGDASLAAFYLPRADCLVTPKMLNNRAKSSLPRVMCPSRWIEVTDIPTTSNGKVDIKLLERRAGELLLNEIQESREGSIPGRVEQNQDSFILLVQDVLGTPVNPELTFIESGGDSLRAIQLANIVRSRGSYVRVRDLLSSYTLGSLAKEYQAQQISPKKSTSAKRSPSRFDDVKIPLTCDMNPAQQGIYFQWLLEPESPYYNYQILLECAGSNTDRIRRALGQALRANPQLMAKFGVDSTGRFTQTFPISAIDMDEISIHEVASAQEAREICWMKAAVPFNLEEGPAIAVDEIRINGYSTWFVLTMNEILIDGWGAMKFMEQLISLFECRNMDDQEIEVKTAMTSALEYFQHLSKPEEISAEAREFWSKSLDGVKSCFPLRDTLNSSCDPYAASVIEVSLDDEATAEIRSTAHALSTSPFAVFVAAYSLALAAVSDQHDFVVGAPVAGRNDEYEIGVPTLMLNMIAIRTRIDVEKKISDTVRSMISNVTEAVSFGDSVFSKVVSEFADHTNEDPLFSTMVNMLTYPSLEFWDGDRSLHLTELNTGFTKYDASLYIQRHGEDYTLQLAYKVAYVTPERANKVLALTAWFLTSDWLSGKTTVANAIKTALNDCDTSQITMLKSY",
                    "domains": [
                        {
                            "type": "AMP-binding",
                            "start": 40,
                            "end": 427,
                            "predictions": [
                                [
                                    "consensus",
                                    "X"
                                ]
                            ],
                            "napdoslink": "",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=EWAQITSHHVAVIDIHGEEITYEMLLNRVNNRAYLLEKKHAFGRVVISEHSRGIECLVDILACSAVGAIYTPIDPQWPEARRKHIKTITNAVAIFTENTSHVTEAKAPLGVTFLERVDDPFNAPSYCFFTSGSTGEPKGALIAHMGMMNHLHSKAHLLHLGVDSVVAQTAPTTFDVSIWQFCSALLVGGAVRIVPNGISQDPHELFSLLEEKHITHIELVPTVFRELIHEIGSSVSFSGLEYVLVTGEELPLRLARDWADKFPFVPLINAYGPTECSDDVTHAIVDGESLNSGEVPIGIPIPNTSLYVLEYAEGTWRPVSPGAQGELFVAGLCVGLGYIGSPDKTAQAFARIDGYPFRIYRTGDLVHQRADGQLVYDGRADRQIKIS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "EWAQITSHHVAVIDIHGEEITYEMLLNRVNNRAYLLEKKHAFGRVVISEHSRGIECLVDILACSAVGAIYTPIDPQWPEARRKHIKTITNAVAIFTENTSHVTEAKAPLGVTFLERVDDPFNAPSYCFFTSGSTGEPKGALIAHMGMMNHLHSKAHLLHLGVDSVVAQTAPTTFDVSIWQFCSALLVGGAVRIVPNGISQDPHELFSLLEEKHITHIELVPTVFRELIHEIGSSVSFSGLEYVLVTGEELPLRLARDWADKFPFVPLINAYGPTECSDDVTHAIVDGESLNSGEVPIGIPIPNTSLYVLEYAEGTWRPVSPGAQGELFVAGLCVGLGYIGSPDKTAQAFARIDGYPFRIYRTGDLVHQRADGQLVYDGRADRQIKIS",
                            "dna_sequence": "GTGATAAACCTTACCAAAAGTTTGGAAAAAAATGGGTTGAGCTTGCTCGCTACCCGGAGTGCACTGGTCGGGGAAAACGTCGACTGGCCTTTAGAACGCACACTCTACTCGTATTTAGTTGAATGGGCCCAGATCACTTCACATCACGTTGCCGTAATAGATATTCATGGTGAAGAAATCACCTACGAAATGTTATTGAATCGAGTTAACAATCGAGCCTATCTCTTGGAAAAGAAACATGCCTTTGGAAGAGTAGTCATTTCAGAGCACTCGCGCGGTATCGAATGTCTTGTCGATATCCTAGCTTGTAGTGCCGTAGGTGCCATCTATACACCCATTGATCCTCAGTGGCCAGAGGCTCGTCGTAAACATATTAAGACAATCACGAACGCGGTCGCCATTTTCACTGAAAATACCTCGCACGTAACGGAAGCAAAGGCACCATTAGGAGTCACATTTCTGGAGCGTGTGGATGATCCTTTCAACGCTCCAAGCTACTGCTTTTTCACCTCGGGTAGCACAGGTGAACCGAAAGGTGCGCTAATCGCGCATATGGGCATGATGAATCACTTGCATAGCAAAGCCCATCTCCTTCATCTTGGTGTTGACTCAGTTGTGGCCCAGACGGCACCTACCACCTTTGATGTATCCATTTGGCAATTTTGTTCAGCTTTACTGGTAGGCGGTGCAGTACGTATCGTCCCCAACGGTATTTCACAGGATCCACATGAGCTTTTTTCTTTACTGGAAGAGAAACATATAACACACATTGAACTAGTTCCGACAGTATTTCGTGAACTTATTCACGAAATTGGGTCAAGCGTGTCTTTCTCTGGGCTTGAGTATGTTCTGGTGACTGGTGAAGAATTACCCCTTCGGTTGGCTAGAGACTGGGCAGACAAATTTCCGTTTGTCCCGTTGATTAATGCGTATGGTCCTACGGAATGTTCTGATGATGTAACGCATGCGATCGTGGATGGCGAATCGCTTAACTCAGGTGAAGTTCCCATCGGAATTCCAATACCTAATACGTCTTTATACGTCCTAGAGTACGCAGAAGGTACTTGGCGTCCAGTTTCTCCTGGAGCGCAAGGCGAGCTTTTTGTTGCTGGTCTTTGTGTGGGTTTAGGTTATATCGGAAGCCCAGATAAAACCGCTCAAGCATTTGCCAGGATTGATGGATACCCATTCCGAATATACCGCACCGGAGATCTCGTTCACCAGCGAGCGGATGGTCAGCTGGTTTACGATGGCCGCGCTGATCGACAGATAAAAATTAGTGGAGTACGGATTGAGCCCGGTGAAATCGAGAACCGTATCCTTCGAGAAATCCCAGAGCTTGAAGACGTTGTAGTGGTTAAATTCCACCCTCGTGTCCGTGAACGTCGCGCAATGGTGCTCCGAGAAACGACGCACCAGTTTCTTCGCCAAGGAGACGCTAGCTTGGCCGCATTCTATCTTCCTCGCGCCGATTGTTTAGTTACTCCCAAAATGCTTAATAATCGCGCGAAAAGCAGTCTCCCTAGAGTGATGTGTCCATCCCGTTGGATAGAGGTTACTGATATTCCCACTACTTCAAATGGCAAGGTAGATATTAAGTTATTAGAGCGCCGTGCCGGGGAACTGTTACTGAATGAAATTCAAGAGTCAAGAGAGGGATCCATTCCCGGTAGAGTTGAACAGAATCAGGACTCTTTCATTCTTCTCGTTCAGGACGTGCTTGGCACTCCTGTGAATCCAGAACTAACATTCATCGAATCCGGAGGCGATTCTCTTCGAGCAATTCAGCTAGCCAATATTGTCCGCTCACGAGGATCTTACGTAAGAGTACGAGATTTGCTTTCTTCATATACGTTAGGCTCTCTAGCAAAAGAATATCAAGCACAACAGATATCTCCGAAGAAATCGACCTCTGCAAAAAGATCTCCTTCCCGCTTTGATGACGTCAAAATTCCTTTGACTTGTGATATGAATCCGGCTCAGCAAGGAATTTATTTTCAATGGCTACTGGAGCCTGAAAGCCCTTACTATAATTATCAGATATTGTTAGAATGCGCTGGGTCGAACACCGATAGAATCCGTCGTGCTCTTGGCCAGGCATTACGGGCGAATCCACAGCTAATGGCGAAGTTTGGAGTGGATTCAACTGGGAGATTTACACAGACGTTTCCTATCTCTGCTATCGATATGGATGAAATCTCAATACACGAAGTGGCCTCTGCGCAAGAGGCTCGTGAGATCTGTTGGATGAAAGCAGCAGTCCCTTTTAACCTGGAGGAAGGTCCCGCTATCGCCGTGGACGAGATCCGTATAAATGGATATTCTACCTGGTTCGTTTTGACCATGAACGAGATCCTTATCGATGGCTGGGGAGCAATGAAGTTCATGGAACAGTTAATTTCTCTTTTTGAGTGTCGTAACATGGACGATCAGGAGATCGAAGTCAAGACAGCTATGACTTCAGCTCTGGAATATTTCCAACATCTGTCGAAACCTGAAGAGATATCCGCTGAAGCACGAGAATTTTGGTCAAAATCACTCGATGGAGTGAAATCATGTTTCCCATTGCGCGATACATTAAATAGTTCGTGTGATCCCTACGCTGCTTCTGTTATAGAGGTCTCTCTAGATGACGAAGCGACTGCTGAGATCCGTTCCACTGCGCATGCATTGAGTACAAGCCCATTTGCAGTATTCGTGGCTGCTTATTCGTTAGCGTTGGCAGCGGTCTCTGACCAACATGATTTTGTTGTCGGTGCACCAGTAGCAGGGCGAAACGATGAGTATGAAATTGGCGTCCCAACTCTGATGCTTAACATGATTGCAATACGAACTCGTATAGATGTCGAAAAGAAAATTAGTGACACAGTACGTTCGATGATATCTAATGTGACTGAAGCTGTCTCATTCGGTGACAGCGTATTTAGCAAGGTTGTTTCTGAGTTCGCTGATCACACGAACGAGGATCCATTGTTTAGCACGATGGTGAATATGCTTACTTACCCGTCTCTGGAGTTTTGGGATGGTGATCGAAGCCTTCACTTAACTGAATTGAATACTGGGTTTACGAAATATGATGCGTCTCTTTATATCCAGCGACACGGCGAAGATTATACCTTGCAACTTGCTTATAAAGTGGCGTATGTGACACCAGAACGCGCTAATAAAGTACTGGCTCTTACAGCGTGGTTCCTTACCTCTGATTGGCTCTCGGGGAAGACGACTGTCGCTAATGCCATAAAAACTGCCCTTAATGATTGTGATACATCTCAGATAACAATGCTCAAAAGCTATTGA",
                            "abbreviation": "A",
                            "html_class": "jsdomain-adenylation"
                        },
                        {
                            "type": "PCP",
                            "start": 569,
                            "end": 624,
                            "predictions": [],
                            "napdoslink": "",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VQDVLGTPVNPELTFIESGGDSLRAIQLANIVRSRGSYVRVRDLLSSYTLGSLAK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "VQDVLGTPVNPELTFIESGGDSLRAIQLANIVRSRGSYVRVRDLLSSYTLGSLAK",
                            "dna_sequence": "GTGATAAACCTTACCAAAAGTTTGGAAAAAAATGGGTTGAGCTTGCTCGCTACCCGGAGTGCACTGGTCGGGGAAAACGTCGACTGGCCTTTAGAACGCACACTCTACTCGTATTTAGTTGAATGGGCCCAGATCACTTCACATCACGTTGCCGTAATAGATATTCATGGTGAAGAAATCACCTACGAAATGTTATTGAATCGAGTTAACAATCGAGCCTATCTCTTGGAAAAGAAACATGCCTTTGGAAGAGTAGTCATTTCAGAGCACTCGCGCGGTATCGAATGTCTTGTCGATATCCTAGCTTGTAGTGCCGTAGGTGCCATCTATACACCCATTGATCCTCAGTGGCCAGAGGCTCGTCGTAAACATATTAAGACAATCACGAACGCGGTCGCCATTTTCACTGAAAATACCTCGCACGTAACGGAAGCAAAGGCACCATTAGGAGTCACATTTCTGGAGCGTGTGGATGATCCTTTCAACGCTCCAAGCTACTGCTTTTTCACCTCGGGTAGCACAGGTGAACCGAAAGGTGCGCTAATCGCGCATATGGGCATGATGAATCACTTGCATAGCAAAGCCCATCTCCTTCATCTTGGTGTTGACTCAGTTGTGGCCCAGACGGCACCTACCACCTTTGATGTATCCATTTGGCAATTTTGTTCAGCTTTACTGGTAGGCGGTGCAGTACGTATCGTCCCCAACGGTATTTCACAGGATCCACATGAGCTTTTTTCTTTACTGGAAGAGAAACATATAACACACATTGAACTAGTTCCGACAGTATTTCGTGAACTTATTCACGAAATTGGGTCAAGCGTGTCTTTCTCTGGGCTTGAGTATGTTCTGGTGACTGGTGAAGAATTACCCCTTCGGTTGGCTAGAGACTGGGCAGACAAATTTCCGTTTGTCCCGTTGATTAATGCGTATGGTCCTACGGAATGTTCTGATGATGTAACGCATGCGATCGTGGATGGCGAATCGCTTAACTCAGGTGAAGTTCCCATCGGAATTCCAATACCTAATACGTCTTTATACGTCCTAGAGTACGCAGAAGGTACTTGGCGTCCAGTTTCTCCTGGAGCGCAAGGCGAGCTTTTTGTTGCTGGTCTTTGTGTGGGTTTAGGTTATATCGGAAGCCCAGATAAAACCGCTCAAGCATTTGCCAGGATTGATGGATACCCATTCCGAATATACCGCACCGGAGATCTCGTTCACCAGCGAGCGGATGGTCAGCTGGTTTACGATGGCCGCGCTGATCGACAGATAAAAATTAGTGGAGTACGGATTGAGCCCGGTGAAATCGAGAACCGTATCCTTCGAGAAATCCCAGAGCTTGAAGACGTTGTAGTGGTTAAATTCCACCCTCGTGTCCGTGAACGTCGCGCAATGGTGCTCCGAGAAACGACGCACCAGTTTCTTCGCCAAGGAGACGCTAGCTTGGCCGCATTCTATCTTCCTCGCGCCGATTGTTTAGTTACTCCCAAAATGCTTAATAATCGCGCGAAAAGCAGTCTCCCTAGAGTGATGTGTCCATCCCGTTGGATAGAGGTTACTGATATTCCCACTACTTCAAATGGCAAGGTAGATATTAAGTTATTAGAGCGCCGTGCCGGGGAACTGTTACTGAATGAAATTCAAGAGTCAAGAGAGGGATCCATTCCCGGTAGAGTTGAACAGAATCAGGACTCTTTCATTCTTCTCGTTCAGGACGTGCTTGGCACTCCTGTGAATCCAGAACTAACATTCATCGAATCCGGAGGCGATTCTCTTCGAGCAATTCAGCTAGCCAATATTGTCCGCTCACGAGGATCTTACGTAAGAGTACGAGATTTGCTTTCTTCATATACGTTAGGCTCTCTAGCAAAAGAATATCAAGCACAACAGATATCTCCGAAGAAATCGACCTCTGCAAAAAGATCTCCTTCCCGCTTTGATGACGTCAAAATTCCTTTGACTTGTGATATGAATCCGGCTCAGCAAGGAATTTATTTTCAATGGCTACTGGAGCCTGAAAGCCCTTACTATAATTATCAGATATTGTTAGAATGCGCTGGGTCGAACACCGATAGAATCCGTCGTGCTCTTGGCCAGGCATTACGGGCGAATCCACAGCTAATGGCGAAGTTTGGAGTGGATTCAACTGGGAGATTTACACAGACGTTTCCTATCTCTGCTATCGATATGGATGAAATCTCAATACACGAAGTGGCCTCTGCGCAAGAGGCTCGTGAGATCTGTTGGATGAAAGCAGCAGTCCCTTTTAACCTGGAGGAAGGTCCCGCTATCGCCGTGGACGAGATCCGTATAAATGGATATTCTACCTGGTTCGTTTTGACCATGAACGAGATCCTTATCGATGGCTGGGGAGCAATGAAGTTCATGGAACAGTTAATTTCTCTTTTTGAGTGTCGTAACATGGACGATCAGGAGATCGAAGTCAAGACAGCTATGACTTCAGCTCTGGAATATTTCCAACATCTGTCGAAACCTGAAGAGATATCCGCTGAAGCACGAGAATTTTGGTCAAAATCACTCGATGGAGTGAAATCATGTTTCCCATTGCGCGATACATTAAATAGTTCGTGTGATCCCTACGCTGCTTCTGTTATAGAGGTCTCTCTAGATGACGAAGCGACTGCTGAGATCCGTTCCACTGCGCATGCATTGAGTACAAGCCCATTTGCAGTATTCGTGGCTGCTTATTCGTTAGCGTTGGCAGCGGTCTCTGACCAACATGATTTTGTTGTCGGTGCACCAGTAGCAGGGCGAAACGATGAGTATGAAATTGGCGTCCCAACTCTGATGCTTAACATGATTGCAATACGAACTCGTATAGATGTCGAAAAGAAAATTAGTGACACAGTACGTTCGATGATATCTAATGTGACTGAAGCTGTCTCATTCGGTGACAGCGTATTTAGCAAGGTTGTTTCTGAGTTCGCTGATCACACGAACGAGGATCCATTGTTTAGCACGATGGTGAATATGCTTACTTACCCGTCTCTGGAGTTTTGGGATGGTGATCGAAGCCTTCACTTAACTGAATTGAATACTGGGTTTACGAAATATGATGCGTCTCTTTATATCCAGCGACACGGCGAAGATTATACCTTGCAACTTGCTTATAAAGTGGCGTATGTGACACCAGAACGCGCTAATAAAGTACTGGCTCTTACAGCGTGGTTCCTTACCTCTGATTGGCTCTCGGGGAAGACGACTGTCGCTAATGCCATAAAAACTGCCCTTAATGATTGTGATACATCTCAGATAACAATGCTCAAAAGCTATTGA",
                            "abbreviation": "",
                            "html_class": "jsdomain-transport"
                        },
                        {
                            "type": "Condensation_LCL",
                            "start": 656,
                            "end": 948,
                            "predictions": [],
                            "napdoslink": "http://napdos.ucsd.edu/cgi-bin/process_request.cgi?query_type=aa&amp;ref_seq_file=all_C_public_12062011.faa&amp;Sequence=%3EC_domain_from_antiSMASH%0DMNPAQQGIYFQWLLEPESPYYNYQILLECAGSNTDRIRRALGQALRANPQLMAKFGVDSTGRFTQTFPISAIDMDEISIHEVASAQEAREICWMKAAVPFNLEEGPAIAVDEIRINGYSTWFVLTMNEILIDGWGAMKFMEQLISLFECRNMDDQEIEVKTAMTSALEYFQHLSKPEEISAEAREFWSKSLDGVKSCFPLRDTLNSSCDPYAASVIEVSLDDEATAEIRSTAHALSTSPFAVFVAAYSLALAAVSDQHDFVVGAPVAGRNDEYEIGVPTLMLNMIAIRTRID",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNPAQQGIYFQWLLEPESPYYNYQILLECAGSNTDRIRRALGQALRANPQLMAKFGVDSTGRFTQTFPISAIDMDEISIHEVASAQEAREICWMKAAVPFNLEEGPAIAVDEIRINGYSTWFVLTMNEILIDGWGAMKFMEQLISLFECRNMDDQEIEVKTAMTSALEYFQHLSKPEEISAEAREFWSKSLDGVKSCFPLRDTLNSSCDPYAASVIEVSLDDEATAEIRSTAHALSTSPFAVFVAAYSLALAAVSDQHDFVVGAPVAGRNDEYEIGVPTLMLNMIAIRTRID&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "MNPAQQGIYFQWLLEPESPYYNYQILLECAGSNTDRIRRALGQALRANPQLMAKFGVDSTGRFTQTFPISAIDMDEISIHEVASAQEAREICWMKAAVPFNLEEGPAIAVDEIRINGYSTWFVLTMNEILIDGWGAMKFMEQLISLFECRNMDDQEIEVKTAMTSALEYFQHLSKPEEISAEAREFWSKSLDGVKSCFPLRDTLNSSCDPYAASVIEVSLDDEATAEIRSTAHALSTSPFAVFVAAYSLALAAVSDQHDFVVGAPVAGRNDEYEIGVPTLMLNMIAIRTRID",
                            "dna_sequence": "GTGATAAACCTTACCAAAAGTTTGGAAAAAAATGGGTTGAGCTTGCTCGCTACCCGGAGTGCACTGGTCGGGGAAAACGTCGACTGGCCTTTAGAACGCACACTCTACTCGTATTTAGTTGAATGGGCCCAGATCACTTCACATCACGTTGCCGTAATAGATATTCATGGTGAAGAAATCACCTACGAAATGTTATTGAATCGAGTTAACAATCGAGCCTATCTCTTGGAAAAGAAACATGCCTTTGGAAGAGTAGTCATTTCAGAGCACTCGCGCGGTATCGAATGTCTTGTCGATATCCTAGCTTGTAGTGCCGTAGGTGCCATCTATACACCCATTGATCCTCAGTGGCCAGAGGCTCGTCGTAAACATATTAAGACAATCACGAACGCGGTCGCCATTTTCACTGAAAATACCTCGCACGTAACGGAAGCAAAGGCACCATTAGGAGTCACATTTCTGGAGCGTGTGGATGATCCTTTCAACGCTCCAAGCTACTGCTTTTTCACCTCGGGTAGCACAGGTGAACCGAAAGGTGCGCTAATCGCGCATATGGGCATGATGAATCACTTGCATAGCAAAGCCCATCTCCTTCATCTTGGTGTTGACTCAGTTGTGGCCCAGACGGCACCTACCACCTTTGATGTATCCATTTGGCAATTTTGTTCAGCTTTACTGGTAGGCGGTGCAGTACGTATCGTCCCCAACGGTATTTCACAGGATCCACATGAGCTTTTTTCTTTACTGGAAGAGAAACATATAACACACATTGAACTAGTTCCGACAGTATTTCGTGAACTTATTCACGAAATTGGGTCAAGCGTGTCTTTCTCTGGGCTTGAGTATGTTCTGGTGACTGGTGAAGAATTACCCCTTCGGTTGGCTAGAGACTGGGCAGACAAATTTCCGTTTGTCCCGTTGATTAATGCGTATGGTCCTACGGAATGTTCTGATGATGTAACGCATGCGATCGTGGATGGCGAATCGCTTAACTCAGGTGAAGTTCCCATCGGAATTCCAATACCTAATACGTCTTTATACGTCCTAGAGTACGCAGAAGGTACTTGGCGTCCAGTTTCTCCTGGAGCGCAAGGCGAGCTTTTTGTTGCTGGTCTTTGTGTGGGTTTAGGTTATATCGGAAGCCCAGATAAAACCGCTCAAGCATTTGCCAGGATTGATGGATACCCATTCCGAATATACCGCACCGGAGATCTCGTTCACCAGCGAGCGGATGGTCAGCTGGTTTACGATGGCCGCGCTGATCGACAGATAAAAATTAGTGGAGTACGGATTGAGCCCGGTGAAATCGAGAACCGTATCCTTCGAGAAATCCCAGAGCTTGAAGACGTTGTAGTGGTTAAATTCCACCCTCGTGTCCGTGAACGTCGCGCAATGGTGCTCCGAGAAACGACGCACCAGTTTCTTCGCCAAGGAGACGCTAGCTTGGCCGCATTCTATCTTCCTCGCGCCGATTGTTTAGTTACTCCCAAAATGCTTAATAATCGCGCGAAAAGCAGTCTCCCTAGAGTGATGTGTCCATCCCGTTGGATAGAGGTTACTGATATTCCCACTACTTCAAATGGCAAGGTAGATATTAAGTTATTAGAGCGCCGTGCCGGGGAACTGTTACTGAATGAAATTCAAGAGTCAAGAGAGGGATCCATTCCCGGTAGAGTTGAACAGAATCAGGACTCTTTCATTCTTCTCGTTCAGGACGTGCTTGGCACTCCTGTGAATCCAGAACTAACATTCATCGAATCCGGAGGCGATTCTCTTCGAGCAATTCAGCTAGCCAATATTGTCCGCTCACGAGGATCTTACGTAAGAGTACGAGATTTGCTTTCTTCATATACGTTAGGCTCTCTAGCAAAAGAATATCAAGCACAACAGATATCTCCGAAGAAATCGACCTCTGCAAAAAGATCTCCTTCCCGCTTTGATGACGTCAAAATTCCTTTGACTTGTGATATGAATCCGGCTCAGCAAGGAATTTATTTTCAATGGCTACTGGAGCCTGAAAGCCCTTACTATAATTATCAGATATTGTTAGAATGCGCTGGGTCGAACACCGATAGAATCCGTCGTGCTCTTGGCCAGGCATTACGGGCGAATCCACAGCTAATGGCGAAGTTTGGAGTGGATTCAACTGGGAGATTTACACAGACGTTTCCTATCTCTGCTATCGATATGGATGAAATCTCAATACACGAAGTGGCCTCTGCGCAAGAGGCTCGTGAGATCTGTTGGATGAAAGCAGCAGTCCCTTTTAACCTGGAGGAAGGTCCCGCTATCGCCGTGGACGAGATCCGTATAAATGGATATTCTACCTGGTTCGTTTTGACCATGAACGAGATCCTTATCGATGGCTGGGGAGCAATGAAGTTCATGGAACAGTTAATTTCTCTTTTTGAGTGTCGTAACATGGACGATCAGGAGATCGAAGTCAAGACAGCTATGACTTCAGCTCTGGAATATTTCCAACATCTGTCGAAACCTGAAGAGATATCCGCTGAAGCACGAGAATTTTGGTCAAAATCACTCGATGGAGTGAAATCATGTTTCCCATTGCGCGATACATTAAATAGTTCGTGTGATCCCTACGCTGCTTCTGTTATAGAGGTCTCTCTAGATGACGAAGCGACTGCTGAGATCCGTTCCACTGCGCATGCATTGAGTACAAGCCCATTTGCAGTATTCGTGGCTGCTTATTCGTTAGCGTTGGCAGCGGTCTCTGACCAACATGATTTTGTTGTCGGTGCACCAGTAGCAGGGCGAAACGATGAGTATGAAATTGGCGTCCCAACTCTGATGCTTAACATGATTGCAATACGAACTCGTATAGATGTCGAAAAGAAAATTAGTGACACAGTACGTTCGATGATATCTAATGTGACTGAAGCTGTCTCATTCGGTGACAGCGTATTTAGCAAGGTTGTTTCTGAGTTCGCTGATCACACGAACGAGGATCCATTGTTTAGCACGATGGTGAATATGCTTACTTACCCGTCTCTGGAGTTTTGGGATGGTGATCGAAGCCTTCACTTAACTGAATTGAATACTGGGTTTACGAAATATGATGCGTCTCTTTATATCCAGCGACACGGCGAAGATTATACCTTGCAACTTGCTTATAAAGTGGCGTATGTGACACCAGAACGCGCTAATAAAGTACTGGCTCTTACAGCGTGGTTCCTTACCTCTGATTGGCTCTCGGGGAAGACGACTGTCGCTAATGCCATAAAAACTGCCCTTAATGATTGTGATACATCTCAGATAACAATGCTCAAAAGCTATTGA",
                            "abbreviation": "C",
                            "html_class": "jsdomain-condensation"
                        }
                    ],
                    "modules": [
                        {
                            "start": 40,
                            "end": 624,
                            "complete": true,
                            "iterative": false,
                            "monomer": "?",
                            "multi_cds": null,
                            "match_id": null
                        },
                        {
                            "start": 656,
                            "end": 948,
                            "complete": false,
                            "iterative": false,
                            "monomer": "",
                            "multi_cds": null,
                            "match_id": null
                        }
                    ]
                }
            ]
        }
    },
    "pfam": {
        "r1c1": {
            "pfamOrfs": [
                {
                    "id": "AAA_01665",
                    "seqLength": 197,
                    "pfams": [
                        {
                            "start": 4,
                            "end": 117,
                            "name": "PIN",
                            "accession": "PF01850.21",
                            "description": "PIN domain",
                            "translation": "VEVSVLAEMLVGSTVGCAAWQQWGGEEFIAPQHLSAEIAHVVRNLSLGQLITDAEAMQILSDFRAFKVELYPVEPLMVDAWEMRHNVSAYDALYVVLARLLGACLLTRDHRLK",
                            "evalue": "4.9e-07",
                            "score": "30.3",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        }
                    ]
                },
                {
                    "id": "AAA_01669",
                    "seqLength": 98,
                    "pfams": [
                        {
                            "start": 1,
                            "end": 61,
                            "name": "ABC2_membrane",
                            "accession": "PF01061.24",
                            "description": "ABC-2 type transporter",
                            "translation": "SYALALRTKSEAALSAIFNVALLPLLLLSGIMLPLSFAPRWIGAVARFNPLWYLVSGTRD",
                            "evalue": "1.2e-09",
                            "score": "38.0",
                            "go_terms": [],
                            "html_class": "pfam-type-transport"
                        }
                    ]
                },
                {
                    "id": "AAA_01670",
                    "seqLength": 109,
                    "pfams": [
                        {
                            "start": 2,
                            "end": 92,
                            "name": "ABC2_membrane",
                            "accession": "PF01061.24",
                            "description": "ABC-2 type transporter",
                            "translation": "ACFRRYLTLAARNRRDFALSFVQPLVYIVLFGPLFVASVNMAQHLTQGRSYALYVSGLCLQIAMTIGAFSGLSIILEYRLGILERIWSTP",
                            "evalue": "2.4e-07",
                            "score": "30.4",
                            "go_terms": [],
                            "html_class": "pfam-type-transport"
                        }
                    ]
                },
                {
                    "id": "AAA_01671",
                    "seqLength": 326,
                    "pfams": [
                        {
                            "start": 32,
                            "end": 172,
                            "name": "ABC_tran",
                            "accession": "PF00005.27",
                            "description": "ABC transporter",
                            "translation": "LNGVSLELGRGEMLSLFGPNGAGKTTLVRIIAGLLSADSGTIEWPGNESRNPRSLLGYVSQKGGLQYGLTCREEMTFHVRCFGLGDREAARRVERVTEMLHCGYLLDWNVDRLSGGQRRVVEVGMALLHEPAVILLDEPT",
                            "evalue": "4.9e-27",
                            "score": "95.1",
                            "go_terms": [],
                            "html_class": "pfam-type-transport"
                        }
                    ]
                },
                {
                    "id": "AAA_01673",
                    "seqLength": 73,
                    "pfams": [
                        {
                            "start": 8,
                            "end": 50,
                            "name": "DUF2815",
                            "accession": "PF10991.8",
                            "description": "Protein of unknown function (DUF2815)",
                            "translation": "VVTGEVRLSYTNIFEAKSIQGGKPKYSVSVIIPKGERVTGIE",
                            "evalue": "2.7e-11",
                            "score": "43.7",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        }
                    ]
                },
                {
                    "id": "AAA_01674",
                    "seqLength": 110,
                    "pfams": [
                        {
                            "start": 52,
                            "end": 107,
                            "name": "Lactococcin_972",
                            "accession": "PF09683.10",
                            "description": "Bacteriocin (Lactococcin_972)",
                            "translation": "GGGLWDHGSDMSSVWSNYYHRTSNHGSTAAGNEVKYSGCKRPTVTSHASAPLSWY",
                            "evalue": "7.7e-11",
                            "score": "42.4",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "AAA_01677",
                    "seqLength": 212,
                    "pfams": [
                        {
                            "start": 19,
                            "end": 165,
                            "name": "ABC_tran",
                            "accession": "PF00005.27",
                            "description": "ABC transporter",
                            "translation": "GISFEVSRGKIFGITGPSGGGKTTLLNCLGALEKPTSGNIFLNGRRISGLSVRKSRRLWAKDIGFLFQDYALVDRMNVRSNVSMGVPHLIGRRGLDDGISSALAGVGLPGCGVNPTYQLSGGEQQRVALARLMLKSPSLVLADEPT",
                            "evalue": "2.9e-31",
                            "score": "108.8",
                            "go_terms": [],
                            "html_class": "pfam-type-transport"
                        }
                    ]
                }
            ]
        },
        "r2c1": {
            "pfamOrfs": [
                {
                    "id": "AAA_02516",
                    "seqLength": 435,
                    "pfams": [
                        {
                            "start": 183,
                            "end": 317,
                            "name": "ATP-grasp_4",
                            "accession": "PF13535.6",
                            "description": "ATP-grasp domain",
                            "translation": "IVKPSIGMGSVGVRHILNVEDTSGLDAVVLEGNYCLEEFITGIEYSVEGIAIDGRVCIYTTTAKTTNEDFVEIGHIQPADLNSISSKLEFEEQLQSCVNALGIECGNLHVEFWVTPEKKIVWGEFHVRQGGDFI",
                            "evalue": "4.6e-11",
                            "score": "42.6",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "AAA_02517",
                    "seqLength": 237,
                    "pfams": [
                        {
                            "start": 18,
                            "end": 221,
                            "name": "Thioesterase",
                            "accession": "PF00975.20",
                            "description": "Thioesterase domain",
                            "translation": "TVLIFPPTGAGAPAFQSMSVLEGDTTVWGYCPPGRGQRLLEPGIRTMGEFVSKFRSSFEIPTGPLILAGVSFGAMLSFVAANILENDGIFATRLVALCGQSPKSYRGEREGWNLERARQRMRSYGLTPKSILNSDESDDLFVRPTLDDLLLAESCCGNQLKQIHVPITCVSAIDDKIVSSEEAVQWREATSETYRLIEVTGGH",
                            "evalue": "7.7e-12",
                            "score": "45.8",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "AAA_02518",
                    "seqLength": 579,
                    "pfams": [
                        {
                            "start": 103,
                            "end": 395,
                            "name": "AMP-binding",
                            "accession": "PF00501.28",
                            "description": "AMP-binding enzyme",
                            "translation": "KTVLIDDSTAEEAIFAGNWISDVRSLTWSDKSKFLYFTSGSEGVPKAVQVGMDAVRNRITWMWNAYPYESSDLVVVQKPLSFVASFWEVLGTLLAGVTGVLITNIERSRPDVMFDRLASSGATHLFTTPPALASLCDIATEQGSTLPQLRLACSSADQLMASVVRQFFEIAPRARVVNLYGATETSANTTSFEVSRSGSIPDPIPLGEPICATKIVIRDMKGNEKLSGEEGQICVQGAPVADGYIVNGQLSPGDDAFFTLGSGQREIRTGDLGIIKDGVLSLVGRLDNAVNI",
                            "evalue": "2.9e-43",
                            "score": "148.0",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        },
                        {
                            "start": 506,
                            "end": 569,
                            "name": "PP-binding",
                            "accession": "PF00550.25",
                            "description": "Phosphopantetheine attachment site",
                            "translation": "DQVQNIWDMVLGKKIHGEDRDFFSAGGNSLRAVQLLTAIGKQFGVRVPLRNFYSNPTISCLVS",
                            "evalue": "7.6e-12",
                            "score": "45.4",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "AAA_02519",
                    "seqLength": 1098,
                    "pfams": [
                        {
                            "start": 40,
                            "end": 427,
                            "name": "AMP-binding",
                            "accession": "PF00501.28",
                            "description": "AMP-binding enzyme",
                            "translation": "EWAQITSHHVAVIDIHGEEITYEMLLNRVNNRAYLLEKKHAFGRVVISEHSRGIECLVDILACSAVGAIYTPIDPQWPEARRKHIKTITNAVAIFTENTSHVTEAKAPLGVTFLERVDDPFNAPSYCFFTSGSTGEPKGALIAHMGMMNHLHSKAHLLHLGVDSVVAQTAPTTFDVSIWQFCSALLVGGAVRIVPNGISQDPHELFSLLEEKHITHIELVPTVFRELIHEIGSSVSFSGLEYVLVTGEELPLRLARDWADKFPFVPLINAYGPTECSDDVTHAIVDGESLNSGEVPIGIPIPNTSLYVLEYAEGTWRPVSPGAQGELFVAGLCVGLGYIGSPDKTAQAFARIDGYPFRIYRTGDLVHQRADGQLVYDGRADRQIKIS",
                            "evalue": "1.6e-63",
                            "score": "214.8",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        },
                        {
                            "start": 568,
                            "end": 624,
                            "name": "PP-binding",
                            "accession": "PF00550.25",
                            "description": "Phosphopantetheine attachment site",
                            "translation": "LVQDVLGTPVNPELTFIESGGDSLRAIQLANIVRSRGSYVRVRDLLSSYTLGSLAK",
                            "evalue": "4.3e-05",
                            "score": "23.8",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        },
                        {
                            "start": 656,
                            "end": 1045,
                            "name": "Condensation",
                            "accession": "PF00668.20",
                            "description": "Condensation domain",
                            "translation": "MNPAQQGIYFQWLLEPESPYYNYQILLECAGSNTDRIRRALGQALRANPQLMAKFGVDSTGRFTQTFPISAIDMDEISIHEVASAQEAREICWMKAAVPFNLEEGPAIAVDEIRINGYSTWFVLTMNEILIDGWGAMKFMEQLISLFECRNMDDQEIEVKTAMTSALEYFQHLSKPEEISAEAREFWSKSLDGVKSCFPLRDTLNSSCDPYAASVIEVSLDDEATAEIRSTAHALSTSPFAVFVAAYSLALAAVSDQHDFVVGAPVAGRNDEYEIGVPTLMLNMIAIRTRIDVEKKISDTVRSMISNVTEAVSFGDSVFSKVVSEFADHTNEDPLFSTMVNMLTYPSLEFWDGDRSLHLTELNTGFTKYDASLYIQRHGEDYTLQLAYK",
                            "evalue": "4.9e-36",
                            "score": "124.4",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "AAA_02520",
                    "seqLength": 329,
                    "pfams": [
                        {
                            "start": 25,
                            "end": 312,
                            "name": "OCD_Mu_crystall",
                            "accession": "PF02423.15",
                            "description": "Ornithine cyclodeaminase/mu-crystallin family",
                            "translation": "LIDLVERVYRAHHAGNTVCPDSYFLRFPDAPRDRIIALPSYINDQTCVSGIKWISSFPENVDHGLQRASAVIVLNNTDNGYAYAFIEASRISAARTAASAALAVRVLHGAPTSIGVVGSGPIAQTTLHFIKSLYTTAVPVKIHDLNSELVARIVTRHGPECSVVSLEEALGCDLVLLATSAGTPYVPMSVRFQPNQLVLNISLRDLHPETIRTANNVFDDVEHCLKANTTPHLLEQLNGNRNFITGTLAEFICSEKQLDPDHPTVFSPFGLGILDLAVAQSLYEHVQ",
                            "evalue": "5.5e-26",
                            "score": "91.2",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "AAA_02521",
                    "seqLength": 333,
                    "pfams": [
                        {
                            "start": 11,
                            "end": 291,
                            "name": "PALP",
                            "accession": "PF00291.25",
                            "description": "Pyridoxal-phosphate dependent enzyme",
                            "translation": "NSQFVRLKNSFPKHDVYAKLEGLNTAGSVKLKTAIALVDSLEKLHGLQPGGWVVESSSGSLGIALSGVCARRGYKLTIVTDLNANSRSISHMRALGAEVEVVQSLDAAGGFLGTRLARVRELVEMPGGPLWTNQYENVANPEVHSKKTYRAIVEELGDPDYLFVGAGTTGTLMGVSRAVMKRGSCTKVYAIDSTGSVTFGGAPSRRYIPGLGASVKPPIFDEKFPLKRYYIDEIDTVRQCRRIAQVEGFLPGGSTGTVLAAFDALRDKIPEGSRVVIIAP",
                            "evalue": "9.7e-49",
                            "score": "166.3",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "AAA_02523",
                    "seqLength": 207,
                    "pfams": [
                        {
                            "start": 66,
                            "end": 167,
                            "name": "ACPS",
                            "accession": "PF01648.20",
                            "description": "4'-phosphopantetheinyl transferase superfamily",
                            "translation": "PVGVDVEAVAEPGLAVVSNDFSVEEVEALRTTATAPLSIARAMIWTRKEAYLKYLGLGLTVQLDSFSVIDQTLLSPAEGMTDGIQFYSWCDADNSHVISVC",
                            "evalue": "2.4e-11",
                            "score": "43.7",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "AAA_02529",
                    "seqLength": 186,
                    "pfams": [
                        {
                            "start": 115,
                            "end": 163,
                            "name": "Acetyltransf_1",
                            "accession": "PF00583.25",
                            "description": "Acetyltransferase (GNAT) family",
                            "translation": "CVHAVPRTQGHGSQILTQVCQWADEHGLTLELKPSGPAAERFYKRFGF",
                            "evalue": "2.9e-05",
                            "score": "24.3",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "AAA_02537",
                    "seqLength": 108,
                    "pfams": [
                        {
                            "start": 70,
                            "end": 105,
                            "name": "RHH_1",
                            "accession": "PF01402.21",
                            "description": "Ribbon-helix-helix protein, copG family",
                            "translation": "LRLDAETNTRLDAMAAETGRSPSDIMRTALIDYLD",
                            "evalue": "3e-06",
                            "score": "27.0",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        }
                    ]
                },
                {
                    "id": "AAA_02541",
                    "seqLength": 665,
                    "pfams": [
                        {
                            "start": 267,
                            "end": 383,
                            "name": "FtsK_SpoIIIE",
                            "accession": "PF01580.18",
                            "description": "FtsK/SpoIIIE family",
                            "translation": "PDSPDWEKIPQAVDEDGNTCYWDISGVMAHQLKAGRTRTGKTVSMIGDAVEAARRDWRVFIIDPKRIEYLGLREWPNIEMVATTVPDQVALIHWLWALMEDRYRRIEEEGARETDF",
                            "evalue": "1.1e-07",
                            "score": "31.5",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        }
                    ]
                },
                {
                    "id": "AAA_02543",
                    "seqLength": 206,
                    "pfams": [
                        {
                            "start": 58,
                            "end": 188,
                            "name": "Resolvase",
                            "accession": "PF00239.21",
                            "description": "Resolvase, N terminal domain",
                            "translation": "IIYARVCSADQKPDLDRQIARVMTWASAKELSVDGVVTEVGSGLDGHRKKFEKLLKDGSVRTILVEHRDRFCRFGSEYIEAALSAQNRRLLVVDDKEIEDDLVQDMTDVLTSMCARLYGKRSAKHRARKA",
                            "evalue": "1.8e-16",
                            "score": "60.6",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "AAA_02544",
                    "seqLength": 481,
                    "pfams": [
                        {
                            "start": 19,
                            "end": 59,
                            "name": "HTH_OrfB_IS605",
                            "accession": "PF12323.8",
                            "description": "Helix-turn-helix domain",
                            "translation": "RSYKFALKPTKSQEQKLRQHTGAARFVYNYLISQWRDDIH",
                            "evalue": "3.2e-13",
                            "score": "48.9",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        },
                        {
                            "start": 212,
                            "end": 338,
                            "name": "OrfB_IS605",
                            "accession": "PF01385.19",
                            "description": "Probable transposase",
                            "translation": "YEKKHIPETHAHSGSVVGVDMGVGDHVIVAATPNGDEVMRRGLPQSVKKDEARVRHLQRKLSRKHGPDKRTKTTPSNRWIRANNQVNKYRAKLANIRRDLAAKAAHGLATNYETVVIEDLNVQAMM",
                            "evalue": "6e-13",
                            "score": "49.1",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        },
                        {
                            "start": 356,
                            "end": 426,
                            "name": "OrfB_Zn_ribbon",
                            "accession": "PF07282.11",
                            "description": "Putative transposase DNA-binding domain",
                            "translation": "FADVRRRITYKTRWNGGRTVIADRWFPSSKTCSECGEVKSKLSLSEREYICHRCGVVVDRDLNAATNLAK",
                            "evalue": "2e-20",
                            "score": "72.5",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        }
                    ]
                }
            ]
        }
    }
};
var resultsData = {};
